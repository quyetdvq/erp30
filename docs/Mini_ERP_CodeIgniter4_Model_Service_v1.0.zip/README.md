Mini ERP CodeIgniter 4 Model & Service v1.0

Based on:
Mini ERP CodeIgniter 4 Model Relationship & Entity Design v1.1 Final

Included:
- OrganizationModel
- EmployeeModel
- EmployeeAssignmentModel
- PolicyModel
- EmployeeContextResolver
- DecisionEngine
- AuthorizationService

Next:
- Complete Entity classes
- ProfileResolver
- PolicyResolver
- AuditLogger
