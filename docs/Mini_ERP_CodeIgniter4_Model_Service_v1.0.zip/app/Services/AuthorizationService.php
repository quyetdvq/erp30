<?php

namespace App\Services;

class AuthorizationService
{
    protected DecisionEngine $decisionEngine;

    public function __construct()
    {
        $this->decisionEngine = new DecisionEngine();
    }

    public function check(array $context): string
    {
        // Flow:
        // 1. Resolve Employee Context
        // 2. Load Profile Permission
        // 3. Resolve Resource Action
        // 4. Load Policy
        // 5. Evaluate Effect

        return $this->decisionEngine->evaluate(
            $context['effects'] ?? []
        );
    }
}
