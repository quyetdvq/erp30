<?php

namespace App\Services;

use App\Models\EmployeeAssignmentModel;

class EmployeeContextResolver
{
    protected EmployeeAssignmentModel $assignmentModel;

    public function __construct()
    {
        $this->assignmentModel = new EmployeeAssignmentModel();
    }

    public function resolve(int $employeeId): array
    {
        return $this->assignmentModel
            ->getActiveAssignments($employeeId);
    }
}
