<?php

namespace App\Services;

class DecisionEngine
{
    public function evaluate(array $effects): string
    {
        if (in_array('ABSOLUTE_DENY', $effects)) {
            return 'DENY';
        }

        if (in_array('ALLOW', $effects)) {
            return 'ALLOW';
        }

        return 'DENY';
    }
}
