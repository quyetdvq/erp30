<?php

namespace App\Models;

use CodeIgniter\Model;

class EmployeeAssignmentModel extends Model
{
    protected $table = 'employee_assignments';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'employee_id',
        'organization_id',
        'department_id',
        'position_id',
        'is_primary',
        'effective_from',
        'effective_to',
        'status'
    ];

    public function getActiveAssignments(int $employeeId)
    {
        return $this->where('employee_id', $employeeId)
            ->where('status', 'ACTIVE')
            ->findAll();
    }

    public function getPrimaryAssignment(int $employeeId)
    {
        return $this->where([
            'employee_id' => $employeeId,
            'is_primary' => 1
        ])->first();
    }
}
