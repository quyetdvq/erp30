<?php

namespace App\Models;

use CodeIgniter\Model;

class PolicyModel extends Model
{
    protected $table = 'policies';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'organization_id',
        'resource_id',
        'state_id',
        'participant_type',
        'participant_ref_id',
        'created_by',
        'updated_by'
    ];

    public function findMatching(array $criteria)
    {
        return $this->where($criteria)->findAll();
    }
}
