<?php

namespace App\Models;

use CodeIgniter\Model;

class OrganizationModel extends Model
{
    protected $table = 'organizations';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'parent_id','type','code','name','status',
        'active_from','active_to'
    ];

    public function getChildren(int $id)
    {
        return $this->where('parent_id', $id)->findAll();
    }

    public function getTree()
    {
        return $this->where('parent_id', null)->findAll();
    }
}
