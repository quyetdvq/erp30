# Mini ERP CodeIgniter 4 Migration v1.2 Full Schema

Based on Mini ERP Authorization Database Design v1.2.

Applied:
- DBPrefix: dinktech_
- Driver: MySQLi
- Logical table names in migration
- InnoDB / utf8mb4 convention

Contains migration files:
001 provinces
002 wards
003 contacts
004 organizations
005 departments
006 positions
007 employees
008 employee_assignments
009 lifecycles
010 workflow_states
011 lifecycle_states
012 resources
013 resource_actions
014 roles
015 role_permissions
016 policies
017 policy_actions
018 authorization_logs
