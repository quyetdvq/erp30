<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateResourceActionsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
'id'=>['type'=>'BIGINT','unsigned'=>true,'auto_increment'=>true],
'created_at'=>['type'=>'DATETIME','null'=>true],
'updated_at'=>['type'=>'DATETIME','null'=>true],
]);
$this->forge->addKey('id', true);

        $this->forge->createTable('resource_actions');
    }

    public function down()
    {
        $this->forge->dropTable('resource_actions');
    }
}
