<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePolicyActionsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
'id'=>['type'=>'BIGINT','unsigned'=>true,'auto_increment'=>true],
'created_at'=>['type'=>'DATETIME','null'=>true],
'updated_at'=>['type'=>'DATETIME','null'=>true],
]);
$this->forge->addKey('id', true);

        $this->forge->createTable('policy_actions');
    }

    public function down()
    {
        $this->forge->dropTable('policy_actions');
    }
}
