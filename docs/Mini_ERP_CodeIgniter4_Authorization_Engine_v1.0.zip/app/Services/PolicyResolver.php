<?php
namespace App\Services;

use App\Models\PolicyModel;

class PolicyResolver
{
    protected PolicyModel $policyModel;

    public function __construct()
    {
        $this->policyModel = new PolicyModel();
    }

    public function resolve(array $context): array
    {
        return $this->policyModel
            ->where([
                'organization_id' => $context['organization_id'] ?? null,
                'resource_id' => $context['resource_id'] ?? null,
                'state_id' => $context['state_id'] ?? null,
            ])
            ->findAll();
    }
}
