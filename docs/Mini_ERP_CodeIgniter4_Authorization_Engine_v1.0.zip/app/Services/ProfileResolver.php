<?php
namespace App\Services;

class ProfileResolver
{
    /**
     * Resolve effective permission profile.
     *
     * Profile =
     * Role Permission
     * +
     * User Permission Override
     */
    public function resolve(int $userId): array
    {
        return [];
    }
}
