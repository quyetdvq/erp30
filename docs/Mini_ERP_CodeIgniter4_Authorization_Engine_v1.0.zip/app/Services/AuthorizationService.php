<?php
namespace App\Services;

class AuthorizationService
{
    protected ProfileResolver $profileResolver;
    protected PolicyResolver $policyResolver;
    protected DecisionEngine $decisionEngine;

    public function __construct()
    {
        $this->profileResolver = new ProfileResolver();
        $this->policyResolver = new PolicyResolver();
        $this->decisionEngine = new DecisionEngine();
    }

    public function check(array $context): string
    {
        $profile = $this->profileResolver->resolve(
            $context['user_id']
        );

        $policies = $this->policyResolver->resolve($context);

        return $this->decisionEngine->evaluate(
            $profile,
            $policies
        );
    }
}
