<?php
namespace App\Entities;

use CodeIgniter\Entity\Entity;

class Organization extends Entity
{
    protected $attributes = [
        'id' => null,
        'parent_id' => null,
        'type' => null,
        'code' => null,
        'name' => null,
        'status' => null,
    ];
}
