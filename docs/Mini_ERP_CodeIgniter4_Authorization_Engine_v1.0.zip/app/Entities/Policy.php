<?php
namespace App\Entities;

use CodeIgniter\Entity\Entity;

class Policy extends Entity
{
    protected $attributes = [
        'id' => null,
        'organization_id' => null,
        'resource_id' => null,
        'state_id' => null,
        'participant_type' => null,
        'participant_ref_id' => null,
    ];
}
