<?php
namespace App\Entities;

use CodeIgniter\Entity\Entity;

class EmployeeAssignment extends Entity
{
    protected $attributes = [
        'id' => null,
        'employee_id' => null,
        'organization_id' => null,
        'department_id' => null,
        'position_id' => null,
        'is_primary' => false,
        'status' => null,
    ];
}
