<?php
namespace App\Entities;

use CodeIgniter\Entity\Entity;

class Employee extends Entity
{
    protected $attributes = [
        'id' => null,
        'user_id' => null,
        'employee_code' => null,
        'status' => null,
    ];
}
