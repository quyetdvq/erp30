<?php
namespace App\Entities;

use CodeIgniter\Entity\Entity;

class Resource extends Entity
{
    protected $attributes = [
        'id' => null,
        'lifecycle_id' => null,
        'type' => null,
        'name' => null,
        'domain' => null,
        'status' => null,
    ];
}
