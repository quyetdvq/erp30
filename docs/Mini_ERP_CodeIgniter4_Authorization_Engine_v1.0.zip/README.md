Mini ERP CodeIgniter 4 Authorization Engine v1.0

Implemented:
- Entity base classes
- ProfileResolver skeleton
- PolicyResolver
- AuthorizationService integration

Based on:
Mini ERP CodeIgniter 4 Model Relationship & Entity Design v1.1 Final

Next:
- Complete Shield Permission integration
- Complete DecisionEngine
- AuditLogger
