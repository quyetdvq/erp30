Mini ERP Authorization Engine v1.1

Implemented:
- DecisionEngine
- AuditLogger
- AuthorizationService evaluation flow

Authorization rules:
ABSOLUTE_DENY > ALLOW > DENY

Flow:
User
 -> Profile Permission
 -> Policy Evaluation
 -> Decision
 -> Audit Log
