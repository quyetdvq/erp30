<?php

namespace App\Services;

use App\Models\AuthorizationLogModel;

class AuditLogger
{
    protected AuthorizationLogModel $model;

    public function __construct()
    {
        $this->model = new AuthorizationLogModel();
    }

    public function log(array $data): bool
    {
        return (bool) $this->model->insert($data);
    }
}
