<?php

namespace App\Services;

class AuthorizationService
{
    protected ProfileResolver $profileResolver;
    protected PolicyResolver $policyResolver;
    protected DecisionEngine $decisionEngine;
    protected AuditLogger $auditLogger;

    public function __construct()
    {
        $this->profileResolver = new ProfileResolver();
        $this->policyResolver = new PolicyResolver();
        $this->decisionEngine = new DecisionEngine();
        $this->auditLogger = new AuditLogger();
    }

    public function check(array $context): array
    {
        $profile = $this->profileResolver->resolve(
            $context['user_id']
        );

        $hasPermission = in_array(
            $context['permission'],
            $profile,
            true
        );

        $policies = $this->policyResolver->resolve($context);

        $effects = [];

        foreach ($policies as $policy) {
            foreach (($policy['actions'] ?? []) as $action) {
                if ($action['permission'] === $context['permission']) {
                    $effects[] = $action['effect'];
                }
            }
        }

        $decision = $this->decisionEngine->evaluate(
            $hasPermission,
            $effects
        );

        $this->auditLogger->log([
            'user_id' => $context['user_id'],
            'organization_id' => $context['organization_id'] ?? null,
            'resource_id' => $context['resource_id'] ?? null,
            'action' => $context['permission'],
            'decision' => $decision,
            'reason' => 'Authorization evaluation',
            'request_id' => $context['request_id'] ?? null,
        ]);

        return [
            'decision' => $decision,
            'permission' => $hasPermission,
            'effects' => $effects,
        ];
    }
}
