<?php

namespace App\Services;

class DecisionEngine
{
    /**
     * Evaluate authorization effect.
     *
     * Priority:
     * ABSOLUTE_DENY
     *      >
     * ALLOW
     *      >
     * DENY
     */
    public function evaluate(
        bool $hasPermission,
        array $effects = []
    ): string {
        if (!$hasPermission) {
            return 'DENY';
        }

        if (in_array('ABSOLUTE_DENY', $effects, true)) {
            return 'DENY';
        }

        if (in_array('ALLOW', $effects, true)) {
            return 'ALLOW';
        }

        if (in_array('DENY', $effects, true)) {
            return 'DENY';
        }

        return 'ALLOW';
    }
}
