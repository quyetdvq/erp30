<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class AuthorizationFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $permission = $arguments[0] ?? null;

        if (!$permission) {
            return;
        }

        $authorization = service('authorization');

        $result = $authorization->check([
            'user_id' => auth()->id(),
            'permission' => $permission,
            'organization_id' => session()->get('organization_id'),
            'resource_id' => $arguments[1] ?? null,
            'state_id' => $arguments[2] ?? null,
        ]);

        if (($result['decision'] ?? 'DENY') !== 'ALLOW') {
            return service('response')
                ->setStatusCode(403)
                ->setJSON([
                    'message' => 'Access denied'
                ]);
        }
    }

    public function after(
        RequestInterface $request,
        ResponseInterface $response,
        $arguments = null
    ) {
    }
}
