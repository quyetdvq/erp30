<?php

namespace App\Libraries;

class CanPermission
{
    public function check(
        string $permission,
        array $context = []
    ): bool
    {
        $authorization = service('authorization');

        $result = $authorization->check(
            array_merge($context, [
                'permission' => $permission
            ])
        );

        return ($result['decision'] ?? 'DENY') === 'ALLOW';
    }
}
