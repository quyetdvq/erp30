<?php

if (! function_exists('can_permission')) {

    function can_permission(
        string $permission,
        array $context = []
    ): bool
    {
        return service('canPermission')
            ->check($permission, $context);
    }
}
