# P2-CUS — UAT/QA Checklist (chưa thực thi)

**Document ID:** P2-CUS-QA-001 · **v1.0.0** · **Status: NOT RUN.** Không có kết quả HTTP/DB/FE thật trong hồ sơ.  
**Phạm vi:** đủ 8 acceptance criteria gốc và 8 nhóm acceptance của change `P2-CUS-CR-001`.  
**Data:** fixture riêng cho Group, Company A/B, User A-only, User with GROUP assignment, Customer ACTIVE/INACTIVE, 2 địa chỉ hợp lệ và 1 contact-only, SO fulfillment partial, Posted/non-posted Money, reversal/COD.

## Coverage

| Requirement | Tên ngắn | Test cases |
|---|---|---|
| `P2-AT-CUS-001-01` | Customer Code global unique | CUS-TC-001, CUS-TC-002, CUS-TC-047 |
| `P2-AT-CUS-001-02` | Company ALL/list | CUS-TC-003, CUS-TC-004, CUS-TC-045 |
| `P2-AT-CUS-001-03` | Company out of usage no new transaction | CUS-TC-005 |
| `P2-AT-CUS-001-04` | Shared Contact multiple | CUS-TC-006, CUS-TC-007, CUS-TC-008, CUS-TC-039, CUS-TC-040, CUS-TC-041, CUS-TC-044 |
| `P2-AT-CUS-001-05` | Inactive and historic access | CUS-TC-009, CUS-TC-042 |
| `P2-AT-CUS-002-01` | Note/contact history | CUS-TC-010, CUS-TC-011 |
| `P2-AT-CUS-002-02` | Source transaction history authorized | CUS-TC-012, CUS-TC-013 |
| `P2-AT-CUS-002-03` | No Lead or Opportunity | CUS-TC-014 |
| `CUS-ADD-01` | Three distinct sales KPIs | CUS-TC-015, CUS-TC-016 |
| `CUS-ADD-02` | Delivered and POSTED, return commercial credits | CUS-TC-017, CUS-TC-018, CUS-TC-019, CUS-TC-020 |
| `CUS-ADD-03` | Order-level receivables | CUS-TC-021, CUS-TC-022, CUS-TC-043 |
| `CUS-ADD-04` | N:M money allocation, refunds/reversals | CUS-TC-023, CUS-TC-024, CUS-TC-025, CUS-TC-026 |
| `CUS-ADD-05` | COD customer pay vs provider remittance | CUS-TC-027, CUS-TC-028, CUS-TC-029 |
| `CUS-ADD-06` | Due date / aging no credit limit | CUS-TC-030, CUS-TC-031, CUS-TC-032 |
| `CUS-ADD-07` | Source permission, as-of and availability | CUS-TC-033, CUS-TC-034, CUS-TC-035, CUS-TC-036, CUS-TC-048 |
| `CUS-ADD-08` | Controlled group code PRC matching | CUS-TC-037, CUS-TC-038, CUS-TC-046 |

## Test case registry

| ID | Requirement | Gate | Scenario | Expected | Runtime |
|---|---|---|---|---|---|
| `CUS-TC-001` | `P2-AT-CUS-001-01` | CUS-G1 | Customer code duplicate within same Company vs different Company | Second create rejected; exactly one Group customer | NOT_RUN |
| `CUS-TC-002` | `P2-AT-CUS-001-01` | CUS-G1 | Two concurrent creates with same code | Exactly one commit; unique integrity; no orphan scope | NOT_RUN |
| `CUS-TC-003` | `P2-AT-CUS-001-02` | CUS-G1 | all_companies=true with no usage rows | Any active Company eligible subject to Sales PBAC | NOT_RUN |
| `CUS-TC-004` | `P2-AT-CUS-001-02` | CUS-G1 | all_companies=false Company A+B, empty/invalid/duplicate allowlist | Atomic, only valid distinct COMPANY IDs accepted | NOT_RUN |
| `CUS-TC-005` | `P2-AT-CUS-001-03` | CUS+SAL | Company C not in allowlist creates SO | Reject at server even if frontend is bypassed | NOT_RUN |
| `CUS-TC-006` | `P2-AT-CUS-001-04` | CUS-G1 | Three valid ship-to Contacts per Customer | All three selectable, no new customer_addresses | NOT_RUN |
| `CUS-TC-007` | `P2-AT-CUS-001-04` | CUS-G1 | Contact has email only/no address | Contact readable but not shipping-eligible | NOT_RUN |
| `CUS-TC-008` | `P2-AT-CUS-001-04` | CUS+SAL | Contact owner is another Customer/EMPLOYEE | Cannot select for this Customer; no spoof | NOT_RUN |
| `CUS-TC-009` | `P2-AT-CUS-001-05` | CUS+SAL | Customer made INACTIVE after historic SO | New SO rejected; old SO still readable under SAL scope | NOT_RUN |
| `CUS-TC-010` | `P2-AT-CUS-002-01` | CUS-G1 | Company A NOTE and Company B CALL; actor A only | B note absent from list/COUNT/export/paging | NOT_RUN |
| `CUS-TC-011` | `P2-AT-CUS-002-01` | CUS-G1 | Attempt to silently edit or delete a past interaction | Write rejected; corrective append retains original | NOT_RUN |
| `CUS-TC-012` | `P2-AT-CUS-002-02` | CUS+SAL+FIN | Only sales_order.view allowed, no money_receipt.view | Order visible; receipts/finance sums suppressed | NOT_RUN |
| `CUS-TC-013` | `P2-AT-CUS-002-02` | CUS+SAL+FIN | Company A actor reads combined Group Customer history A+B | Only authorized source records after SQL Company filtering | NOT_RUN |
| `CUS-TC-014` | `P2-AT-CUS-002-03` | CUS-G1 | Inspect CUS UI/resource/table catalog | No Lead/Opportunity pipeline or CRUD | NOT_RUN |
| `CUS-TC-015` | `CUS-ADD-01` | SAL+INV | Confirmed order value, shipped part, returned part | Three distinct KPIs; correct values and cutoff dates | NOT_RUN |
| `CUS-TC-016` | `CUS-ADD-01` | SAL | Order cancelled pre-fulfillment | No fulfilled value; confirmed value handling uses authoritative cancellation policy | NOT_RUN |
| `CUS-TC-017` | `CUS-ADD-02` | SAL+INV | Shipment delivered but Sales Issue not POSTED | No fulfilled amount yet | NOT_RUN |
| `CUS-TC-018` | `CUS-ADD-02` | SAL+INV | Sales Issue POSTED, Shipment not delivered | No fulfilled amount yet | NOT_RUN |
| `CUS-TC-019` | `CUS-ADD-02` | SAL+INV | Partial delivery and duplicate carrier callback | Only posted+delivered valid portion; no duplicate values | NOT_RUN |
| `CUS-TC-020` | `CUS-ADD-02` | SAL | Commercial credit approved but stock return not POSTED yet | Net sales decreases only per approved commercial credit event | NOT_RUN |
| `CUS-TC-021` | `CUS-ADD-03` | SAL+FIN | Payable 12m, approved credit 2m, paid allocation 7m | Open 3m VND, no AR/GL table | NOT_RUN |
| `CUS-TC-022` | `CUS-ADD-03` | FIN | Overpayment and unapplied receipt | Separate overpay/open due/unapplied buckets, not hide negative position | NOT_RUN |
| `CUS-TC-023` | `CUS-ADD-04` | FIN | One POSTED receipt allocated to two SOs | Total allocated <= posted amount, correct Company/customer | NOT_RUN |
| `CUS-TC-024` | `CUS-ADD-04` | FIN | Two POSTED receipts allocated to one SO | Correct sum; no double apply; concurrent lock | NOT_RUN |
| `CUS-TC-025` | `CUS-ADD-04` | FIN | Unposted/void/reversed receipt allocated | Not counted; linkage refused or reversed consistently | NOT_RUN |
| `CUS-TC-026` | `CUS-ADD-04` | FIN | Posted customer refund against prior allocated cash | net(o,t) corrected without duplicate commercial credit | NOT_RUN |
| `CUS-TC-027` | `CUS-ADD-05` | SAL+FIN | Carrier collected COD; Company not yet remitted | Customer collection distinct from cash in bank; carrier pending | NOT_RUN |
| `CUS-TC-028` | `CUS-ADD-05` | SAL+FIN | Carrier payout and FIN posted receipt | Carrier pending decreases; Customer debt not reduced twice | NOT_RUN |
| `CUS-TC-029` | `CUS-ADD-05` | SAL+FIN | Marketplace order unknown customer_id | Not attributed to named Customer; no phone-based join | NOT_RUN |
| `CUS-TC-030` | `CUS-ADD-06` | SAL+FIN | Order due_date missing, positive balance | UNKNOWN_DUE_DATE, not overdue | NOT_RUN |
| `CUS-TC-031` | `CUS-ADD-06` | SAL+FIN | Due date -1,-30,-31,-60,-61,-90,-91 days | Buckets 1–30,31–60,61–90,>90 correct Company business date | NOT_RUN |
| `CUS-TC-032` | `CUS-ADD-06` | CUS-G1 | Customer UI tries credit limit feature | Not present; new credit blocking not enabled | NOT_RUN |
| `CUS-TC-033` | `CUS-ADD-07` | CUS-G1 | Sales dependency not installed | Metric tagged DEPENDENCY_PENDING, not value 0 | NOT_RUN |
| `CUS-TC-034` | `CUS-ADD-07` | CUS+SAL+FIN | Denied one financial source permission | No hidden sums/count leak; NOT_AUTHORIZED | NOT_RUN |
| `CUS-TC-035` | `CUS-ADD-07` | SAL+FIN | As-of date before later receipt/refund/reversal | Historical value computed from valid past events only | NOT_RUN |
| `CUS-TC-036` | `CUS-ADD-07` | SAL+FIN | Period report vs as-of past payments and timezone midnight | Flow period and position as_of not mixed; Company timezone | NOT_RUN |
| `CUS-TC-037` | `CUS-ADD-08` | CUS+PRC | Pricing uses controlled code, group change after SO | No Customer Group FK required; historic SO price frozen | NOT_RUN |
| `CUS-TC-038` | `CUS-ADD-08` | CUS-G1 | Unknown customer_group_code posted | Validation reject, no arbitrary text group | NOT_RUN |
| `CUS-TC-039` | `P2-AT-CUS-001-04` | CUS+SAL | Update ship-to Contact after confirmed Order | Order/label snapshot remains unchanged | NOT_RUN |
| `CUS-TC-040` | `P2-AT-CUS-001-04` | CUS+SAL | Marketplace external delivery snapshot | No Contact created; source address retained | NOT_RUN |
| `CUS-TC-041` | `P2-AT-CUS-001-04` | CUS-G1 | Same person/mobile two locations | Two distinct eligible Contact rows, no dedup | NOT_RUN |
| `CUS-TC-042` | `P2-AT-CUS-001-05` | CUS-G1 | Remove Company A from allowlist with historic interaction | Historic record retained; PBAC governs read | NOT_RUN |
| `CUS-TC-043` | `CUS-ADD-03` | SAL+FIN | Receipt from Company B linked to Company A SO | Reject allocation; no cross-company balance | NOT_RUN |
| `CUS-TC-044` | `P2-AT-CUS-001-04` | CUS-G1 | P1 Organization and Employee Contacts regressions | Old owner operations and PBAC scope pass unchanged | NOT_RUN |
| `CUS-TC-045` | `P2-AT-CUS-001-02` | CUS-G1 | Company usage replace concurrent with inactivation | Serializable business outcome with locked parent; no invalid ACTIVE+empty LIST | NOT_RUN |
| `CUS-TC-046` | `CUS-ADD-08` | CUS+PRC | Price List matching Company->Group->default and Customer group | Preserve P1 precedence; PRC group-code conditions deterministic | NOT_RUN |
| `CUS-TC-047` | `P2-AT-CUS-001-01` | CUS-G1 | Numbering AUTO_REQUIRED with blank code + rollback | Generates business code in transaction, no committed skipped/duplicate | NOT_RUN |
| `CUS-TC-048` | `CUS-ADD-07` | CUS+SAL+FIN | Open source link without permission after summary response | New request re-authorizes; deny when source permission revoked | NOT_RUN |

## Execution gate

- Trước test: chưa duyệt migration/API/PBAC kỹ thuật thì test chỉ là kế hoạch.
- G1: chạy PHP unit, CI4 integration, MariaDB transaction/FK and EXPLAIN, FE unit/e2e, DEV clone + P1 Contact Organization/Employee regression; ghi actor/config/DB fixture, request/response, assertion, timestamp.
- XMOD: chạy các edge cases thực với SAL/INV/FIN/PRC/COD, riêng billing và finance projections cần source recon totals và cancellation/reversal consistency.
- Chưa có module nguồn => đánh dấu **DEFERRED**, không PASS, không hiển thị số 0 giả.
- Release signoff cần reviewer, build SHA, DB schema version, scenarios negative and positive, evidence URL/artifacts; dùng template trong `qa/10_SIGNOFF_TEMPLATE.md`.
