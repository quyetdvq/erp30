# PBAC, Identity, Company Scope và Audit — CUS

**Document ID:** P2-CUS-SEC-001 · **P1 contract inherited, P2 resource additions are design-approved conceptually, technical seeding pending.**

## 1. Security boundaries

- `customer` là Group Master: authorize canonical `GROUP` for shared create/update/view/setstate. Company list is business *eligibility for new transactions*, **not** authorization.
- `customer_interaction` thuộc `COMPANY` persisted, authorize at `company_organization_id`. Multiple Company access only if actor permitted per Company; no cross-Company lane merge.
- `customer_contact` uses existing P1 Contact resource approach extended to owner `CUSTOMER`; owner `(contact_type, contact_ref_id)` authoritative, immutable, not inferred from request context.
- `customer.sales_summary`/financial summary authorization requires both aggregate-level policy (if introduced) and the underlying source Data Resource/Action/Company filter. `customer.view` does not grant finance data.
- No System Admin bypass; Shield User→Employee→effective Assignment→PBAC base permission/policy. Inheritance `GROUP`→exact ancestor; `ABSOLUTE_DENY` propagated as P1.

## 2. Candidate Resource/Action catalog

| Resource | Actions proposed | Evaluation Organization |
|---|---|---|
| `customer` | `view/create/edit/setstate/export` | GROUP for Group Master |
| `customer_contact` | `view/create/edit/setstate` | Trusted Customer owner context; exact GROUP/Company resolution still technical gate |
| `customer_interaction` | `view/create/export` | Saved `company_organization_id` type COMPANY |
| Customer KPI reader | `view` or specific metric-view action TBD | Authorized Company/source, not Group blanket |
| `sales_order`, `shipment`, `sales_return`, `money_receipt` | Source `view` and `export` as configured | Persisted source Company per P2 module |

No new permission table. Catalog ResourceAction registered using P1 Resource/Action registry and approved Group assignments/Policy. ACTION `export` is independent of `view`.

## 3. Contact P1 modification boundary

Verified source: `backend/app/Modules/Contact/ContactRules.php` has exactly `ORGANIZATION`/`EMPLOYEE`; `ContactScope.php` chooses Organization or effective Employee Primary; `ContactScopeProvider.php` only supports `organization_contact` and `employee_contact`; `ContactSql.php` compiles SQL authorization predicates for those two branches. Thus `CUSTOMER` requires all four coordinated changes plus controller/service/read tests and seed of ResourceAction/Workflow. Inserting `contact_type='CUSTOMER'` alone is invalid.

For Customer contact owner, authoritative `customers.id` exists, resource `customer_contact`, Organization evaluation cannot come from request/client hint. P1 Contact SQL list includes authorized organization/employee branches; new Customer branch must be integrated **before** filtering/pagination. Security design must explicitly address whether Contact entries are Group-shared or Company-restricted (no `company_id` exists in P1 contacts). This detail is **still open** under `CUS-T-SEC-01`; no invented implicit access.

## 4. Interaction SQL scope and negative cases

Authorized filter minimum: `customer_id=target` and `company_organization_id IN permitted-company-ids` and the actor has `customer_interaction.view` at each Company. Reject untrusted `company_id` not type COMPANY, not allowed or outside Customer usage for **new** event. No count leak, no ordering/projection leak, no export leak. For historical records, current usage scope changes should not delete history; final historical read scope solely PBAC.

On primary Contact update, stored Contact must have `contact_type='CUSTOMER' AND contact_ref_id=customer.id`, regardless of permission to another Customer. Contact routing must not grant Customer permission through `employee_contact`/`organization_contact`. Wrong-owner/foreign Company source -> deny, no partial writes.

## 5. Access to SAL/FIN data

1. Apply Company and Resource view permissions **before** constructing list/aggregate.
2. If actor may view `sales_order` but not `money_receipt`, show order summary only; receipt and receivable totals suppressed when not faithfully computable without finance data.
3. Unknown/deferred source => `DEPENDENCY_PENDING`; denied source => not authorized, never `0`.
4. Per-source navigation/external documents enforce permission again at access time; do not use CUS fetch as authorization token.
5. Request/user/employee context, actor/timestamp and decision reason follow P1 audit and error convention; note contents potentially personal data, apply least privilege.

## 6. Security test matrix highlights

- Company A-only role cannot access B interactions using list, direct ID, sort pagination, count, export or summary.
- Base permission missing=>deny even if Policy ALLOW; `ABSOLUTE_DENY` cannot be opened through assignment lanes.
- Contacts owner spoofing, primary-contact mismatch, status bypass, context hint mismatch rejected; Organization/Employee contact regression remains PASS.
- Master Group access must not accidentally expose Company-private financial data; query-level SQL scoped and negative tests.
