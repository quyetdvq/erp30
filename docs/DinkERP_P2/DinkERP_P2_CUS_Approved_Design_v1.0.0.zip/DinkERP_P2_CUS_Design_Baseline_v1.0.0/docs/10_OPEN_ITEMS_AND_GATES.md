# Danh mục còn mở sau khi đã chốt 12/12 quyết định

**Điểm phân biệt quan trọng:** 12 quyết định `CUS-X-01`…`CUS-X-12` đã **APPROVED** và không được trình bày như chưa chốt. Bảng dưới đây là các **chi tiết kỹ thuật/thiết kế module nguồn chưa được Product Owner xác định đủ**, không phải câu hỏi chốt lại phương án A.

## 1. Các blocker trước khi triển khai CUS Core (G1)

| Mã | Chi tiết cần hoàn tất | Owner |
|---|---|---|
| `CUS-T-GROUP-01` | Khóa danh mục mã customer_group_code ban đầu, quy tắc thay đổi/retirement và giá trị NULL | PO + PRC |
| `CUS-T-SEC-01` | Contact CUSTOMER group-shared hay private theo Company? P1 Contact thiếu company_id; xác định resource/context PBAC authority | Security + BE |
| `CUS-T-SQL-01` | Thiết kế SQL-first contact CUSTOMER scope, limit/cap fail-closed, join owner & negative tests khi mở rộng ContactRules/ScopeProvider/Sql | BE + Security |
| `CUS-T-WF-01` | State registry customer/customer_contact/customer_interaction, transition ACTION và precise ResourceAction seeding | BE + PO |
| `CUS-T-API-01` | Khóa exact API shapes/errors, sort/filter, paging, exception mapping và schema P1 compatibility | BE + FE |
| `CUS-T-DATA-01` | Chuẩn hóa customer_code, collation DB, province/ward input rules, NUMBERING mode, company allowlist active mutation | DBA + BE |
| `CUS-T-INT-01` | Cấu hình activity_type codes, sửa nhật ký append-only và retention/actor identity | PO + BE |

**Gate G1-Design Ready:** chỉ được gắn `READY FOR IMPLEMENTATION` khi có các artifact xác nhận: catalog/migrations/schema, owner-aware Contact PBAC SQL strategy, customer/interaction ResourceAction+Lifecycle, API schema frozen, code-list, regression matrix reviewed. Không cần chờ SAL/FIN runtime để triển khai **Core**, nhưng không được cam kết full UAT.

## 2. Các blocker tích hợp tại module nguồn

| Mã | Chi tiết cần hoàn tất | Gate |
|---|---|---|
| `CUS-T-SEC-02` | Permission riêng cho sales-summary/receivables và source authorization fallback, aggregate suppression | G3/G4 |
| `CUS-SAL-01` | Lifecycle SO, partial cancellation, direct pickup equivalent delivered event, frozen price components/taxes/fees | G3 |
| `CUS-SAL-02` | Return commercially-approved credit event/time and partial goods/discount/COMBO rounding | G3/G4 |
| `CUS-FIN-01` | money_source_links typed payment/refund allocations, N:M locking, overpayment, reversal and unapplied prepayments | G4 |
| `CUS-FIN-02` | Due_date source/default term, aging as-of retroactive events, refunds on allocated cash and backdate policy | G4 |
| `CUS-COD-01` | Provider collected/remitted/settled statuses, payout many shipments, fees and no double count | G4 |
| `CUS-PRC-01` | Replace P2 draft customer_group_id FK with stable customer_group_code matching plus specificity/tie-break | G3 |
| `CUS-DOC-01` | Document owner Customer and file permission/retention, future attachment tab | G1 DOC |
| `CUS-REPORT-01` | Định nghĩa cuối kỳ/holiday/date filtering, exact aggregation sources, response availability/auth/error mapping | G4 |

**Gate CUS-XMOD:** các mục này được sở hữu bởi SAL/INV/FIN/PRC/DOC; CUS chỉ chuẩn bị hợp đồng và client read projection. Không thêm bảng CUS vì các mục chưa chốt.

## 3. Đối chiếu quyết định P2 v1.0.0 trước đây

- `P2-DEC-007` Customer Group: **đã được giải quyết ở mức business** bằng controlled `customer_group_code` không có bảng nhóm động. P2-PRC schema/lookup sửa tại `CUS-PRC-01`.
- `P2-DEC-008` Company Usage: **đã giải quyết** bằng ALL/current allowlist; không effective dating; giữ lịch sử.
- `P2-DEC-009` Contact CUSTOMER: **đã chốt kiến trúc** mở rộng P1 owner, nhưng precise SQL/PBAC vẫn BLOCKER_G1 (`CUS-T-SEC-01`, `CUS-T-SQL-01`).
- Những `P2-DEC-*` khác ngoài CUS chỉ được thay đổi nếu có quyết định/gate tương ứng; không đánh dấu global P2 G0 hoặc SAL/FIN là đã Approved nhờ chốt CUS.

## 4. Trạng thái nghiệm thu được phép công bố

| Trạng thái | Bằng chứng tối thiểu |
|---|---|
| `CUS-DESIGN DECISIONS APPROVED` | 12/12 PO decisions; 3-table data model; domain ownership |
| `CUS-G1 DESIGN READY` | 7 technical G1 blockers closed, coherent schema/API/PBAC test specification |
| `CUS-G1 IMPLEMENTED` | Code + migrations + CI4 route + Vue + tests integrated on DEV clone (chưa làm) |
| `CUS-CORE CLOSED` | 8 UR AC CUS Core relevant tests PASS; P1 regressions PASS; dependent history marked deferred |
| `CUS-XMOD CONTRACT LOCKED` | SAL/FIN/PRC/DOC owners sign exact monetary/timeline/event contracts |
| `CUS-FULL ACCEPTED` | Runtimes SAL/INV/FIN integrated, UR-CUS-002 + CR reports UAT PASS, negative PBAC + finance reconciliation evidence |

**Hiện tại**: chỉ trạng thái đầu tiên hợp lệ; toàn bộ test case `NOT_RUN`.
