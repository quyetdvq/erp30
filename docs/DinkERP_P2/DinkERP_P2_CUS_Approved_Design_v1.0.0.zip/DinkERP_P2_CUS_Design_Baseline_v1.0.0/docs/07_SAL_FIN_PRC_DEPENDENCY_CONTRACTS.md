# Liên module — SAL / INV / FIN / PRC / DOC / COD

**Document ID:** P2-CUS-XMOD-002 · **Business-level decisions APPROVED.** Exact status taxonomies, payloads, posted payment link types and concurrency implementation are **to be finalized by source module** (no source exists in P1). CUS owns no transactional monetary rows.

## 1. Data ownership / join keys

| Concept | Owner | Required keys / as-of facts | CUS usage |
|---|---|---|---|
| Customer & Contact | CUS / P1 Contact | `customers.id`, `contact_type='CUSTOMER'`,`contact_ref_id` | profile, ship-to book |
| Sales obligations | SAL | `sales_orders.customer_id`, Company, order lines, frozen payable/discount/ship/tax, confirm time, delivery snapshots | confirmed order value/receivable |
| Fulfillment | SAL + INV | Shipment linked order and lines, delivery success instant, posted Sales Issue, partial qty | fulfilled goods value |
| Returns | SAL | source order/line, commercially approved credit amount/time; stock-return POSTED is separate condition | net-sales credit |
| Posted cash | FIN | Company, `money_transactions` receipt/expense, posted/reversed times | receipts/refunds |
| Payment application | FIN | `money_source_links` typed allocation, paid/refunded direction, order ID, amount, company | reduce open-order due |
| COD | SAL/COD/FIN | per-shipment carrier-collected event, provider settlement IDs, money remittance posting | carrier pending, avoid duplication |
| Customer Group price rule | PRC | `customer_group_code` stable, Customer ID, Company, channel, effective time | pricing **not** computed in CUS |
| Files | DOC | owner resource/customer ID, permission, owner Company scope | attachments, no CUS blob table |

## 2. Sales KPIs — definitions fixed at business level

For selected Companies C and interval `[from,to)` by *Company business time*:

1. `confirmed_order_value` = Σ frozen customer-payable order values of valid confirmed orders exactly once by confirmation time. Post-confirmation cancel/partial-cancel policies require explicit correction event definition at SAL gate.
2. `fulfilled_goods_value` = Σ net goods amounts attributable to delivered-and-posted quantities. Both `(shipment delivery confirmed)` AND `(sales issue POSTED)` required, including P1 COMBO leaf allocation; use source line frozen values with deterministic residual rounding on partial fulfillment. No shipment/event double count.
3. `net_sales_operational` = `fulfilled_goods_value − approved_return_sales_credit`; return authorization is **commercial credit** milestone, may differ from physical stock return. Do not subtract cash refund a second time.

**Presentation:** Distinguish order amount including shipping/tax from goods-only fulfilled amount. Product selling amounts after discount/COMBO allocation must be preserved; Sales is responsible for defining exactly which shipping/tax/discount amounts enter each metric, not CUS. If direct pickup no Shipment carrier is used, SAL must specify equivalent confirmed-delivered event + posted Issue and test it.

## 3. Operational receivables — not accounting AR

Initial scope **Direct/Internal identified Customer + postpaid order** only, 1 transaction belongs 1 Company, VND. Each Order o as of instant t:

```text
charge(o,t)    = commercially due amount for fulfilled order as-of t
credit(o,t)    = approved sales return/adjustment credit applied to o by t
paid(o,t)      = valid posted, non-reversed customer receipts financially allocated to o by t
refunded(o,t)  = valid posted, non-reversed refunds of previously applied cash for o by t
net(o,t)       = charge - credit - paid + refunded
open_due(o,t)  = MAX(0, net(o,t))
overpay(o,t)   = MAX(0, -net(o,t))
```

- **NEVER** compute debt as sum(SO) - sum(all Money Receipts). Also not the Finance cash account balance.
- Customer headline = `SUM(open_due)` and `SUM(overpay)` separated **plus** `unapplied_customer_credit` (posted receipts not allocated). No auto-offset between orders without an authorized allocation.
- Balance report `as_of` includes all relevant earlier valid events; activity period filter does not truncate earlier payments for a current balance.
- `due_date` authoritative per payable Order/obligation, Company business date; past-due buckets 1–30,31–60,61–90,>90 days **only positive outstanding**, if no due_date -> `UNKNOWN_DUE_DATE` bucket. Credit limit and order auto-blocking **excluded**.

**Important unresolved technical semantics:** whether charge is created on fulfillment or other commercial milestone for deposits/unfulfilled advance/invoice-less orders; return timing and refunds must form an event-valid as-of history. The above initial formula is *approved design approach*, per-event realization gated at SAL/FIN.

## 4. Payment allocations and refunds (FIN-owned)

Reuse proposed Finance `money_transactions` and `money_source_links`, **do not create CUS ledger**. Design addendum to `money_source_links` must distinguish `REFERENCE` vs `APPLIED_PAYMENT`/`APPLIED_REFUND` (or a different explicitly named type), using positive decimal application amount, link to exact `SALES_ORDER`, Company/customer validation and POSTED/reversal status.

- One posted receipt can be allocated to multiple Sales Orders; one Sales Order can have multiple receipts; sum allocations must not exceed source Money Receipt and per-order payable integrity.
- Concurrent allocations lock posted source and affected Orders; idempotent posting/reversal keys prevent repeats and overapply.
- Refund is **posted cash outflow**; an approved commercial return credit is a different event. Refund only adds back to net position when it reverses previously allocated customer payment; otherwise use separate unapplied-credit settlement logic. No double-count.
- Cash receipts can be unallocated advance: show separately; do not reduce a specific order unless explicitly applied.
- No allocation across Company, Customer, currency, or unknown Customer SO without approved re-link operation.

## 5. COD and marketplace

- **Customer paid carrier**: a confirmed customer-collection event, not automatically Company cash received. Record per Shipment.
- **Carrier payout**: provider settlement and FIN Money Receipt when POSTED, not another Customer collection. `COD carrier pending` = collected customer funds not yet remitted/cleared to Company under provider ledger, subject to approved fee allocation.
- COD customer debt reduction needs explicit verified collection/settlement semantics. Do **not** use FIN carrier remittance to decrease Customer debt a second time.
- Marketplace external Order price/discount snapshot uses `EXTERNAL_CHANNEL`, cannot be repriced by PRC; Customer may be null. Such orders excluded from named Customer aggregates unless authorized explicit linkage.

## 6. PRC — code key compatibility (critical update from P2 v1.0.0)

Legacy P2 draft `customer_groups`, `customer_group_id` foreign keys in `price_list_item_conditions`/`promotion_conditions` **do not match approved CUS decisions**. PRC G3 must replace them with canonical matching on stable **`customer_group_code`**, validate codes against shared source-controlled catalog, retain Company > Group pricing priority and P1 `Product + UOM + Company + Effective Time` invariants. There is no dynamic Customer Group admin API unless separately approved.

The exact schema mapping and Company/Customer/Group/Channel specificity tie-break is still `P2-DEC-012` and must be signed off at PRC gate; do not silently repurpose numeric IDs. Historical orders must snapshot realized prices/discounts and not recompute on Customer group change.

## 7. Data-flow compatibility checklist for module owners

| Owner gate | Required design handoff |
|---|---|
| G1 CUS | customers/Contacts IDs, Group master + Company usage; PBAC `customer_contact` owner and interactions |
| G2 INV | Posted Sales Issue trace and no duplicate movement; source line quantities and Company |
| G3 PRC/SAL | stable group code; monetary snapshot, SO destination snapshot and due date; fulfillment/cancellation states |
| G4 SAL/COD/FIN | delivery confirmation, commercial return credit, typed allocations/refunds, provider settlement and reversal/as-of |
| G1/G4 DOC | original document owner permission and linkage, no own Customer attachment blob |

When a source module has not been implemented/tested, the CUS feature relying on it stays `DEPENDENCY_PENDING` even if its business contract is approved.
