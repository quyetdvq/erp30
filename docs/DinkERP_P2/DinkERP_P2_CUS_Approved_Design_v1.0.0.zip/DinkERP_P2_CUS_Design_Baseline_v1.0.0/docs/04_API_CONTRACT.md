# API Contract — P2-CUS

**Document ID:** P2-CUS-API-001 · **v1.0.0** · **Status:** design approval at functional level, endpoint/schema validation pending `CUS-T-API-01`. **No endpoint P2-CUS exists in ERP v1.9.0.**  
**Baseline conventions:** `GET /api/v1/contacts` P1; error `{error:{code,message,details},meta:{request_id}}`; success `{data,meta}`; collections `{data:[...],meta:{page,page_size,total,request_id}}`; locale vi/en, stable error codes. See P1 OpenAPI `contracts/openapi/openapi.yaml`.

## 1. Core endpoints (G1)

| Method | Path | Permission | Main contract |
|---|---|---|---|
| GET | `/api/v1/customers` | `customer.view` | Filtered paginated Group Master; no Company-private KPIs |
| POST | `/api/v1/customers` | `customer.create` | Create including `all_companies` / `company_ids` atomically |
| GET | `/api/v1/customers/{id}` | `customer.view` | Profile + usage; not implicit Company-private interactions |
| PATCH | `/api/v1/customers/{id}` | `customer.edit` | Mutable master+usage update with audit, no status inline |
| POST | `/api/v1/customers/{id}/actions/set-state` | `customer.setstate` | `{status:"ACTIVE"|"INACTIVE"}` after Workflow transition guards |
| GET | `/api/v1/customers/{id}/interactions?company_id=` | `customer_interaction.view` | Company SQL scope applied before COUNT/LIMIT |
| POST | `/api/v1/customers/{id}/interactions` | `customer_interaction.create` | Append event with authoritative Company ID and server actor |

**Shared Contact:** retain P1 `GET/POST /api/v1/contacts`, `GET/PATCH /api/v1/contacts/{id}`, and `POST .../actions/set-state` with `contact_type=CUSTOMER`, `contact_ref_id=customer.id` after owner extension. Resource is `customer_contact`; no parallel Customer contact table or CRUD endpoint. P1 existing `ORGANIZATION`/`EMPLOYEE` contracts unchanged.

**Customer create body** (normative fields, not executable API):

```json
{"customer_code": "KH001", "name": "ABC", "customer_type": "ORGANIZATION", "customer_group_code": null, "phone": null, "email": null, "tax_code": null, "address": "...", "province_id": 1, "ward_id": 10, "all_companies": false, "company_ids": [7, 9], "primary_contact_id": null}
```

If Auto Numbering `AUTO_REQUIRED` active, `customer_code` is omitted or blank according to the P1 numbering implementation contract; if disabled, valid manual code required. Response includes new `id`, `status`, timestamps and exact stored code. User cannot supply actor/time/status in ordinary PATCH. With ALL mode `company_ids` must be omitted or empty; with LIST mode at least one Company when ACTIVE. `primary_contact_id` ownership validated on every write.

**Error examples (candidate codes, pending exact P1 mapping):** `CUSTOMER_CODE_ALREADY_EXISTS` (409), `CUSTOMER_COMPANY_SCOPE_INVALID` (422), `CUSTOMER_NOT_SELECTABLE` (422), `CUSTOMER_PRIMARY_CONTACT_MISMATCH` (422), `CUSTOMER_CONTACT_NOT_SHIPPABLE` (422), `CUSTOMER_STATE_TRANSITION_INVALID` (422). Error code stable independent vi/en. Route/resource authorization failures follow P1 401/403/404 policy; no ownership existence oracle.

## 2. Deferred read-only endpoints (must not expose before source is ready)

| Method | Path | Required source | Output/Permission |
|---|---|---|---|
| GET | `/api/v1/customers/{id}/transactions?company_ids=&source=&from=&to=&page=` | SAL+FIN | Authorized timeline of orders, shipments, returns, money; each family checks own Resource.Action and Company |
| GET | `/api/v1/customers/{id}/sales-summary?company_ids=&from=&to=` | SAL+INV | `confirmed_order_value`, `fulfilled_goods_value`, `net_sales_operational`, credit/return details; `metric_status` |
| GET | `/api/v1/customers/{id}/receivables?company_ids=&as_of=&page=` | SAL+FIN | Positive open balance per Order, overpayments, unallocated, due/aging, Company/time; `metric_status` |

**Do not create** `POST /customer-groups`, `PUT /customer-addresses`, `POST /customer-debts`, or `GET /customer-balance` as local persistence. The old P2 v1.0.0 endpoints `/customer-groups*`, `/customers/{id}/notes`, `/customers/{id}/history` are **superseded in this CUS contract**. Client migration path must be explicit if any draft client already used those names (P2 code not shipped in v1.9.0).

## 3. Read authorization contract

- Authoritative source Customer ID from persisted Customer, Company from persisted transaction; no client-supplied `organization_id` for privilege escalation.
- For list of Company IDs, intersect with actor's actually readable Companies, and document how explicit unauthorized IDs are handled; **never** silently return Group-wide results. For Company-private interactions, one authoritative Company request is recommended for G1.
- `customer.view` grants Customer Master only; `customer_interaction.view` governs CRM notes; `sales_order.view`, `shipment.view`, `sales_return.view`, `money_receipt.view` (exact resource naming to finalize SAL/FIN) govern source history; dedicated `customer.sales_summary.view` or equivalent design may be needed for aggregate-only permission (security gate T-SEC-02).
- Metric `0` only when source ready and query genuinely returns zero; missing source -> `DEPENDENCY_PENDING`; no permission -> `NOT_AUTHORIZED` or 403 per final API policy; do not expose inferred totals.
- SQL scope before COUNT, SORT, LIMIT; re-authorize each linked source when opened.

## 4. Date, monetary, pagination contracts

- `as_of` is an instant; Company business date derived using P1 Company timezone. `from`/`to` for flows define explicitly half-open interval. Never compute historical `as_of` balance solely from receipts inside requested `from/to`.
- `VND` amounts/quantities encoded as canonical decimal strings, e.g. `"3000000.00"`; no IEEE float and no formatted currency text in API.
- `page>=1`, `page_size` per existing P1 bound; deterministic sort by `(happened_at,id)` for interactions and `(business_at,source_type,source_id)` for unified history.
- `status`/resource/enum identifiers stable, error `message` localized, `request_id` propagated.

**Open technical API items** are listed in `docs/10_OPEN_ITEMS_AND_GATES.md`; the YAML design is parseable but not route-tested or merged into official P1 contract.
