# DinkERP — P2-CUS Design Baseline v1.0.0

**Mốc xác nhận quyết định:** 2026-10-28 · **Tài liệu:** đã chốt 12/12 quyết định nghiệp vụ/kiến trúc CUS theo phương án A và toàn bộ quy tắc bổ sung mục D.  
**Codebase P1:** `erp_v1.9.0.zip` (P1 CLOSED) · **Trạng thái code:** chưa sửa / chưa triển khai P2-CUS.  
**Trạng thái P2-CUS:** `BUSINESS & ARCHITECTURE DECISIONS APPROVED` — chi tiết triển khai liên quan hoặc kỹ thuật còn gate, xem `docs/10_OPEN_ITEMS_AND_GATES.md`.

## Hướng dẫn đọc

1. `docs/00_DECISION_RECORD.md` — quyết định nào đã được duyệt, phạm vi duyệt; không suy diễn thêm.
2. `docs/01_SCOPE_REQUIREMENTS_AND_CHANGE.md` — UR gốc giữ nguyên, CR được duyệt bổ sung chỉ tiêu/công nợ.
3. `docs/02_DOMAIN_FUNCTIONAL_SPEC.md` — trường hợp sử dụng, validation và business invariants.
4. `docs/03_DATABASE_MINIMAL.md` — đúng 3 bảng CUS mới; sử dụng lại Contact/Organization/Province/Ward.
5. `docs/04_API_CONTRACT.md`, `contracts/openapi/p2-cus.design.openapi.yaml` — hợp đồng API tại mức thiết kế, **chưa phải endpoint đang chạy**.
6. `docs/05_UI_UX_CONTRACT.md` — bảng và màn Customer workspace.
7. `docs/06_PBAC_AND_SECURITY.md` — bảo mật, Company/PBAC, SQL scope, liên kết nguồn.
8. `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md` — doanh số, công nợ, COD và tích hợp.
9. `docs/08_DATA_FLOW_AND_LIFECYCLE.md` — state, ship-to snapshot, as-of.
10. `qa/09_TEST_MATRIX.md`, `reference/CUS_TRACEABILITY.csv` — nghiệm thu theo requirement.
11. `docs/10_OPEN_ITEMS_AND_GATES.md` — chưa chốt ở **mức kỹ thuật hoặc module phụ thuộc**; không phủ định 12 quyết định đã chốt.
12. `docs/11_IMPLEMENTATION_HANDOFF.md`, `docs/12_P2_DOCUMENT_SYNC_AMENDMENT.md` — bàn giao và các tệp P2 v1.0.0 cần cập nhật.
13. `reference/` — UR gốc, decision CSV, traceability, nguồn code P1 xác minh; `archive/` — v0.1, v0.2, v0.3 trước khi duyệt.

## Kết luận thiết kế

- **Bảng mới CUS:** `customers`, `customer_company_usages`, `customer_interactions` (**3**). Tên bảng vật lý theo CI4 DBPrefix khi áp dụng.
- **Tái sử dụng** bảng `contacts`, `organizations`, `provinces`, `wards`, PBAC, Auto Numbering, Workflow, audit P1.
- **Không tạo** `customer_groups`, `customer_addresses`, `customer_notes`, bảng doanh số, bảng công nợ hoặc bảng thanh toán trong CUS.
- Customer loại `INDIVIDUAL` hoặc `ORGANIZATION`; `customer_group_code` được quản lý bằng danh mục mã kiểm soát; PRC đảm trách giá.
- CUS Core có thể triển khai trước SAL/FIN nhưng **không nghiệm thu đầy đủ phần lịch sử giao dịch và chỉ số công nợ** cho đến khi module nguồn chạy và kiểm thử tích hợp.
- Mọi khoản tiền là **VND / DECIMAL**, báo cáo theo Company và timezone nghiệp vụ P1.

**Không kèm source application, migrations, SQL thực thi hoặc thao tác cơ sở dữ liệu.** Tất cả tài liệu tạo ra từ P1 v1.9.0 và P2 UR 1.0.15; khác biệt ngoài UR gốc được phân loại thành quyết định đã duyệt hoặc chi tiết còn mở.
