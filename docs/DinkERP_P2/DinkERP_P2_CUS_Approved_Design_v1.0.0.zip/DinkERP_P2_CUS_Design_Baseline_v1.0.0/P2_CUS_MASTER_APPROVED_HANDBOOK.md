# DinkERP P2-CUS — Master Approved Design Handbook v1.0.0

**12/12** quyết định CUS đã được Product Owner chốt theo A; CUS codebase chưa được sửa; 16 technical/downstream items remain OPEN.



---

> Nguồn nội bộ: `docs/00_DECISION_RECORD.md`

# CUS Decision Record — chốt 12/12 phương án A

**Document ID:** P2-CUS-ADR-001 · **Version:** 1.0.0 · **Decision date:** 2026-10-28  
**Approval evidence:** Chủ sở hữu sản phẩm chọn phương án A cho `CUS-X-01`…`CUS-X-12`, đồng ý tất cả quy tắc mục D, không có ghi chú.  
**Status:** `APPROVED — BUSINESS DESIGN`. Không đồng nghĩa schema/API hoặc downstream calculation implementation đều đã đạt QA.

| ID | Quyết định đã duyệt | Dữ liệu/module chịu trách nhiệm |
|---|---|---|
| `CUS-X-01` | Dùng Contact P1 cho nhiều địa chỉ giao hàng | CUS / Contact |
| `CUS-X-02` | Dùng INDIVIDUAL/ORGANIZATION và mã nhóm kiểm soát | CUS |
| `CUS-X-03` | Customer Group Master; giao dịch và nhật ký scoped Company | CUS / PBAC |
| `CUS-X-04` | Ba chỉ tiêu doanh số riêng biệt | SAL / CUS |
| `CUS-X-05` | Doanh số fulfillment cần giao thành công + xuất kho POSTED | SAL / INV |
| `CUS-X-06` | Công nợ vận hành theo Sales Order, không phải AR kế toán | SAL / FIN / CUS |
| `CUS-X-07` | Thu tiền được phân bổ theo Sales Order | FIN |
| `CUS-X-08` | Tách tiền khách trả cho hãng và tiền hãng chuyển Company | SAL / FIN |
| `CUS-X-09` | Có due_date và tuổi nợ; chưa credit limit | SAL / FIN |
| `CUS-X-10` | API và thống kê phân quyền theo từng nguồn dữ liệu | CUS / PBAC |
| `CUS-X-11` | Pricing nằm tại PRC; CUS chỉ cung cấp customer_group_code | PRC |
| `CUS-X-12` | As-of/timezone theo Company và hiệu chỉnh reversal | SAL / FIN / CUS |

## Quy tắc bổ sung mục D đã được duyệt

| Quy tắc | Cách áp dụng |
|---|---|
| Số bảng mới | **3**: `customers`, `customer_company_usages`, `customer_interactions` |
| Customer code | Unique toàn Group; tái sử dụng P1 Auto Numbering nếu bật |
| Mã số thuế | Có search/index, **không UNIQUE** |
| Primary Contact | `primary_contact_id` nullable, owner bắt buộc đúng Customer; không đồng nghĩa địa chỉ giao hàng mặc định |
| Nhiều địa chỉ | Từ các bản ghi P1 `contacts` owner `CUSTOMER`; không `is_shipping_address` |
| Company Usage | `all_companies`/allowlist hiện hành; không tự sửa history |
| Contact interactions | Company-owned, append-only |
| Đơn không xác định Customer | `customer_id=NULL` không được tự ghép Customer theo phone/address/alias |
| Tiền tệ | VND, DECIMAL; không dùng float |
| Customer inactive | Chặn giao dịch mới; lịch sử được phép vẫn xem được |

## Tác động chính thức của việc duyệt

- Chuyển từ 4 bảng CUS draft sang 3 bảng: xóa thiết kế `customer_groups`, thay `customer_notes` bằng `customer_interactions`; bỏ các `shipping_*` trực tiếp trên `customers`.
- Mở rộng Contact P1 bằng `CUSTOMER` owner khi bắt đầu triển khai, không thay đổi owner `ORGANIZATION` và `EMPLOYEE`.
- Khóa **chức năng**: chỉ tiêu sales ba loại, doanh số giao+POSTED, công nợ vận hành theo Sales Order, phân bổ thanh toán, COD collection vs remittance, due_date/aging, as-of và reversal.
- Không tự phê duyệt những chi tiết **chưa được chỉ định**: bộ giá trị `customer_group_code`, SQL PBAC cuối cùng, các status event SAL, settlement provider contract, payment-reversal allocation schema cụ thể. Chúng thuộc gate kỹ thuật/thiết kế module nguồn ở `docs/10_OPEN_ITEMS_AND_GATES.md`.

## Change control

Quyết định bổ sung KPI và công nợ **không được chèn ngược** vào nguyên văn User Requirements 1.0.15. Đăng ký `P2-CUS-CR-001` để quản lý scope tăng thêm. P2 v1.0.0 và tài liệu v0.x giữ làm lịch sử; trong phạm vi CUS quyết định mới tại đây **supersede** mô hình CUS 4 bảng và endpoint customer-groups trước đó. Mọi thay đổi sau này cần version/ADR mới.



---

> Nguồn nội bộ: `docs/01_SCOPE_REQUIREMENTS_AND_CHANGE.md`

# CUS Scope, Requirements và Change Addendum

**Design authority:** UR-CUS-001 / UR-CUS-002 và các P1 invariants trong `00_User_Requirements_v1.0.15.md`. Toàn văn UR gốc đính kèm ở `../reference/UR_CUS_001_002_SOURCE_VERBATIM.md` và `../reference/00_User_Requirements_v1.0.15.md`.

## 1. UR gốc — giữ nguyên hiệu lực

- **UR-CUS-001:** Customer là shared Group Master, code unique, contact/Company Usage/Status, địa chỉ chính và địa chỉ giao hàng, Customer inactive không dùng giao dịch mới nhưng history đọc được.
- **UR-CUS-002:** note/lịch sử liên hệ, lịch sử Sales Order/Shipment/Sales Return/Thu tiền có kiểm tra phân quyền; **không Lead/Opportunity**.
- **Quyết định biểu diễn tương đương được duyệt:** Shipping Address/Province/Ward được lưu ở `contacts` owner `CUSTOMER` thay vì cột shipping trực tiếp trong `customers`. Khi tạo SO lấy snapshot ship-to, không biến Customer thành bộ nhớ duy nhất của Shipping data.

**UR acceptance registry (8 AC):**

| ID | Kiểm chứng |
|---|---|
| `P2-AT-CUS-001-01` | Code unique toàn Group |
| `P2-AT-CUS-001-02` | ALL hoặc Company allowlist |
| `P2-AT-CUS-001-03` | Company không thuộc scope không dùng cho giao dịch mới |
| `P2-AT-CUS-001-04` | Shared Contact 1:N dùng lại từ P1 |
| `P2-AT-CUS-001-05` | Customer inactive không giao dịch mới, vẫn đọc history có quyền |
| `P2-AT-CUS-002-01` | Lưu notes/interaction history |
| `P2-AT-CUS-002-02` | Sales Orders, Shipments, Returns, Receipts theo quyền nguồn |
| `P2-AT-CUS-002-03` | Không Lead/Opportunity |

## 2. Scope bổ sung đã được Product Owner phê duyệt — `P2-CUS-CR-001`

**Lý do:** 2 UR CUS ban đầu không đặc tả KPI doanh số/công nợ, thời điểm ghi nhận, phân bổ tiền, COD và aging. Quyết định `CUS-X-04`…`CUS-X-12` đã chốt *mục tiêu nghiệp vụ*, giữ triển khai và nghiệm thu theo module sở hữu nguồn.

| FR bổ sung | Năng lực / tiêu chí chấp nhận nghiệp vụ | Chủ dữ liệu |
|---|---|---|
| `CUS-ADD-01` | Hiển thị riêng Giá trị đơn xác nhận, Giá trị hàng đã giao và Doanh số vận hành ròng | SAL + INV |
| `CUS-ADD-02` | Value fulfilled chỉ khi đã giao và Stock Issue POSTED; trả hàng chỉ trừ khi credit thương mại được duyệt; partials không double count | SAL / INV |
| `CUS-ADD-03` | Công nợ vận hành theo Company + Customer + Sales Order, phân biệt còn phải thu, thừa tiền và tiền ứng trước; không lập full AR ledger | SAL / FIN |
| `CUS-ADD-04` | Payment allocation N:M, chỉ POSTED/reversal-aware; không cross-Company, Customer hoặc double apply | FIN |
| `CUS-ADD-05` | COD tách trạng thái người mua trả hãng và hãng chuyển doanh nghiệp; settlement không thu khách hai lần | SAL / FIN |
| `CUS-ADD-06` | Có due_date/aging (1–30, 31–60, 61–90, >90); không credit limit, không auto block; không due date => unclassified | SAL / FIN |
| `CUS-ADD-07` | Mọi báo cáo theo authorized Company và quyền nguồn, với `as_of`/timezone/reversal; dependency chưa triển khai -> NOT_AVAILABLE | CUS + nguồn |
| `CUS-ADD-08` | Customer group codes ổn định dùng cho PRC; CUS không lưu/list giá độc lập | CUS / PRC |

**Đây là addendum scope được duyệt qua hội thoại Product Owner, không phải thay thế text UR gốc.** Các kịch bản test chi tiết vẫn cần phê duyệt tại gate của module sở hữu khi biết chính xác state/event/field.

## 3. Scope bị loại

Không có customer-specific AR ledger, invoice journal/GL, tax-compliance AR, dòng tiền FX, hạn mức/khóa tín dụng, Lead/Opportunity/Campaign, bảng Customer Group tự cấu hình, địa chỉ giao hàng riêng, billing process mang tính pháp lý, cache KPI đã materialize, hay bảng copy Sales/Finance vào CUS.

## 4. Sở hữu chức năng và nghiệm thu

- **CUS-G1 Core:** Customer CRUD, Company Usage, Contact ship-to, interaction log, PBAC, UI/API/list, 8 UR acceptance nhưng nhánh UR-CUS-002 liên quan SAL/FIN phải **DEFERRED BY DEPENDENCY**, không được ghi PASS giả.
- **CUS-XMOD:** Phê duyệt contract theo bản thiết kế này; runtime UAT chỉ sau khi INV/SAL/FIN/PRC/DOC module nguồn cần thiết sẵn sàng.
- **CUS-FULL:** Chỉ được đóng toàn bộ khi kiểm thử E2E với data thật trên DEV clone; không có bằng chứng test runtime trong bộ tài liệu này.



---

> Nguồn nội bộ: `docs/02_DOMAIN_FUNCTIONAL_SPEC.md`

# Functional Specification — Customer Core + liên module

**Document ID:** P2-CUS-FRS-001 · **v1.0.0** · **Trạng thái:** chức năng/kiến trúc đã được duyệt, chi tiết tích hợp tương lai gắn gate.

## 1. Customer Master (CUS-C-01..06)

| Use case | Tiền điều kiện / luồng | Hậu điều kiện |
|---|---|---|
| CUS-C-01 Create | Actor có `customer.create` tại Group, validate loại/nhóm, tên/code, main address, chọn ALL hoặc Company allowlist | Tạo Customer 1 lần toàn Group; number P1 nếu bật; transaction atomically tạo usages |
| CUS-C-02 List/search | `customer.view`; query `code/name/phone/email/tax_code/customer_type/group/status`, sort allowlist, paging | Kết quả chỉ gồm Customer actor có thể view; không tự đưa Finance KPI vào danh sách |
| CUS-C-03 Detail/edit | Chỉ được sửa mutable fields, kiểm tra persisted target/permission; reject `status` trong PATCH thông thường | Audit actor/time; uniqueness enforced DB; không renumber historical ID |
| CUS-C-04 Status | Lifecycle `ACTIVE/INACTIVE` với `customer.setstate`; trạng thái qua workflow, không bypass | ACTIVE usable nếu Company eligible; INACTIVE không giao dịch mới, history vẫn đọc |
| CUS-C-05 Company Usage | `all_companies=true` => zero allowlist rows; `false` => ít nhất 1 Company hợp lệ khi ACTIVE; all rows type COMPANY | Thay đổi toàn bộ list trong một DB transaction/lock; không xóa/sửa SO lịch sử |
| CUS-C-06 Shared Contact | Xem/ghi contact owner `CUSTOMER` qua resource `customer_contact`; owner ID immutable | N Customer contacts; `primary_contact_id` chỉ thuộc Customer hiện tại và không phải ship-to default |

**Dữ liệu Customer đề xuất:** `customer_code`, `name`, `customer_type` (`INDIVIDUAL`/`ORGANIZATION`), `customer_group_code`, `phone`, `email`, `tax_code`, địa chỉ chính/Province/Ward, Company scope, status, audit. `tax_code` nonunique; có thể tìm kiếm. `customer_group_code` không được nhận arbitrary code do người dùng gửi; bộ codes nguồn-control và triển khai rollout cần khóa trước code (tham chiếu open item T-01).

**Trạng thái:** `ACTIVE`/`INACTIVE` là trạng thái business được duyệt ở scope cơ bản. Workflow Resource state/transition registrations và status API vẫn tuân P1, không update status bằng generic PATCH.

## 2. Contacts và shipping (CUS-C-07..09)

- Người liên hệ chính là một optional Customer Contact; không bắt buộc phải đủ địa chỉ giao hàng.
- Không cần bảng địa chỉ. Contact `CUSTOMER` + active + name người nhận + phone/mobile + address detail + province/ward active và liên hệ đúng chủ = eligible ship-to.
- Contact chỉ có email/phone vẫn là Contact hợp lệ, **không** eligible ship-to.
- Người nhận giống nhau ở hai địa chỉ được lưu thành hai Contact rows. Không ép dedupe dựa trên tên hoặc số điện thoại.
- Không có ship-to mặc định trong CUS G1; Sales bắt người dùng chọn khi có nhiều địa chỉ. One-off shipping destination cho Sales không tự thêm Contact.
- Marketplace shipping address tự do theo dữ liệu bên ngoài vào Sales snapshot, không tự ghép Contact hay Customer.
- Khi Customer inactive/Company ngoài usage/Contact inactive/owner không đúng thì chặn việc chọn ship-to cho SO mới.
- `customer_contact.view` không tự đủ cho việc tạo Sales Order; cần `sales_order.create` và Company eligibility/PBAC.

## 3. Interactions (CUS-C-10..12)

- Một interaction thuộc **chính xác một** persisted Company (`company_organization_id`) và một Customer; `activity_type` code `NOTE/CALL/EMAIL/MEETING` là bộ mã gợi ý đang cần seed/code-list approve; actor và event time server validated.
- P2 Core lưu tương tác append-only. Correction được ghi một event mới được liên kết audit (schema tối giản không có explicit `corrects_id`; nội dung correction cần tham chiếu ID bản ghi bị sửa và lý do). Không delete/edit overwrite lịch sử cũ.
- Truy vấn `company_id`, date window, `activity_type`, pagination với Company SQL scope **trước** count/sort/limit; không trả thông tin Company B cho actor chỉ có Company A.
- Tác vụ list/export phải có `customer_interaction.view`/`export` riêng; View không suy ra Export.

## 4. Lịch sử giao dịch & báo cáo (CUS-M-01..07; integrated later)

Customer workspace phải truy vấn nguồn live sau khi có module:

| Phần hiển thị | Nguồn / điều kiện |
|---|---|
| Sales Orders | SAL, Customer ID nguồn và Company; không suy diễn Customer từ phone |
| Shipment | SAL Shipment liên kết Order; chỉ hiển thị nếu `shipment.view` + Company authorized |
| Sales Return | SAL return/credit, chỉ accepted state được định nghĩa giảm doanh số |
| Money Receipt/Refund | FIN POSTED, đúng Customer/order link, tránh liên kết thông tin bị coi là thanh toán |
| Order Value | SAL confirmed order snapshot; tính một lần theo Order, không sum theo shipments |
| Fulfilled Goods Value | SAL/INV với Delivery confirmed + Stock Issue POSTED, quantity partial và no duplicates |
| Net Operational Sales | Fulfilled goods value trừ approved commercial return credits, không trừ money refunds hai lần |
| Receivables | SAL obligations + FIN payment allocations/reversals; không tạo bảng `customer_balance` |
| Past Due | Order due_date < business date Company và outstanding dương; missing due_date unclassified |
| COD Pending Carrier | Đã xác nhận carrier thu từ khách nhưng chưa payout, độc lập tiền đã POSTED về account |

**Không dùng `customer.view` duy nhất để đọc Sales/Finance**; permissions theo nguồn và Company trước aggregate. KPI chưa có backend nguồn: `DEPENDENCY_PENDING`/`NOT_AVAILABLE`, không hiển thị số `0`.

## 5. Invariants, edge cases

1. Customer code unique toàn Group, mã số thuế **không** unique. Normalize code theo P1 string identity convention, không tự invent normalizer khác; unique DB vẫn là chốt sau cùng.
2. Một Customer có thể được dùng tại nhiều Company, nhưng mỗi SO, Shipment, Money Receipt/Expense, interaction vẫn đúng một Company owner.
3. Remove usage scope chỉ chặn **giao dịch mới** (không orphan historical reference); historic read do PBAC của từng nguồn quyết định.
4. Shipping Contact không có FK polymorphic tự động tới Customer: owner pair phải được kiểm tra server-side; không cho transfer owner qua PATCH.
5. User-defined shipping destination chỉ xuất hiện khi SAL phê duyệt; snapshot immutable sau confirmation hoặc thay qua action được audit.
6. P2 Core chỉ quản lý quan hệ Customer: không Lead/Opportunity, full AR, credit blocking, invoice/tax ledger, không cross-Company money allocation.
7. Kiểm tra same Company/currency, status, quantity/amount, partial deliveries, idempotency và reversal tại module nguồn, CUS chỉ đọc results.
8. Price List/Pricing Context P2 phải dùng `customer_group_code` làm matching key stable; Customer không tính price.
9. Show linked source only if actor has permission for that resource and Company. Click-through re-authorize independently.

## 6. Lịch phát hành

**Core release (CUS-G1):** CRUD, contact, company scope, interactions, search, PBAC, UI. **XMOD release:** transaction history, doanh số/công nợ/COD khi nguồn INV/SAL/FIN hoàn thành; không giả lập endpoints như đã triển khai.



---

> Nguồn nội bộ: `docs/03_DATABASE_MINIMAL.md`

# Database Design — CUS tối giản 3 bảng

**Document ID:** P2-CUS-DB-001 · **Approved logical design**. Chưa có migration thực thi và chưa kiểm thử MariaDB. Tên logic tuân `DBPrefix` CodeIgniter của dự án; trường hợp cụ thể DB prefixed cần kiểm tra migration khi triển khai.

## 1. ER logical model

```text
organizations (P1, type COMPANY) 1 -- N customer_company_usages N -- 1 customers
customers 1 -- N customer_interactions N -- 1 organizations (COMPANY)
customers 1 -- N contacts (P1: contact_type='CUSTOMER', contact_ref_id=customers.id)
customers 0..1 -- 1 contacts (P1: primary_contact_id, validate owner pair)
customers N -- 1 provinces / wards (P1, optional main address)
[future] customers 1 -- N sales_orders (SAL) -- N money_source_links (FIN via order)
```

## 2. `customers` (new)

| Column | Type (logical) | Null/default | Validation |
|---|---|---|---|
| `id` | BIGINT UNSIGNED auto PK | NOT NULL | Technical key |
| `customer_code` | VARCHAR(50) | NOT NULL | UNIQUE toàn Group, trim/normalize theo P1 + numbering if configured |
| `name` | VARCHAR(255) | NOT NULL | Không rỗng |
| `customer_type` | VARCHAR(20) | NOT NULL | `INDIVIDUAL`, `ORGANIZATION` |
| `customer_group_code` | VARCHAR(50) | NULL | Kiểm tra trong danh mục mã nguồn-controlled; code list seed cần khóa |
| `phone` | VARCHAR(50) | NULL | Plain contact channel, optional |
| `email` | VARCHAR(255) | NULL | Optional; validation theo API contract |
| `tax_code` | VARCHAR(50) | NULL | Chỉ INDEX, **không UNIQUE** |
| `address` | TEXT | NULL | Địa chỉ chính/billing của Customer; không thay địa chỉ SO |
| `province_id` | BIGINT UNSIGNED | NULL | FK provinces.id |
| `ward_id` | BIGINT UNSIGNED | NULL | FK wards.id; nếu có phải thuộc province hợp lệ |
| `primary_contact_id` | BIGINT UNSIGNED | NULL | FK contacts.id; owner `CUSTOMER` và ID khớp; không ship-to default |
| `all_companies` | TINYINT(1) | NOT NULL | ALL nếu `1`, allowlist nếu `0` |
| `status` | VARCHAR(20) | NOT NULL | `ACTIVE`, `INACTIVE`; transition qua Workflow |
| `created_by`, `updated_by` | BIGINT UNSIGNED | NULL | Server actor / seed null |
| `created_at` | DATETIME | NOT NULL | Server-managed |
| `updated_at` | DATETIME | NULL | Server-managed |

**Keys/indexes:** PK(id), UNIQUE(customer_code), INDEX(status,name), INDEX(customer_group_code), INDEX(tax_code), INDEX(all_companies,status). FK province_id/ward_id, primary_contact_id (P1 contacts). Không yêu cầu uniqueness của phone/email/tax. `customer_group_code` không có FK vì catalog code kiểm soát tại application layer.

**Đã loại khỏi thiết kế:** `shipping_address`, `shipping_province_id`, `shipping_ward_id`, `customer_group_id`, company-owned `customer_id` clone, `revenue`, `debt`, balance counters hoặc `current_due`. Contact quản lý các địa chỉ ship-to; các khoản phải thu chỉ là reporting projection.

## 3. `customer_company_usages` (new)

| Column | Type | Constraint |
|---|---|---|
| `customer_id` | BIGINT UNSIGNED | NOT NULL FK `customers.id` |
| `company_organization_id` | BIGINT UNSIGNED | NOT NULL FK `organizations.id`; service verify `type=COMPANY` |

**PK:** `(customer_id, company_organization_id)`; index reversed `(company_organization_id, customer_id)` khi dùng query theo Company. Không có auto id, status, effective dates, audit row; parent customer audit ghi actor/time thay scope.

**Mutation:** `all_companies=1` => zero row; `all_companies=0` và Customer ACTIVE => ít nhất một Company hợp lệ; replace list trong transaction + lock parent row, reject invalid non-COMPANY/duplicate/unknown/inactive Company for new use. `customer_company_usages` chỉ thể hiện eligibility, không phải permission và không back-edit historical orders.

## 4. `customer_interactions` (new)

| Column | Type | Constraint |
|---|---|---|
| `id` | BIGINT UNSIGNED PK auto | NOT NULL |
| `customer_id` | BIGINT UNSIGNED | NOT NULL FK customers.id |
| `company_organization_id` | BIGINT UNSIGNED | NOT NULL FK organizations.id (`COMPANY`) |
| `activity_type` | VARCHAR(30) | NOT NULL controlled code |
| `content` | TEXT | NOT NULL nonblank |
| `happened_at` | DATETIME | NOT NULL; authoritative instant/UTC convention compatible P1 |
| `created_by` | BIGINT UNSIGNED | NULL for approved system actions; otherwise actor |
| `created_at` | DATETIME | NOT NULL |

**Indexes:** `(customer_id,company_organization_id,happened_at,id)`; `(company_organization_id,happened_at)`; immutable append-only. Không có `updated_at`, `deleted_at` cho interactions; correction append một entry mới có nội dung tham chiếu source ID. Không thêm `customer_notes` cạnh tranh.

## 5. P1 reused tables, verified from v1.9.0

| Table | P1 source and integration notes |
|---|---|
| `contacts` | P1 migration `2026-10-05-000002_CreateOrganizationContactTables.php`. Fields owner `contact_type`, `contact_ref_id`; `description`, `name`, `phone`, `mobile`, `email`, `address`, Province/Ward IDs and name snapshots, status/audit. No `organization_id` and no FK to polymorphic owner. Currently owner types `ORGANIZATION`/`EMPLOYEE` only. |
| `organizations` | P1 group/company hierarchy; Company is `type=COMPANY`; only one Group root business scope |
| `provinces`, `wards` | P1 migration `2026-10-05-000001_CreateFoundationLocationTables.php`; FK wards.province_id; historic references retained |
| P1 authorization/numbering/workflow | Reuse Resource Actions, PBAC, Shield, Auto Numbering, Lifecycle; do **not** create alternative persistence |

**Đặc biệt:** `primary_contact_id` FK + polymorphic owner validity **không thể được bảo đảm bằng FK đơn thuần**; service validates `(contact_type='CUSTOMER', contact_ref_id=customers.id)` tại transaction. Kết nối vòng Customer→Contact bằng cách insert customer trước, rồi contact, rồi gán `primary_contact_id`.

## 6. Concurrency, audit and migration contract

1. Migration chỉ **additive** từ ERP P1 v1.9.0; không drop/rename P1 Contact table. P1 existing `CONTACT` owner regression giữ nguyên.
2. Customer creation/numbering and company usages cùng transaction; unique index chống duplicate concurrent code. Numbering rollback cùng transaction khi tạo thất bại.
3. Replace allowlist lock row Customer, reset/replace atomically; checks thực thi tại thời điểm SO create/confirm trong SAL.
4. FK with soft state invariants: không CASCADE hard-delete Customer/Company/Contact khi lịch sử đã tham chiếu.
5. Authorization SQL scope trước COUNT/order/limit. Audit create/update/status/usage mutations; interaction append-only.
6. Dữ liệu *không* có thể reconstruct từ bảng Customer: total revenue, receivable, COD, sales order shipping history — lấy từ nguồn SAL/FIN/ship snapshot.
7. Trước migration: DBA xác nhận exact CI4 DBPrefix, default charset/collation, indexes, FK, timezone, duplicate-code normalization và rollback plan trên DEV clone.

## 7. P2 drafts cần loại bỏ

`customer_groups`, `customer_notes`, Customer `shipping_*`, `customer_company_usages.status`; cả `customer_group_id` FK trong `price_list_item_conditions` và `promotion_conditions` phải được thiết kế lại tại PRC thành code-based matching. Không sửa *source* P1; các entity này mới chỉ ở tài liệu draft P2 v1.0.0.



---

> Nguồn nội bộ: `docs/04_API_CONTRACT.md`

# API Contract — P2-CUS

**Document ID:** P2-CUS-API-001 · **v1.0.0** · **Status:** design approval at functional level, endpoint/schema validation pending `CUS-T-API-01`. **No endpoint P2-CUS exists in ERP v1.9.0.**  
**Baseline conventions:** `GET /api/v1/contacts` P1; error `{error:{code,message,details},meta:{request_id}}`; success `{data,meta}`; collections `{data:[...],meta:{page,page_size,total,request_id}}`; locale vi/en, stable error codes. See P1 OpenAPI `contracts/openapi/openapi.yaml`.

## 1. Core endpoints (G1)

| Method | Path | Permission | Main contract |
|---|---|---|---|
| GET | `/api/v1/customers` | `customer.view` | Filtered paginated Group Master; no Company-private KPIs |
| POST | `/api/v1/customers` | `customer.create` | Create including `all_companies` / `company_ids` atomically |
| GET | `/api/v1/customers/{id}` | `customer.view` | Profile + usage; not implicit Company-private interactions |
| PATCH | `/api/v1/customers/{id}` | `customer.edit` | Mutable master+usage update with audit, no status inline |
| POST | `/api/v1/customers/{id}/actions/set-state` | `customer.setstate` | `{status:"ACTIVE"|"INACTIVE"}` after Workflow transition guards |
| GET | `/api/v1/customers/{id}/interactions?company_id=` | `customer_interaction.view` | Company SQL scope applied before COUNT/LIMIT |
| POST | `/api/v1/customers/{id}/interactions` | `customer_interaction.create` | Append event with authoritative Company ID and server actor |

**Shared Contact:** retain P1 `GET/POST /api/v1/contacts`, `GET/PATCH /api/v1/contacts/{id}`, and `POST .../actions/set-state` with `contact_type=CUSTOMER`, `contact_ref_id=customer.id` after owner extension. Resource is `customer_contact`; no parallel Customer contact table or CRUD endpoint. P1 existing `ORGANIZATION`/`EMPLOYEE` contracts unchanged.

**Customer create body** (normative fields, not executable API):

```json
{"customer_code": "KH001", "name": "ABC", "customer_type": "ORGANIZATION", "customer_group_code": null, "phone": null, "email": null, "tax_code": null, "address": "...", "province_id": 1, "ward_id": 10, "all_companies": false, "company_ids": [7, 9], "primary_contact_id": null}
```

If Auto Numbering `AUTO_REQUIRED` active, `customer_code` is omitted or blank according to the P1 numbering implementation contract; if disabled, valid manual code required. Response includes new `id`, `status`, timestamps and exact stored code. User cannot supply actor/time/status in ordinary PATCH. With ALL mode `company_ids` must be omitted or empty; with LIST mode at least one Company when ACTIVE. `primary_contact_id` ownership validated on every write.

**Error examples (candidate codes, pending exact P1 mapping):** `CUSTOMER_CODE_ALREADY_EXISTS` (409), `CUSTOMER_COMPANY_SCOPE_INVALID` (422), `CUSTOMER_NOT_SELECTABLE` (422), `CUSTOMER_PRIMARY_CONTACT_MISMATCH` (422), `CUSTOMER_CONTACT_NOT_SHIPPABLE` (422), `CUSTOMER_STATE_TRANSITION_INVALID` (422). Error code stable independent vi/en. Route/resource authorization failures follow P1 401/403/404 policy; no ownership existence oracle.

## 2. Deferred read-only endpoints (must not expose before source is ready)

| Method | Path | Required source | Output/Permission |
|---|---|---|---|
| GET | `/api/v1/customers/{id}/transactions?company_ids=&source=&from=&to=&page=` | SAL+FIN | Authorized timeline of orders, shipments, returns, money; each family checks own Resource.Action and Company |
| GET | `/api/v1/customers/{id}/sales-summary?company_ids=&from=&to=` | SAL+INV | `confirmed_order_value`, `fulfilled_goods_value`, `net_sales_operational`, credit/return details; `metric_status` |
| GET | `/api/v1/customers/{id}/receivables?company_ids=&as_of=&page=` | SAL+FIN | Positive open balance per Order, overpayments, unallocated, due/aging, Company/time; `metric_status` |

**Do not create** `POST /customer-groups`, `PUT /customer-addresses`, `POST /customer-debts`, or `GET /customer-balance` as local persistence. The old P2 v1.0.0 endpoints `/customer-groups*`, `/customers/{id}/notes`, `/customers/{id}/history` are **superseded in this CUS contract**. Client migration path must be explicit if any draft client already used those names (P2 code not shipped in v1.9.0).

## 3. Read authorization contract

- Authoritative source Customer ID from persisted Customer, Company from persisted transaction; no client-supplied `organization_id` for privilege escalation.
- For list of Company IDs, intersect with actor's actually readable Companies, and document how explicit unauthorized IDs are handled; **never** silently return Group-wide results. For Company-private interactions, one authoritative Company request is recommended for G1.
- `customer.view` grants Customer Master only; `customer_interaction.view` governs CRM notes; `sales_order.view`, `shipment.view`, `sales_return.view`, `money_receipt.view` (exact resource naming to finalize SAL/FIN) govern source history; dedicated `customer.sales_summary.view` or equivalent design may be needed for aggregate-only permission (security gate T-SEC-02).
- Metric `0` only when source ready and query genuinely returns zero; missing source -> `DEPENDENCY_PENDING`; no permission -> `NOT_AUTHORIZED` or 403 per final API policy; do not expose inferred totals.
- SQL scope before COUNT, SORT, LIMIT; re-authorize each linked source when opened.

## 4. Date, monetary, pagination contracts

- `as_of` is an instant; Company business date derived using P1 Company timezone. `from`/`to` for flows define explicitly half-open interval. Never compute historical `as_of` balance solely from receipts inside requested `from/to`.
- `VND` amounts/quantities encoded as canonical decimal strings, e.g. `"3000000.00"`; no IEEE float and no formatted currency text in API.
- `page>=1`, `page_size` per existing P1 bound; deterministic sort by `(happened_at,id)` for interactions and `(business_at,source_type,source_id)` for unified history.
- `status`/resource/enum identifiers stable, error `message` localized, `request_id` propagated.

**Open technical API items** are listed in `docs/10_OPEN_ITEMS_AND_GATES.md`; the YAML design is parseable but not route-tested or merged into official P1 contract.



---

> Nguồn nội bộ: `docs/05_UI_UX_CONTRACT.md`

# UI/UX Contract — Customer workspace tối giản

**Document ID:** P2-CUS-UI-001 · **v1.0.0**. Không phải screenshot, không phải UI đã code. Sử dụng shell, locale `vi/en`, Display Settings và table patterns của P1.

## 1. Route và screens

| UI ID | Route | Core status | Nội dung |
|---|---|---|---|
| `CUS-UI-01` | `/customers` | CUS-G1 | Search + table + sort/page/filter, create action |
| `CUS-UI-02` | `/customers/new` | CUS-G1 | Customer type, code/name/group, main address, Company ALL/list; create/validation |
| `CUS-UI-03` | `/customers/:id` | CUS-G1 + progressive | Workspace gồm tab Profile, Contact/Ship-to, Interactions; tabs Sales/Payments/Shipping trạng thái dependency |
| `CUS-UI-04` | `/customers/:id/edit` | CUS-G1 | Edit details/company allowlist, primary Contact, status riêng |

Không tạo `/customer-groups` UI; không tạo 6 bảng hoặc 6 SPA module vì có nhiều tab. Dùng layout/components P1 và permission-based actions; route exact spelling chốt trong router implementation review.

## 2. Danh sách Customer

Cột mặc định: customer_code, name, customer_type, group_code, phone, status, all_companies/Company count; không show amounts / note company-private trong Group list. Search theo code/name/tax/phone/email; filter type/group/status/Company eligibility; export chỉ nếu `customer.export` được phép. Không lọc dữ liệu nhạy cảm sau paginate.

## 3. Detail/workspace

| Tab | Trạng thái | UI behavior |
|---|---|---|
| Hồ sơ | CUS-G1 | Group Master, địa chỉ chính, MST, group/status, Company usage |
| Người liên hệ / Điểm giao hàng | CUS-G1 | Multiple P1 Contacts owner CUSTOMER; badge eligible/ineligible + lý do; primary contact không phải default ship-to |
| Nhật ký chăm sóc | CUS-G1 | Notes, calls, emails, meetings theo Company selector actor được xem; tạo append-only; không cho sửa silent history |
| Đơn hàng & Doanh số | SAL/INV later | Order history + 3 KPI riêng, Company/kỳ filter; thiếu nguồn => `NOT_AVAILABLE` |
| Thu tiền & Công nợ | FIN/SAL later | Posted receipts, allocated payments, open balance, overpayment, unapplied, aging; tách COD |
| Giao hàng & Trả hàng | SAL later | Shipments/tracking/return, links và permission per source |
| Tài liệu | DOC later | Attachments qua Document owner authorization; không fork storage |

**Điều kiện hiển thị:** source chưa triển khai => `DEPENDENCY_PENDING`, actor không có permission => `NOT_AUTHORIZED`/ẩn section theo UX policy; metric có dữ liệu hợp lệ bằng 0 => `READY` với value 0. Không show `0` giả khi không có tính toán.

## 4. Ship-to selector ở Sales (contract cho SAL)

`Sales Company → Customer ACTIVE+eligible → Contacts of CUSTOMER → computed ship-to eligible → explicit selection (multiple) → preview recipient/phone/address/province/ward → frozen SO snapshot`. No default in G1, no `is_shipping_address` flag, no live dereference after confirmation; record change only through audited Sales action if approved. Marketplace external address snapshot không tự ghi thành Contact.

## 5. Localization/presentation/security

- `Accept-Language: vi/en` theo workspace preference; mã code/status không dịch; number/date hiển thị qua Display Settings, calculation server DECIMAL + business timezone theo Company.
- Group-level Customer Data không được nhúng vào list Company Sales như aggregate vượt scope. Company selections chỉ bao gồm allowed Company IDs actor authorized.
- Khi backend báo unauthorized/dependency pending, frontend không cố tự tổng hợp hoặc lộ count/amount qua tooltip, pagination, export hay navigation.
- Error code stable, message localized; giữ form draft khi server conflict unique/scope.



---

> Nguồn nội bộ: `docs/06_PBAC_AND_SECURITY.md`

# PBAC, Identity, Company Scope và Audit — CUS

**Document ID:** P2-CUS-SEC-001 · **P1 contract inherited, P2 resource additions are design-approved conceptually, technical seeding pending.**

## 1. Security boundaries

- `customer` là Group Master: authorize canonical `GROUP` for shared create/update/view/setstate. Company list is business *eligibility for new transactions*, **not** authorization.
- `customer_interaction` thuộc `COMPANY` persisted, authorize at `company_organization_id`. Multiple Company access only if actor permitted per Company; no cross-Company lane merge.
- `customer_contact` uses existing P1 Contact resource approach extended to owner `CUSTOMER`; owner `(contact_type, contact_ref_id)` authoritative, immutable, not inferred from request context.
- `customer.sales_summary`/financial summary authorization requires both aggregate-level policy (if introduced) and the underlying source Data Resource/Action/Company filter. `customer.view` does not grant finance data.
- No System Admin bypass; Shield User→Employee→effective Assignment→PBAC base permission/policy. Inheritance `GROUP`→exact ancestor; `ABSOLUTE_DENY` propagated as P1.

## 2. Candidate Resource/Action catalog

| Resource | Actions proposed | Evaluation Organization |
|---|---|---|
| `customer` | `view/create/edit/setstate/export` | GROUP for Group Master |
| `customer_contact` | `view/create/edit/setstate` | Trusted Customer owner context; exact GROUP/Company resolution still technical gate |
| `customer_interaction` | `view/create/export` | Saved `company_organization_id` type COMPANY |
| Customer KPI reader | `view` or specific metric-view action TBD | Authorized Company/source, not Group blanket |
| `sales_order`, `shipment`, `sales_return`, `money_receipt` | Source `view` and `export` as configured | Persisted source Company per P2 module |

No new permission table. Catalog ResourceAction registered using P1 Resource/Action registry and approved Group assignments/Policy. ACTION `export` is independent of `view`.

## 3. Contact P1 modification boundary

Verified source: `backend/app/Modules/Contact/ContactRules.php` has exactly `ORGANIZATION`/`EMPLOYEE`; `ContactScope.php` chooses Organization or effective Employee Primary; `ContactScopeProvider.php` only supports `organization_contact` and `employee_contact`; `ContactSql.php` compiles SQL authorization predicates for those two branches. Thus `CUSTOMER` requires all four coordinated changes plus controller/service/read tests and seed of ResourceAction/Workflow. Inserting `contact_type='CUSTOMER'` alone is invalid.

For Customer contact owner, authoritative `customers.id` exists, resource `customer_contact`, Organization evaluation cannot come from request/client hint. P1 Contact SQL list includes authorized organization/employee branches; new Customer branch must be integrated **before** filtering/pagination. Security design must explicitly address whether Contact entries are Group-shared or Company-restricted (no `company_id` exists in P1 contacts). This detail is **still open** under `CUS-T-SEC-01`; no invented implicit access.

## 4. Interaction SQL scope and negative cases

Authorized filter minimum: `customer_id=target` and `company_organization_id IN permitted-company-ids` and the actor has `customer_interaction.view` at each Company. Reject untrusted `company_id` not type COMPANY, not allowed or outside Customer usage for **new** event. No count leak, no ordering/projection leak, no export leak. For historical records, current usage scope changes should not delete history; final historical read scope solely PBAC.

On primary Contact update, stored Contact must have `contact_type='CUSTOMER' AND contact_ref_id=customer.id`, regardless of permission to another Customer. Contact routing must not grant Customer permission through `employee_contact`/`organization_contact`. Wrong-owner/foreign Company source -> deny, no partial writes.

## 5. Access to SAL/FIN data

1. Apply Company and Resource view permissions **before** constructing list/aggregate.
2. If actor may view `sales_order` but not `money_receipt`, show order summary only; receipt and receivable totals suppressed when not faithfully computable without finance data.
3. Unknown/deferred source => `DEPENDENCY_PENDING`; denied source => not authorized, never `0`.
4. Per-source navigation/external documents enforce permission again at access time; do not use CUS fetch as authorization token.
5. Request/user/employee context, actor/timestamp and decision reason follow P1 audit and error convention; note contents potentially personal data, apply least privilege.

## 6. Security test matrix highlights

- Company A-only role cannot access B interactions using list, direct ID, sort pagination, count, export or summary.
- Base permission missing=>deny even if Policy ALLOW; `ABSOLUTE_DENY` cannot be opened through assignment lanes.
- Contacts owner spoofing, primary-contact mismatch, status bypass, context hint mismatch rejected; Organization/Employee contact regression remains PASS.
- Master Group access must not accidentally expose Company-private financial data; query-level SQL scoped and negative tests.



---

> Nguồn nội bộ: `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md`

# Liên module — SAL / INV / FIN / PRC / DOC / COD

**Document ID:** P2-CUS-XMOD-002 · **Business-level decisions APPROVED.** Exact status taxonomies, payloads, posted payment link types and concurrency implementation are **to be finalized by source module** (no source exists in P1). CUS owns no transactional monetary rows.

## 1. Data ownership / join keys

| Concept | Owner | Required keys / as-of facts | CUS usage |
|---|---|---|---|
| Customer & Contact | CUS / P1 Contact | `customers.id`, `contact_type='CUSTOMER'`,`contact_ref_id` | profile, ship-to book |
| Sales obligations | SAL | `sales_orders.customer_id`, Company, order lines, frozen payable/discount/ship/tax, confirm time, delivery snapshots | confirmed order value/receivable |
| Fulfillment | SAL + INV | Shipment linked order and lines, delivery success instant, posted Sales Issue, partial qty | fulfilled goods value |
| Returns | SAL | source order/line, commercially approved credit amount/time; stock-return POSTED is separate condition | net-sales credit |
| Posted cash | FIN | Company, `money_transactions` receipt/expense, posted/reversed times | receipts/refunds |
| Payment application | FIN | `money_source_links` typed allocation, paid/refunded direction, order ID, amount, company | reduce open-order due |
| COD | SAL/COD/FIN | per-shipment carrier-collected event, provider settlement IDs, money remittance posting | carrier pending, avoid duplication |
| Customer Group price rule | PRC | `customer_group_code` stable, Customer ID, Company, channel, effective time | pricing **not** computed in CUS |
| Files | DOC | owner resource/customer ID, permission, owner Company scope | attachments, no CUS blob table |

## 2. Sales KPIs — definitions fixed at business level

For selected Companies C and interval `[from,to)` by *Company business time*:

1. `confirmed_order_value` = Σ frozen customer-payable order values of valid confirmed orders exactly once by confirmation time. Post-confirmation cancel/partial-cancel policies require explicit correction event definition at SAL gate.
2. `fulfilled_goods_value` = Σ net goods amounts attributable to delivered-and-posted quantities. Both `(shipment delivery confirmed)` AND `(sales issue POSTED)` required, including P1 COMBO leaf allocation; use source line frozen values with deterministic residual rounding on partial fulfillment. No shipment/event double count.
3. `net_sales_operational` = `fulfilled_goods_value − approved_return_sales_credit`; return authorization is **commercial credit** milestone, may differ from physical stock return. Do not subtract cash refund a second time.

**Presentation:** Distinguish order amount including shipping/tax from goods-only fulfilled amount. Product selling amounts after discount/COMBO allocation must be preserved; Sales is responsible for defining exactly which shipping/tax/discount amounts enter each metric, not CUS. If direct pickup no Shipment carrier is used, SAL must specify equivalent confirmed-delivered event + posted Issue and test it.

## 3. Operational receivables — not accounting AR

Initial scope **Direct/Internal identified Customer + postpaid order** only, 1 transaction belongs 1 Company, VND. Each Order o as of instant t:

```text
charge(o,t)    = commercially due amount for fulfilled order as-of t
credit(o,t)    = approved sales return/adjustment credit applied to o by t
paid(o,t)      = valid posted, non-reversed customer receipts financially allocated to o by t
refunded(o,t)  = valid posted, non-reversed refunds of previously applied cash for o by t
net(o,t)       = charge - credit - paid + refunded
open_due(o,t)  = MAX(0, net(o,t))
overpay(o,t)   = MAX(0, -net(o,t))
```

- **NEVER** compute debt as sum(SO) - sum(all Money Receipts). Also not the Finance cash account balance.
- Customer headline = `SUM(open_due)` and `SUM(overpay)` separated **plus** `unapplied_customer_credit` (posted receipts not allocated). No auto-offset between orders without an authorized allocation.
- Balance report `as_of` includes all relevant earlier valid events; activity period filter does not truncate earlier payments for a current balance.
- `due_date` authoritative per payable Order/obligation, Company business date; past-due buckets 1–30,31–60,61–90,>90 days **only positive outstanding**, if no due_date -> `UNKNOWN_DUE_DATE` bucket. Credit limit and order auto-blocking **excluded**.

**Important unresolved technical semantics:** whether charge is created on fulfillment or other commercial milestone for deposits/unfulfilled advance/invoice-less orders; return timing and refunds must form an event-valid as-of history. The above initial formula is *approved design approach*, per-event realization gated at SAL/FIN.

## 4. Payment allocations and refunds (FIN-owned)

Reuse proposed Finance `money_transactions` and `money_source_links`, **do not create CUS ledger**. Design addendum to `money_source_links` must distinguish `REFERENCE` vs `APPLIED_PAYMENT`/`APPLIED_REFUND` (or a different explicitly named type), using positive decimal application amount, link to exact `SALES_ORDER`, Company/customer validation and POSTED/reversal status.

- One posted receipt can be allocated to multiple Sales Orders; one Sales Order can have multiple receipts; sum allocations must not exceed source Money Receipt and per-order payable integrity.
- Concurrent allocations lock posted source and affected Orders; idempotent posting/reversal keys prevent repeats and overapply.
- Refund is **posted cash outflow**; an approved commercial return credit is a different event. Refund only adds back to net position when it reverses previously allocated customer payment; otherwise use separate unapplied-credit settlement logic. No double-count.
- Cash receipts can be unallocated advance: show separately; do not reduce a specific order unless explicitly applied.
- No allocation across Company, Customer, currency, or unknown Customer SO without approved re-link operation.

## 5. COD and marketplace

- **Customer paid carrier**: a confirmed customer-collection event, not automatically Company cash received. Record per Shipment.
- **Carrier payout**: provider settlement and FIN Money Receipt when POSTED, not another Customer collection. `COD carrier pending` = collected customer funds not yet remitted/cleared to Company under provider ledger, subject to approved fee allocation.
- COD customer debt reduction needs explicit verified collection/settlement semantics. Do **not** use FIN carrier remittance to decrease Customer debt a second time.
- Marketplace external Order price/discount snapshot uses `EXTERNAL_CHANNEL`, cannot be repriced by PRC; Customer may be null. Such orders excluded from named Customer aggregates unless authorized explicit linkage.

## 6. PRC — code key compatibility (critical update from P2 v1.0.0)

Legacy P2 draft `customer_groups`, `customer_group_id` foreign keys in `price_list_item_conditions`/`promotion_conditions` **do not match approved CUS decisions**. PRC G3 must replace them with canonical matching on stable **`customer_group_code`**, validate codes against shared source-controlled catalog, retain Company > Group pricing priority and P1 `Product + UOM + Company + Effective Time` invariants. There is no dynamic Customer Group admin API unless separately approved.

The exact schema mapping and Company/Customer/Group/Channel specificity tie-break is still `P2-DEC-012` and must be signed off at PRC gate; do not silently repurpose numeric IDs. Historical orders must snapshot realized prices/discounts and not recompute on Customer group change.

## 7. Data-flow compatibility checklist for module owners

| Owner gate | Required design handoff |
|---|---|
| G1 CUS | customers/Contacts IDs, Group master + Company usage; PBAC `customer_contact` owner and interactions |
| G2 INV | Posted Sales Issue trace and no duplicate movement; source line quantities and Company |
| G3 PRC/SAL | stable group code; monetary snapshot, SO destination snapshot and due date; fulfillment/cancellation states |
| G4 SAL/COD/FIN | delivery confirmation, commercial return credit, typed allocations/refunds, provider settlement and reversal/as-of |
| G1/G4 DOC | original document owner permission and linkage, no own Customer attachment blob |

When a source module has not been implemented/tested, the CUS feature relying on it stays `DEPENDENCY_PENDING` even if its business contract is approved.



---

> Nguồn nội bộ: `docs/08_DATA_FLOW_AND_LIFECYCLE.md`

# Data Flow, state/lifecycle và tính lịch sử

**Document ID:** P2-CUS-FLOW-001 · **v1.0.0** · **Source control only; not runtime tested**.

## 1. Customer creation

```text
User authenticated -> authorize(customer.create@GROUP) -> normalize/validate Customer
 -> validate Customer Type / group code / main Province-Ward
 -> resolve Company ALL or allowlist (Organizations type COMPANY)
 -> begin transaction (+ P1 numbering if active)
 -> insert customers -> insert usages (when LIST) -> audit -> commit
```

- Fails at any step => rollback Customer/usage/number allocation together.
- `customer_code` unique across Group, including concurrent create; `tax_code` nonunique.
- `status` initially configured lifecycle state, no client arbitrarily choosing state.

## 2. Status/usage change

**Status:** only approved Workflow transition through `customer.setstate`; one transition at a time, PBAC re-evaluated on persisted target. `INACTIVE` cannot be chosen on *new* Orders; changing status never erases historical orders/notes.

**Company usage:** `ALL=true` -> no usage rows; `ALL=false` -> one or more Company IDs when Customer ACTIVE. Permission on shared Customer still independent of Company business eligibility. A currently existing SO belonging removed Company remains linked to Customer and governed by Sales authorization/history rules.

## 3. Contact-as-ship-to

```text
Customer selected for Company C
 -> verify Customer ACTIVE and eligible at C
 -> fetch Contacts (CUSTOMER owner, persisted ID, permitted by PBAC)
 -> computed shippable: ACTIVE + name + phone/mobile + address + active valid Province/Ward
 -> choose Contact (no default) -> validate again in Sales server transaction
 -> SNAPSHOT recipient/address/phone/Province/Ward into Sales Order
 -> confirm; later Contact edits do NOT mutate SO/Shipment labels
```

If a carrier or recipient change is necessary after confirmation, SAL must implement an audited business action and possibly a Shipment snapshot. A SO initially has one destination; multi-destination requires separate Sales design. Marketplace external order address snapshots do not imply Customer Contact creation.

## 4. Interactions

`customer_interaction.create` with authoritative Customer and Company -> append once (server actor/time). Read with SQL PBAC restricted Company before page/total; corrections append another event, not edit/delete silent history. No independent Company ownership table for Contact.

## 5. Sales/Finance event projection

```text
Confirmed SO (frozen price+customer+company) ----> confirmed_order_value
Delivery success AND posted Sales Issue -------> fulfilled_goods_value
Approved commercial return credit -------------> net_sales_operational decreases
Posted FIN receipt with order allocation ------> paid(o,t) decreases receivable
Posted refund undoing applied payment ---------> refunded(o,t) increases receivable position
Carrier confirmed COD collection --------------> customer collection state (separate)
Carrier payout + posted FIN receipt -----------> business cash received; NOT another customer payment
```

- Time is authoritative instant; business date per **transaction Company** timezone P1.
- As-of replay requires events/reversal and effective times retained by SAL/FIN. If only current mutable status is stored, historical query as-of cannot be certified; this is an integration test blocker.
- Do not read `status` from presentation settings. Do not mix future settlement/remittance amounts with Customer received.

## 6. Deletion / retention

No hard delete Customer with references. `customer_interactions` append-only. P1 Contact retains history on inactive/closed. Posted Sales Issue/Receipt adjustments happen with reversal/correction links. Underlying audit retention and data privacy rules from P1/P2 operational policy still apply; no arbitrary permanent deletion in UI.



---

> Nguồn nội bộ: `qa/09_TEST_MATRIX.md`

# P2-CUS — UAT/QA Checklist (chưa thực thi)

**Document ID:** P2-CUS-QA-001 · **v1.0.0** · **Status: NOT RUN.** Không có kết quả HTTP/DB/FE thật trong hồ sơ.  
**Phạm vi:** đủ 8 acceptance criteria gốc và 8 nhóm acceptance của change `P2-CUS-CR-001`.  
**Data:** fixture riêng cho Group, Company A/B, User A-only, User with GROUP assignment, Customer ACTIVE/INACTIVE, 2 địa chỉ hợp lệ và 1 contact-only, SO fulfillment partial, Posted/non-posted Money, reversal/COD.

## Coverage

| Requirement | Tên ngắn | Test cases |
|---|---|---|
| `P2-AT-CUS-001-01` | Customer Code global unique | CUS-TC-001, CUS-TC-002, CUS-TC-047 |
| `P2-AT-CUS-001-02` | Company ALL/list | CUS-TC-003, CUS-TC-004, CUS-TC-045 |
| `P2-AT-CUS-001-03` | Company out of usage no new transaction | CUS-TC-005 |
| `P2-AT-CUS-001-04` | Shared Contact multiple | CUS-TC-006, CUS-TC-007, CUS-TC-008, CUS-TC-039, CUS-TC-040, CUS-TC-041, CUS-TC-044 |
| `P2-AT-CUS-001-05` | Inactive and historic access | CUS-TC-009, CUS-TC-042 |
| `P2-AT-CUS-002-01` | Note/contact history | CUS-TC-010, CUS-TC-011 |
| `P2-AT-CUS-002-02` | Source transaction history authorized | CUS-TC-012, CUS-TC-013 |
| `P2-AT-CUS-002-03` | No Lead or Opportunity | CUS-TC-014 |
| `CUS-ADD-01` | Three distinct sales KPIs | CUS-TC-015, CUS-TC-016 |
| `CUS-ADD-02` | Delivered and POSTED, return commercial credits | CUS-TC-017, CUS-TC-018, CUS-TC-019, CUS-TC-020 |
| `CUS-ADD-03` | Order-level receivables | CUS-TC-021, CUS-TC-022, CUS-TC-043 |
| `CUS-ADD-04` | N:M money allocation, refunds/reversals | CUS-TC-023, CUS-TC-024, CUS-TC-025, CUS-TC-026 |
| `CUS-ADD-05` | COD customer pay vs provider remittance | CUS-TC-027, CUS-TC-028, CUS-TC-029 |
| `CUS-ADD-06` | Due date / aging no credit limit | CUS-TC-030, CUS-TC-031, CUS-TC-032 |
| `CUS-ADD-07` | Source permission, as-of and availability | CUS-TC-033, CUS-TC-034, CUS-TC-035, CUS-TC-036, CUS-TC-048 |
| `CUS-ADD-08` | Controlled group code PRC matching | CUS-TC-037, CUS-TC-038, CUS-TC-046 |

## Test case registry

| ID | Requirement | Gate | Scenario | Expected | Runtime |
|---|---|---|---|---|---|
| `CUS-TC-001` | `P2-AT-CUS-001-01` | CUS-G1 | Customer code duplicate within same Company vs different Company | Second create rejected; exactly one Group customer | NOT_RUN |
| `CUS-TC-002` | `P2-AT-CUS-001-01` | CUS-G1 | Two concurrent creates with same code | Exactly one commit; unique integrity; no orphan scope | NOT_RUN |
| `CUS-TC-003` | `P2-AT-CUS-001-02` | CUS-G1 | all_companies=true with no usage rows | Any active Company eligible subject to Sales PBAC | NOT_RUN |
| `CUS-TC-004` | `P2-AT-CUS-001-02` | CUS-G1 | all_companies=false Company A+B, empty/invalid/duplicate allowlist | Atomic, only valid distinct COMPANY IDs accepted | NOT_RUN |
| `CUS-TC-005` | `P2-AT-CUS-001-03` | CUS+SAL | Company C not in allowlist creates SO | Reject at server even if frontend is bypassed | NOT_RUN |
| `CUS-TC-006` | `P2-AT-CUS-001-04` | CUS-G1 | Three valid ship-to Contacts per Customer | All three selectable, no new customer_addresses | NOT_RUN |
| `CUS-TC-007` | `P2-AT-CUS-001-04` | CUS-G1 | Contact has email only/no address | Contact readable but not shipping-eligible | NOT_RUN |
| `CUS-TC-008` | `P2-AT-CUS-001-04` | CUS+SAL | Contact owner is another Customer/EMPLOYEE | Cannot select for this Customer; no spoof | NOT_RUN |
| `CUS-TC-009` | `P2-AT-CUS-001-05` | CUS+SAL | Customer made INACTIVE after historic SO | New SO rejected; old SO still readable under SAL scope | NOT_RUN |
| `CUS-TC-010` | `P2-AT-CUS-002-01` | CUS-G1 | Company A NOTE and Company B CALL; actor A only | B note absent from list/COUNT/export/paging | NOT_RUN |
| `CUS-TC-011` | `P2-AT-CUS-002-01` | CUS-G1 | Attempt to silently edit or delete a past interaction | Write rejected; corrective append retains original | NOT_RUN |
| `CUS-TC-012` | `P2-AT-CUS-002-02` | CUS+SAL+FIN | Only sales_order.view allowed, no money_receipt.view | Order visible; receipts/finance sums suppressed | NOT_RUN |
| `CUS-TC-013` | `P2-AT-CUS-002-02` | CUS+SAL+FIN | Company A actor reads combined Group Customer history A+B | Only authorized source records after SQL Company filtering | NOT_RUN |
| `CUS-TC-014` | `P2-AT-CUS-002-03` | CUS-G1 | Inspect CUS UI/resource/table catalog | No Lead/Opportunity pipeline or CRUD | NOT_RUN |
| `CUS-TC-015` | `CUS-ADD-01` | SAL+INV | Confirmed order value, shipped part, returned part | Three distinct KPIs; correct values and cutoff dates | NOT_RUN |
| `CUS-TC-016` | `CUS-ADD-01` | SAL | Order cancelled pre-fulfillment | No fulfilled value; confirmed value handling uses authoritative cancellation policy | NOT_RUN |
| `CUS-TC-017` | `CUS-ADD-02` | SAL+INV | Shipment delivered but Sales Issue not POSTED | No fulfilled amount yet | NOT_RUN |
| `CUS-TC-018` | `CUS-ADD-02` | SAL+INV | Sales Issue POSTED, Shipment not delivered | No fulfilled amount yet | NOT_RUN |
| `CUS-TC-019` | `CUS-ADD-02` | SAL+INV | Partial delivery and duplicate carrier callback | Only posted+delivered valid portion; no duplicate values | NOT_RUN |
| `CUS-TC-020` | `CUS-ADD-02` | SAL | Commercial credit approved but stock return not POSTED yet | Net sales decreases only per approved commercial credit event | NOT_RUN |
| `CUS-TC-021` | `CUS-ADD-03` | SAL+FIN | Payable 12m, approved credit 2m, paid allocation 7m | Open 3m VND, no AR/GL table | NOT_RUN |
| `CUS-TC-022` | `CUS-ADD-03` | FIN | Overpayment and unapplied receipt | Separate overpay/open due/unapplied buckets, not hide negative position | NOT_RUN |
| `CUS-TC-023` | `CUS-ADD-04` | FIN | One POSTED receipt allocated to two SOs | Total allocated <= posted amount, correct Company/customer | NOT_RUN |
| `CUS-TC-024` | `CUS-ADD-04` | FIN | Two POSTED receipts allocated to one SO | Correct sum; no double apply; concurrent lock | NOT_RUN |
| `CUS-TC-025` | `CUS-ADD-04` | FIN | Unposted/void/reversed receipt allocated | Not counted; linkage refused or reversed consistently | NOT_RUN |
| `CUS-TC-026` | `CUS-ADD-04` | FIN | Posted customer refund against prior allocated cash | net(o,t) corrected without duplicate commercial credit | NOT_RUN |
| `CUS-TC-027` | `CUS-ADD-05` | SAL+FIN | Carrier collected COD; Company not yet remitted | Customer collection distinct from cash in bank; carrier pending | NOT_RUN |
| `CUS-TC-028` | `CUS-ADD-05` | SAL+FIN | Carrier payout and FIN posted receipt | Carrier pending decreases; Customer debt not reduced twice | NOT_RUN |
| `CUS-TC-029` | `CUS-ADD-05` | SAL+FIN | Marketplace order unknown customer_id | Not attributed to named Customer; no phone-based join | NOT_RUN |
| `CUS-TC-030` | `CUS-ADD-06` | SAL+FIN | Order due_date missing, positive balance | UNKNOWN_DUE_DATE, not overdue | NOT_RUN |
| `CUS-TC-031` | `CUS-ADD-06` | SAL+FIN | Due date -1,-30,-31,-60,-61,-90,-91 days | Buckets 1–30,31–60,61–90,>90 correct Company business date | NOT_RUN |
| `CUS-TC-032` | `CUS-ADD-06` | CUS-G1 | Customer UI tries credit limit feature | Not present; new credit blocking not enabled | NOT_RUN |
| `CUS-TC-033` | `CUS-ADD-07` | CUS-G1 | Sales dependency not installed | Metric tagged DEPENDENCY_PENDING, not value 0 | NOT_RUN |
| `CUS-TC-034` | `CUS-ADD-07` | CUS+SAL+FIN | Denied one financial source permission | No hidden sums/count leak; NOT_AUTHORIZED | NOT_RUN |
| `CUS-TC-035` | `CUS-ADD-07` | SAL+FIN | As-of date before later receipt/refund/reversal | Historical value computed from valid past events only | NOT_RUN |
| `CUS-TC-036` | `CUS-ADD-07` | SAL+FIN | Period report vs as-of past payments and timezone midnight | Flow period and position as_of not mixed; Company timezone | NOT_RUN |
| `CUS-TC-037` | `CUS-ADD-08` | CUS+PRC | Pricing uses controlled code, group change after SO | No Customer Group FK required; historic SO price frozen | NOT_RUN |
| `CUS-TC-038` | `CUS-ADD-08` | CUS-G1 | Unknown customer_group_code posted | Validation reject, no arbitrary text group | NOT_RUN |
| `CUS-TC-039` | `P2-AT-CUS-001-04` | CUS+SAL | Update ship-to Contact after confirmed Order | Order/label snapshot remains unchanged | NOT_RUN |
| `CUS-TC-040` | `P2-AT-CUS-001-04` | CUS+SAL | Marketplace external delivery snapshot | No Contact created; source address retained | NOT_RUN |
| `CUS-TC-041` | `P2-AT-CUS-001-04` | CUS-G1 | Same person/mobile two locations | Two distinct eligible Contact rows, no dedup | NOT_RUN |
| `CUS-TC-042` | `P2-AT-CUS-001-05` | CUS-G1 | Remove Company A from allowlist with historic interaction | Historic record retained; PBAC governs read | NOT_RUN |
| `CUS-TC-043` | `CUS-ADD-03` | SAL+FIN | Receipt from Company B linked to Company A SO | Reject allocation; no cross-company balance | NOT_RUN |
| `CUS-TC-044` | `P2-AT-CUS-001-04` | CUS-G1 | P1 Organization and Employee Contacts regressions | Old owner operations and PBAC scope pass unchanged | NOT_RUN |
| `CUS-TC-045` | `P2-AT-CUS-001-02` | CUS-G1 | Company usage replace concurrent with inactivation | Serializable business outcome with locked parent; no invalid ACTIVE+empty LIST | NOT_RUN |
| `CUS-TC-046` | `CUS-ADD-08` | CUS+PRC | Price List matching Company->Group->default and Customer group | Preserve P1 precedence; PRC group-code conditions deterministic | NOT_RUN |
| `CUS-TC-047` | `P2-AT-CUS-001-01` | CUS-G1 | Numbering AUTO_REQUIRED with blank code + rollback | Generates business code in transaction, no committed skipped/duplicate | NOT_RUN |
| `CUS-TC-048` | `CUS-ADD-07` | CUS+SAL+FIN | Open source link without permission after summary response | New request re-authorizes; deny when source permission revoked | NOT_RUN |

## Execution gate

- Trước test: chưa duyệt migration/API/PBAC kỹ thuật thì test chỉ là kế hoạch.
- G1: chạy PHP unit, CI4 integration, MariaDB transaction/FK and EXPLAIN, FE unit/e2e, DEV clone + P1 Contact Organization/Employee regression; ghi actor/config/DB fixture, request/response, assertion, timestamp.
- XMOD: chạy các edge cases thực với SAL/INV/FIN/PRC/COD, riêng billing và finance projections cần source recon totals và cancellation/reversal consistency.
- Chưa có module nguồn => đánh dấu **DEFERRED**, không PASS, không hiển thị số 0 giả.
- Release signoff cần reviewer, build SHA, DB schema version, scenarios negative and positive, evidence URL/artifacts; dùng template trong `qa/10_SIGNOFF_TEMPLATE.md`.



---

> Nguồn nội bộ: `docs/10_OPEN_ITEMS_AND_GATES.md`

# Danh mục còn mở sau khi đã chốt 12/12 quyết định

**Điểm phân biệt quan trọng:** 12 quyết định `CUS-X-01`…`CUS-X-12` đã **APPROVED** và không được trình bày như chưa chốt. Bảng dưới đây là các **chi tiết kỹ thuật/thiết kế module nguồn chưa được Product Owner xác định đủ**, không phải câu hỏi chốt lại phương án A.

## 1. Các blocker trước khi triển khai CUS Core (G1)

| Mã | Chi tiết cần hoàn tất | Owner |
|---|---|---|
| `CUS-T-GROUP-01` | Khóa danh mục mã customer_group_code ban đầu, quy tắc thay đổi/retirement và giá trị NULL | PO + PRC |
| `CUS-T-SEC-01` | Contact CUSTOMER group-shared hay private theo Company? P1 Contact thiếu company_id; xác định resource/context PBAC authority | Security + BE |
| `CUS-T-SQL-01` | Thiết kế SQL-first contact CUSTOMER scope, limit/cap fail-closed, join owner & negative tests khi mở rộng ContactRules/ScopeProvider/Sql | BE + Security |
| `CUS-T-WF-01` | State registry customer/customer_contact/customer_interaction, transition ACTION và precise ResourceAction seeding | BE + PO |
| `CUS-T-API-01` | Khóa exact API shapes/errors, sort/filter, paging, exception mapping và schema P1 compatibility | BE + FE |
| `CUS-T-DATA-01` | Chuẩn hóa customer_code, collation DB, province/ward input rules, NUMBERING mode, company allowlist active mutation | DBA + BE |
| `CUS-T-INT-01` | Cấu hình activity_type codes, sửa nhật ký append-only và retention/actor identity | PO + BE |

**Gate G1-Design Ready:** chỉ được gắn `READY FOR IMPLEMENTATION` khi có các artifact xác nhận: catalog/migrations/schema, owner-aware Contact PBAC SQL strategy, customer/interaction ResourceAction+Lifecycle, API schema frozen, code-list, regression matrix reviewed. Không cần chờ SAL/FIN runtime để triển khai **Core**, nhưng không được cam kết full UAT.

## 2. Các blocker tích hợp tại module nguồn

| Mã | Chi tiết cần hoàn tất | Gate |
|---|---|---|
| `CUS-T-SEC-02` | Permission riêng cho sales-summary/receivables và source authorization fallback, aggregate suppression | G3/G4 |
| `CUS-SAL-01` | Lifecycle SO, partial cancellation, direct pickup equivalent delivered event, frozen price components/taxes/fees | G3 |
| `CUS-SAL-02` | Return commercially-approved credit event/time and partial goods/discount/COMBO rounding | G3/G4 |
| `CUS-FIN-01` | money_source_links typed payment/refund allocations, N:M locking, overpayment, reversal and unapplied prepayments | G4 |
| `CUS-FIN-02` | Due_date source/default term, aging as-of retroactive events, refunds on allocated cash and backdate policy | G4 |
| `CUS-COD-01` | Provider collected/remitted/settled statuses, payout many shipments, fees and no double count | G4 |
| `CUS-PRC-01` | Replace P2 draft customer_group_id FK with stable customer_group_code matching plus specificity/tie-break | G3 |
| `CUS-DOC-01` | Document owner Customer and file permission/retention, future attachment tab | G1 DOC |
| `CUS-REPORT-01` | Định nghĩa cuối kỳ/holiday/date filtering, exact aggregation sources, response availability/auth/error mapping | G4 |

**Gate CUS-XMOD:** các mục này được sở hữu bởi SAL/INV/FIN/PRC/DOC; CUS chỉ chuẩn bị hợp đồng và client read projection. Không thêm bảng CUS vì các mục chưa chốt.

## 3. Đối chiếu quyết định P2 v1.0.0 trước đây

- `P2-DEC-007` Customer Group: **đã được giải quyết ở mức business** bằng controlled `customer_group_code` không có bảng nhóm động. P2-PRC schema/lookup sửa tại `CUS-PRC-01`.
- `P2-DEC-008` Company Usage: **đã giải quyết** bằng ALL/current allowlist; không effective dating; giữ lịch sử.
- `P2-DEC-009` Contact CUSTOMER: **đã chốt kiến trúc** mở rộng P1 owner, nhưng precise SQL/PBAC vẫn BLOCKER_G1 (`CUS-T-SEC-01`, `CUS-T-SQL-01`).
- Những `P2-DEC-*` khác ngoài CUS chỉ được thay đổi nếu có quyết định/gate tương ứng; không đánh dấu global P2 G0 hoặc SAL/FIN là đã Approved nhờ chốt CUS.

## 4. Trạng thái nghiệm thu được phép công bố

| Trạng thái | Bằng chứng tối thiểu |
|---|---|
| `CUS-DESIGN DECISIONS APPROVED` | 12/12 PO decisions; 3-table data model; domain ownership |
| `CUS-G1 DESIGN READY` | 7 technical G1 blockers closed, coherent schema/API/PBAC test specification |
| `CUS-G1 IMPLEMENTED` | Code + migrations + CI4 route + Vue + tests integrated on DEV clone (chưa làm) |
| `CUS-CORE CLOSED` | 8 UR AC CUS Core relevant tests PASS; P1 regressions PASS; dependent history marked deferred |
| `CUS-XMOD CONTRACT LOCKED` | SAL/FIN/PRC/DOC owners sign exact monetary/timeline/event contracts |
| `CUS-FULL ACCEPTED` | Runtimes SAL/INV/FIN integrated, UR-CUS-002 + CR reports UAT PASS, negative PBAC + finance reconciliation evidence |

**Hiện tại**: chỉ trạng thái đầu tiên hợp lệ; toàn bộ test case `NOT_RUN`.



---

> Nguồn nội bộ: `docs/11_IMPLEMENTATION_HANDOFF.md`

# Implementation Handoff — P2-CUS (tài liệu, chưa code)

**Change set:** G1 Customer Core, shared Contact owner extension and downstream contracts. **Base:** ERP v1.9.0 unchanged, P2 other modules deferred.

## 1. Phạm vi công việc khi bắt đầu CUS-G1 (sau khi đóng G1 technical gate)

1. Migration additive tạo **3 bảng** CUS và ResourceAction/Lifecycle seeds tương thích P1; kiểm tra DBPrefix/FK and unique.
2. Backend service/repositories cho Customer/Company Usage/Interactions theo patterns Module P1 hiện hành; không tạo Identity/permissions/numbering library mới.
3. Extend `ContactRules`, `ContactScope`, `ContactScopeProvider`, `ContactSql`, `ContactService` and Contact GET validation with new CUSTOMER owner while keeping P1 regressions.
4. API `customers`, `actions/set-state`, `interactions` với P1 response envelope, stable errors, actor+timestamp, SQL authorization.
5. Frontend Vue `Customers` list + Customer workspace, vi/en, Display Settings; Company allowlist; Contact ship-to eligibility.
6. Tests PHP unit/service/DB integration/PBAC negative/migrations/Frontend; approved fixture rules.
7. Dependency tabs for SAL/INV/FIN/DOC return `NOT_AVAILABLE`/hidden until actual source available; no false 0 or fake test success.

## 2. Non-goals for CUS-G1

Không tạo `customer_groups`, `customer_addresses`, `customer_debts`, `customer_revenues`, `customer_notes` hay generic Customer transaction clone. Không implement SAL/FIN transactions inside CUS. Không thêm Lead/Opportunity. Không cập nhật P1 already issued numbers/history. Không cung cấp tín dụng hạn mức.

## 3. Interface invariants phải giữ

| Consumer | Contract |
|---|---|
| SAL | Customer ID stable, Company selectable check authoritative at create/confirm, Contact ship-to snapshot, nullable Customer marketplace |
| PRC | `customer_group_code` from CUS, stable controlled codes; Company-Pricing P1 precedence preserved |
| FIN | Customer+Company validated order allocations, non-reversed POSTED only, source amounts not duplicated |
| DOC | Customer attachment links PBAC; no CUS binary storage |
| Analytics/UI | Company/date/source guards, separate 3 KPIs, no fake zeros, as-of/reversal |

## 4. Pre-merge checklist

- Reference tests 8 original UR and 8 additive CR, all mapped to test registry.
- Reviewed PBAC `customer`, `customer_contact`, `customer_interaction`, admin no bypass, ROW SQL before LIMIT.
- Review SQL EXPLAIN/filters, null/collation/order, concurrent duplicate and Company allowlist race.
- Migrations forward-only and rollback only on DEV clone, no destructive P1 Contact changes.
- Reconcile P2 draft PRC `customer_group_id` and old CUS references before merging OpenAPI docs.
- QA proof includes actual runtime tests in test environment, not docs verification.

## 5. Control

Everything beyond 12 PO decisions and D-rules must use `docs/10_OPEN_ITEMS_AND_GATES.md`; don't assume silent approval. New requirements via addendum/ADR, update traceability, bump version.



---

> Nguồn nội bộ: `docs/12_P2_DOCUMENT_SYNC_AMENDMENT.md`

# Amendment — những tài liệu P2 v1.0.0 phải đồng bộ trước triển khai

**Document ID:** P2-CUS-PARENT-DELTA-001 · **Status:** binding **CUS design amendment** sau quyết định của Product Owner; P2 v1.0.0 lưu như lịch sử DRAFT. Các file P2 draft **chưa được sửa hoặc hợp nhất trong tài liệu gốc**. Bản này cung cấp mapping chi tiết và source mới để cập nhật, tránh nhầm đã thay toàn bộ P2 v1.0.0.

| P2 source cũ | Nội dung CUS phải thay | Source thay thế trong pack |
|---|---|---|
| `modules/P2_CUS_INDEPENDENT_MODULE_SPEC.md` | 4 bảng + Customer Group CRUD + customer_notes => 3 bảng, controlled group code, interactions, ship-to contacts, indicators | `docs/01_..`, `02_..`, `03_..`, `04_..`, `05_..` |
| `docs/05_P2_DATABASE_DESIGN.md` | Bỏ `customer_groups`, `customer_notes`; bỏ `customers.customer_group_id` và `shipping_*`; bỏ `customer_company_usages.status`; dùng `customer_interactions`, `customer_group_code` | `docs/03_DATABASE_MINIMAL.md` |
| `docs/06_P2_API_DESIGN.md` | Bỏ Customer Group CRUD, notes/history endpoints draft; bổ sung `interactions`, deferred `transactions/sales-summary/receivables`; owner Contact | `docs/04_API_CONTRACT.md` + OpenAPI CUS |
| `docs/07_P2_UI_UX_DESIGN.md` | Bỏ `/customer-groups`; Customer workspace tabs, computed ship-to, deferred KPI status | `docs/05_UI_UX_CONTRACT.md` |
| `docs/08_P2_AUTHORIZATION_AND_AUDIT.md` | Thêm resource `customer_contact`, `customer_interaction`; PBAC nguồn KPI, SQL-first Company notes | `docs/06_PBAC_AND_SECURITY.md` |
| `docs/09_P2_INTEGRATIONS_AND_IDEMPOTENCY.md` | CUS cross-module payment and COD separation, Customer/Company owner checks | `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md` |
| `docs/14_P2_GAPS_AND_OPEN_DECISIONS.md` + `reference/P2_OPEN_DECISIONS.csv` | P2-DEC-007/008 resolved business; 009 design yes/technical open; add source-module blockers | `docs/10_OPEN_ITEMS_AND_GATES.md` |
| `docs/15_P2_TRACEABILITY_MATRIX.md` | CUS addendum CR and deferred tests | `reference/CUS_TRACEABILITY.csv` |
| `contracts/openapi/p2.draft.openapi.yaml` | Customer Group endpoints and Customer Group FK schema stale; CUS contract separate design file, merge after global review | `contracts/openapi/p2-cus.design.openapi.yaml` |
| `modules/P2_PRC_INDEPENDENT_MODULE_SPEC.md`, P2 PRC DB/API | `customer_group_id` FK -> `customer_group_code` code-aware lookup, no dynamic group table | `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md` |
| `modules/P2_SAL_INDEPENDENT_MODULE_SPEC.md` | SO ship-to immutable snapshot, delivery+posted-issue KPI, due date, returns credit, Customer ID company | `docs/07_..`, `08_..` |
| `modules/P2_FIN_INDEPENDENT_MODULE_SPEC.md` | posted payment allocations, refund/reversal, COD carrier remittance no double count | `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md` |

**Quan trọng:** Bản P2 tổng hợp v1.0.0 hiện có **187 API draft**; khi bỏ 5 group endpoints và thay các endpoint liên quan, số đếm sẽ thay đổi. Không coi con số cũ, API draft YAML cũ và CR hiện hành là nhất quán sau khi chốt CUS. Khi phát hành P2 v1.0.1 nên regenerate toàn bộ P2 registry, OpenAPI, FRS, handbook và chạy audit liên kết; việc này **khác** với approved CUS-only doc pack này.

**Thứ bậc tài liệu:** Original UR v1.0.15 > PO approved 12 decisions / CR CUS > CUS design baseline này > P2 v1.0.0 DRAFT CUS sections. Other P2 module approved invariants vẫn nguyên và không bị CUS quyết định tự sửa.



---

> Nguồn nội bộ: `reference/P1_SOURCE_VERIFICATION.md`

# P1 v1.9.0 verified source facts relevant to CUS

**ZIP:** `erp_v1.9.0.zip` SHA-256 `464cfe340c4d1b8d8ada4357b48fb8e470d719985155b8371ba01a975dbdf626`. Code was **read only** from ZIP, not modified in this delivery. File references are relative to `erp30-main/` in the original ZIP.

| Source path | Verified behavior |
|---|---|
| `backend/app/Database/Migrations/2026-10-05-000001_CreateFoundationLocationTables.php` | `provinces`, `wards` with `ward.province_id` and FK |
| `backend/app/Database/Migrations/2026-10-05-000002_CreateOrganizationContactTables.php` | `organizations` and `contacts`; Contact polymorphic `contact_type` + `contact_ref_id`, contact name/email/phone/mobile/description/address/province/ward and name snapshots; status/audit |
| `backend/app/Database/Migrations/2026-10-11-000015_SplitContactAuthorizationResources.php` | Contact-specific PBAC resources split, not generic Contact allow |
| `backend/app/Modules/Contact/ContactRules.php` | `OWNERS` currently only `ORGANIZATION => organization_contact` and `EMPLOYEE => employee_contact`; create `contact_type` and `contact_ref_id`; owner transfer in PATCH rejected |
| `backend/app/Modules/Contact/ContactScope.php` | Authoritative owner→organization derived from persisted Organization or Employee primary Assignment; doesn't support Customer owner |
| `backend/app/Modules/Contact/ContactScopeProvider.php` | Scope only `organization_contact`/`employee_contact`, SQL-first fail-closed limits |
| `backend/app/Modules/Contact/ContactSql.php` | Separate organization/employee SQL scope, new Customer branch required |
| `backend/app/Modules/Contact/ContactService.php` | Contact PBAC, workflow status, transaction/actor updates; must regress when adding owner |
| `contracts/openapi/openapi.yaml` | P1 3.1, GET/POST `/api/v1/contacts` and detail/action routes, response/error envelope with request_id, vi/en behavior |

**Not verified as live runtime:** MariaDB existing schema, production migrations state, actual CI4 DBPrefix, active PBAC assignments, existing Settings/Numbering series, current frontend deployment and carrier contracts. G1 technical review must reconcile with the running database and CI4 routes on DEV clone.

**No P2 module or migration was added** by this documentation operation.



---

> Nguồn nội bộ: `docs/13_DOCUMENTATION_INTEGRITY_QA.md`

# Documentation QA & Integrity — P2-CUS v1.0.0

**Scope:** kiểm tra cấu trúc và tính nhất quán của bộ **tài liệu**, không phải nghiệm thu API/frontend hoặc MariaDB. Tất cả P2 CUS tests chưa được chạy.

| Kiểm tra | Kết quả |
|---|---|
| CUS decisions 12/12 approved A | PASS |
| Approved extras D in register | PASS |
| 3 CUS tables only | PASS |
| No Customer Address/Group new entity | PASS |
| 8 original acceptance references | PASS |
| 8 additive requirement groups | PASS |
| All 16 requirements covered | PASS |
| All 12 decisions tested | PASS |
| 48 tests unexecuted | PASS |
| 16 unresolved technical items tagged open | PASS |
| P1 ZIP untouched same checksum | PASS |
| Original UR file byte-for-byte | PASS |
| OpenAPI 3.1 YAML parseable | PASS |
| 10 OpenAPI operations unique | PASS |
| OpenAPI refs resolved | PASS |
| Contacts P1 owner extension documented | PASS |
| P2 outdated group IDs flagged | PASS |
| No new application files | PASS |

## Tổng hợp kiểm chứng

- **18/18 kiểm tra hồ sơ PASS**; chuẩn hóa `12/12` quyết định duyệt A + mục D.
- **3** bảng CUS logical, **28** columns documented, **10** operation API đề xuất (7 G1 + 3 XMOD deferred), **4** UI routes đề xuất.
- **8** UR acceptance criteria gốc + **8** scope-addendum groups; **48** test cases **NOT RUN**; **16** chi tiết kỹ thuật/module nguồn còn OPEN.
- P1 source SHA-256: `464cfe340c4d1b8d8ada4357b48fb8e470d719985155b8371ba01a975dbdf626`; User Requirements SHA-256: `97894e35dbf6c5f641f56574af947cafbc45122a87b9fb189ee7426503448144`.

**Không được dùng chữ PASS của kiểm tra tài liệu làm bằng chứng phát triển đã hoàn thành.** Cần migration/runtime/integration UAT trên DEV clone trước khi đóng CUS Core/Full.
