# P1 v1.9.0 verified source facts relevant to CUS

**ZIP:** `erp_v1.9.0.zip` SHA-256 `464cfe340c4d1b8d8ada4357b48fb8e470d719985155b8371ba01a975dbdf626`. Code was **read only** from ZIP, not modified in this delivery. File references are relative to `erp30-main/` in the original ZIP.

| Source path | Verified behavior |
|---|---|
| `backend/app/Database/Migrations/2026-10-05-000001_CreateFoundationLocationTables.php` | `provinces`, `wards` with `ward.province_id` and FK |
| `backend/app/Database/Migrations/2026-10-05-000002_CreateOrganizationContactTables.php` | `organizations` and `contacts`; Contact polymorphic `contact_type` + `contact_ref_id`, contact name/email/phone/mobile/description/address/province/ward and name snapshots; status/audit |
| `backend/app/Database/Migrations/2026-10-11-000015_SplitContactAuthorizationResources.php` | Contact-specific PBAC resources split, not generic Contact allow |
| `backend/app/Modules/Contact/ContactRules.php` | `OWNERS` currently only `ORGANIZATION => organization_contact` and `EMPLOYEE => employee_contact`; create `contact_type` and `contact_ref_id`; owner transfer in PATCH rejected |
| `backend/app/Modules/Contact/ContactScope.php` | Authoritative owner→organization derived from persisted Organization or Employee primary Assignment; doesn't support Customer owner |
| `backend/app/Modules/Contact/ContactScopeProvider.php` | Scope only `organization_contact`/`employee_contact`, SQL-first fail-closed limits |
| `backend/app/Modules/Contact/ContactSql.php` | Separate organization/employee SQL scope, new Customer branch required |
| `backend/app/Modules/Contact/ContactService.php` | Contact PBAC, workflow status, transaction/actor updates; must regress when adding owner |
| `contracts/openapi/openapi.yaml` | P1 3.1, GET/POST `/api/v1/contacts` and detail/action routes, response/error envelope with request_id, vi/en behavior |

**Not verified as live runtime:** MariaDB existing schema, production migrations state, actual CI4 DBPrefix, active PBAC assignments, existing Settings/Numbering series, current frontend deployment and carrier contracts. G1 technical review must reconcile with the running database and CI4 routes on DEV clone.

**No P2 module or migration was added** by this documentation operation.
