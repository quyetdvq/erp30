#!/usr/bin/env python3
"""Documentation-only integrity and design parity QA for P2-CUS G1 v1.1.0.
This script READS packaged docs. It does not write to or require the ERP codebase/database.
PyYAML and jsonschema enable deeper optional OpenAPI schema checks.
"""
from __future__ import annotations
import csv, hashlib, json, re, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
EXPECTED_GROUP={'STANDARD':'Tiêu chuẩn','TMDT':'Thương mại điện tử','VIP1':'Vip 1','VIP2':'Vip 2'}
DECISIONS={f'CUS-T-{s}-01' for s in ('GROUP','SEC','SQL','WF','API','DATA','INT')}
checks=[]

def check(name,condition):
 checks.append((name, bool(condition)))
 print(('[PASS]' if condition else '[FAIL]')+' '+name)

def filebytes(relative):return (ROOT/relative).read_bytes()
def csvrows(relative):
 with (ROOT/relative).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def sha(data):return hashlib.sha256(data).hexdigest()

def main():
 manifest=json.loads(filebytes('MANIFEST.json'))
 check('G1 package version',manifest.get('document_pack')=='DinkERP_P2_CUS_G1_Technical_Baseline_v1.1.0')
 items=manifest.get('files',[])
 rels=[i['path'] for i in items]
 check('Manifest covers all packaged data files',len(items)==len(set(rels)) and set(rels)=={x.relative_to(ROOT).as_posix() for x in ROOT.rglob('*') if x.is_file() and x.name not in {'MANIFEST.json','SHA256SUMS.txt'}})
 check('Manifest file hashes match', all((ROOT/i['path']).is_file() and sha(filebytes(i['path']))==i['sha256'] and len(filebytes(i['path']))==i['bytes'] for i in items))
 checksums={}
 for line in filebytes('SHA256SUMS.txt').decode('utf-8').splitlines():
  match=re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
  if match:checksums[match.group(2)]=match.group(1)
 check('SHA256SUMS covers manifest and every other file',set(checksums)==set(rels)|{'MANIFEST.json'} and all(sha(filebytes(p))==h for p,h in checksums.items()))
 check('Original source UR content checksum preserved',sha(filebytes('reference/00_User_Requirements_v1.0.15.md'))=='97894e35dbf6c5f641f56574af947cafbc45122a87b9fb189ee7426503448144')

 approved=csvrows('reference/CUS_APPROVED_DECISIONS.csv')
 check('12 original CUS business decisions remain approved',len(approved)==12 and all(x['status']=='APPROVED_BUSINESS_DESIGN' for x in approved))
 t=csvrows('reference/CUS_G1_APPROVED_TECH_DECISIONS.csv')
 check('7 approved G1 technical A decisions',len(t)==7 and set(x['decision_id'] for x in t)==DECISIONS and all(x['status']=='CLOSED_APPROVED' for x in t))
 op=csvrows('reference/CUS_OPEN_TECHNICAL_ITEMS.csv')
 check('No G1 blockers, exactly 9 XMOD open',len(op)==16 and sum(x['status']=='CLOSED_APPROVED' for x in op)==7 and sum(x['status']=='OPEN' for x in op)==9 and all(x['status']=='CLOSED_APPROVED' for x in op if x['item_id'] in DECISIONS))
 groups=csvrows('reference/CUS_CUSTOMER_GROUP_CODES.csv')
 actual={x['code']:x['vi_label'] for x in groups}
 check('Approved CUSTOMER_GROUP() code/label catalog exact',len(groups)==4 and actual==EXPECTED_GROUP)
 jc=json.loads(filebytes('reference/CUS_CUSTOMER_GROUP_CONTRACT.json'))
 check('GROUP contract nullable; no literal VIP; no dynamic tables',jc.get('nullable') is True and jc['codes']==EXPECTED_GROUP and 'VIP' in jc['reject_literals'] and not jc['dynamic_group_crud'])
 helper=filebytes('docs/15_CUSTOMER_GROUP_FUNCTION_CONTRACT.md').decode('utf-8')
 sample=re.search(r'```php\s*(.*?)\s*```',helper,re.DOTALL)
 pairs=re.findall(r"'([A-Z0-9]+)'\s*=>\s*'([^']+)'",sample.group(1) if sample else '')
 check('PHP helper sample has exact four key/value pairs and function guard',bool(sample) and dict(pairs)==EXPECTED_GROUP and len(pairs)==4 and "function_exists('CUSTOMER_GROUP')" in sample.group(1) and 'function CUSTOMER_GROUP()' in sample.group(1))
 check('Helper sample is documentation only, no ERP .php source packaged',not any(f.suffix.lower()=='.php' for f in ROOT.rglob('*') if f.is_file()))

 db=csvrows('reference/CUS_DATABASE_DICTIONARY.csv')
 check('Exactly 3 CUS tables and 29 logical columns',len(db)==29 and set(x['table'] for x in db)=={'customers','customer_company_usages','customer_interactions'} and len({(x['table'],x['column']) for x in db})==29)
 correct=[x for x in db if x['table']=='customer_interactions' and x['column']=='corrects_interaction_id']
 check('CORRECTION same-owner nullable self-FK in DB catalog',len(correct)==1 and 'customer_interactions.id' in correct[0]['constraint'] and 'same persisted' in correct[0]['description'])
 check('Group code is nullable field without group table', any(x['table']=='customers' and x['column']=='customer_group_code' and 'NULL' in x['description'] for x in db) and 'customer_groups' not in {x['table'] for x in db})
 tests=csvrows('reference/CUS_TEST_CASES.csv')
 check('66 distinct test cases, zero tests claimed run',len(tests)==66 and len(set(x['test_id'] for x in tests))==66 and all(x['run_status']=='NOT_RUN' for x in tests))
 check('Every technical decision has a named test',all(any(x['decision_id']==d for x in tests) for d in DECISIONS))
 trace=csvrows('reference/CUS_TRACEABILITY.csv')
 check('8 original AC + 8 change-addendum groups traced',len(trace)==16 and len([x for x in trace if x['requirement_id'].startswith('P2-AT-CUS')])==8 and all(any(t['requirement_id']==x['requirement_id'] for t in tests) for x in trace))
 check('Every test appears in its own requirement trace row',all(t['test_id'] in next(x['test_ids'] for x in trace if x['requirement_id']==t['requirement_id']).split(';') for t in tests))
 api=csvrows('reference/CUS_API_CATALOG.csv')
 check('7 Core API designs + 3 XMOD deferred and not implemented',len(api)==10 and sum(x['release']=='CUS-G1' for x in api)==7 and all(x['runtime_status']!='IMPLEMENTED' for x in api))

 yamldoc=None
 try:
  import yaml
  yamldoc=yaml.safe_load(filebytes('contracts/openapi/p2-cus.design.openapi.yaml'))
 except ImportError:print('[SKIP] PyYAML not installed; OpenAPI structure check unavailable (all text/hashes checked)')
 if yamldoc is not None:
  check('OpenAPI 3.1 and approved design-only metadata',yamldoc.get('openapi')=='3.1.0' and yamldoc.get('x-cus-design-approval',{}).get('approved_technical_decisions')==7 and not yamldoc['x-cus-design-approval']['runtime_implemented'])
  ops=[(m,e) for route,v in yamldoc['paths'].items() for m,e in v.items() if m.lower() in ('get','post','put','patch','delete')]
  check('OpenAPI has 10 unique operationIds',len(ops)==10 and len(set(e.get('operationId') for m,e in ops))==10)
  check('OpenAPI declares exactly 7 approved G1 operations and 3 deferred',sum(e.get('x-design-status')=='CUS_G1_TECH_APPROVED_NOT_IMPLEMENTED' for m,e in ops)==7 and sum(e.get('x-design-status')=='DEPENDENCY_PENDING' for m,e in ops)==3)
  comps=yamldoc['components']['schemas']
  group_schema=comps['CustomerGroupCode']
  check('OpenAPI Group code schema matches helper and null',group_schema.get('oneOf')==[{'type':'string','enum':list(EXPECTED_GROUP)},{'type':'null'}] and all(comps[x]['properties']['customer_group_code'].get('$ref')=='#/components/schemas/CustomerGroupCode' for x in ('Customer','CustomerCreate','CustomerPatch')))
  check('OpenAPI interaction event types and correction FK',comps['CustomerInteractionActivityType'].get('enum')==['NOTE','CALL','EMAIL','MEETING','CORRECTION'] and 'corrects_interaction_id' in comps['CustomerInteractionCreate']['properties'] and 'corrects_interaction_id' in comps['CustomerInteraction']['properties'])
  refs=set()
  def walk(v):
   if isinstance(v,dict):
    for k,x in v.items():
     if k=='$ref':refs.add(x)
     else:walk(x)
   elif isinstance(v,list):
    for x in v:walk(x)
  walk(yamldoc)
  def resolves(ref):
   if not ref.startswith('#/'):return False
   v=yamldoc
   for part in ref[2:].split('/'):
    part=part.replace('~1','/').replace('~0','~')
    if not isinstance(v,dict) or part not in v:return False
    v=v[part]
   return True
  check('OpenAPI references all resolve locally',all(resolves(x) for x in refs))
  try:
   import jsonschema
   wrapper={'components':yamldoc['components']}
   group_value={'$ref':'#/components/schemas/CustomerGroupCode',**wrapper}
   interaction={'$ref':'#/components/schemas/CustomerInteractionCreate',**wrapper}
   valids=['STANDARD','TMDT','VIP1','VIP2',None]
   invalids=['VIP','NULL','OTHER',12]
   gcheck=all(jsonschema.Draft202012Validator(group_value).is_valid(x) for x in valids) and all(not jsonschema.Draft202012Validator(group_value).is_valid(x) for x in invalids)
   check('JSON Schema validates exact four group codes + NULL',gcheck)
   base={'company_organization_id':1,'activity_type':'NOTE','content':'Contacted customer'}
   corr={'company_organization_id':1,'activity_type':'CORRECTION','content':'Mistake correction','corrects_interaction_id':3}
   tests2=[(base,True),(corr,True),({**corr,'happened_at':'2026-10-28T00:00:00Z'},False),({**base,'corrects_interaction_id':3},False),({k:v for k,v in corr.items() if k!='corrects_interaction_id'},False)]
   check('JSON Schema correction conditional valid/invalid fixtures',all(jsonschema.Draft202012Validator(interaction).is_valid(inp)==expected for inp,expected in tests2))
  except ImportError: print('[SKIP] jsonschema missing; functional schema fixture checks unavailable')

 # No broken relative markdown links (external URL and anchors ignored).
 bad=[]
 for f in ROOT.rglob('*.md'):
  for dest in re.findall(r'\[[^\]]+\]\(([^)]+)\)',f.read_text(encoding='utf-8-sig')):
   if dest.startswith(('http:','https:','#','sandbox:','mailto:')):continue
   dest=dest.split('#',1)[0]
   if dest and not (f.parent/dest).is_file():bad.append((str(f.relative_to(ROOT)),dest))
 check('Markdown local links resolve',not bad)
 if bad:
  print('Unresolved links:',bad[:10])
 passed=sum(ok for _,ok in checks); print(f'DOCUMENTATION QA: {passed}/{len(checks)} checks PASS; '+('SUCCESS' if passed==len(checks) else 'FAILURE'))
 return 0 if passed==len(checks) else 2

if __name__=='__main__':sys.exit(main())
