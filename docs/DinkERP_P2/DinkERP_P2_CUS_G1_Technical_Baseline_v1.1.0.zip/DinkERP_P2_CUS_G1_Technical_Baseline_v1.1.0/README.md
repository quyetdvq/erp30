# DinkERP — P2-CUS G1 Technical Baseline v1.1.0

**Approved by Product Owner on 2026-10-28:** 12/12 CUS business decisions A + supporting D rules; **7/7 G1 technical decisions A** with an explicit `CUSTOMER_GROUP()` list (`STANDARD,TMDT,VIP1,VIP2`, nullable) and `CORRECTION` + `corrects_interaction_id`. No further G1 **design** blocker.  
**State:** `CUS-G1 DESIGN READY FOR IMPLEMENTATION` (**documentation approval only**), `CODE NOT MODIFIED`, `DB NOT MODIFIED`, `RUNTIME TESTS NOT RUN`; **9 XMOD source-module design items OPEN**.  
**Source baseline:** `erp_v1.9.0.zip` (P1 closed); User Requirements v1.0.15 copied byte-verbatim into `reference/`.

## Start here

1. `docs/00_DECISION_RECORD.md`: 12 business choices and G1 addendum; `docs/14_G1_TECHNICAL_DECISIONS_APPROVED.md`: all 7 resolved technical choices.
2. `docs/15_CUSTOMER_GROUP_FUNCTION_CONTRACT.md`: exact user-approved PHP helper *specification* (code sample only; **not an application file**) and allowed group codes.
3. `docs/02_DOMAIN_FUNCTIONAL_SPEC.md`, `docs/03_DATABASE_MINIMAL.md`: domain and **exactly 3 tables/29 columns**.
4. `docs/04_API_CONTRACT.md` + `contracts/openapi/p2-cus.design.openapi.yaml`: **7 G1 Core operations + 3 deferred reads**, approved design schema; no deployed endpoint asserted.
5. `docs/05_UI_UX_CONTRACT.md`, `docs/06_PBAC_AND_SECURITY.md`, `docs/08_DATA_FLOW_AND_LIFECYCLE.md`: UI, GROUP Contact/Company interactions, workflow and correction.
6. `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md`, `docs/10_OPEN_ITEMS_AND_GATES.md`: **9** still-open source-module integration design details; not CUS Core blockers.
7. `qa/09_TEST_MATRIX.md` and `reference/CUS_TEST_CASES.csv`: full planned acceptance/regression tests (**all NOT_RUN**), `qa/10_SIGNOFF_TEMPLATE.md`.
8. `docs/11_IMPLEMENTATION_HANDOFF.md`, `docs/12_P2_DOCUMENT_SYNC_AMENDMENT.md`: implementation and parent-P2 delta without editing parent pack.
9. `docs/13_DOCUMENTATION_INTEGRITY_QA.md`, `tools/check_cus_g1_bundle.py`: self-contained verification of documentation files, manifest, decisions, group codes, OpenAPI references and status.
10. `archive/`: three **historical** proposal memos (v0.x) that must not override current v1.1.0 design.

## Approved architecture

- 3 NEW CUS tables: `customers`, `customer_company_usages`, `customer_interactions` — **29 logical columns** (including `corrects_interaction_id`).
- P1 `contacts` reused for multiple ship-to locations and Customer contact list, owner `CUSTOMER` is an **additive future code change**, not present in P1.
- No `customer_groups`, `customer_addresses`, duplicate Contact table, debt/revenue cache or extra CRM table.
- Customer is GROUP master; Contact Group-shared with dual PBAC, interactions COMPANY-owned; SAL/FIN data source-specific PBAC.
- Customer Group codes `STANDARD/TMDT/VIP1/VIP2`, `NULL` allowed; frontend labels and PRC matching use stable keys. `TMDT` customer segment is not sales channel.
- `ACTIVE/INACTIVE` via lifecycle, five append-only interaction types; corrections reference a same-Company original row.
- CUS G1 covers Customer/Contacts/Interactions/Core UI; Sales, Revenue, Receivables, COD and Documents only activate after owning modules reach runtime acceptance.

## Design ≠ implementation

**Nothing in this distribution is a database migration or modified ERP application code.** Any PHP snippet inside `.md` is only a planned function contract. No live DB migration, deployment, authorization-seed or test has run. 7 technical choices are fixed at design level; implementers must verify P1 runtime schema/DBPrefix/Numbering/PBAC/EXPLAIN on DEV before release. All 9 XMOD design items stay open.
