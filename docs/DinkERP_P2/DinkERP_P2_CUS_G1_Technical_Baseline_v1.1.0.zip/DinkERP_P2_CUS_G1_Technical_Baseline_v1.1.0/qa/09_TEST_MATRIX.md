# P2-CUS v1.1.0 — QA and Traceability Matrix

**Documentation design status:** 12/12 CUS-X business decisions + 7/7 technical CUS-T G1 APPROVED. **Runtime execution status:** every test **NOT_RUN**. **XMOD:** 9 integration technical source items OPEN.

## Scope and evidence contract

- Customer Group exactly `STANDARD/TMDT/VIP1/VIP2`, optional NULL; test planned backend `CUSTOMER_GROUP()` helper source only after implementation. No bare VIP and no Customer Group table.
- Add `CORRECTION` and nullable `corrects_interaction_id` same-Customer+Company self-FK; test append-only/no mutation and time ordering.
- G1 negative PBAC: dual Customer/contact Group permission, Company-interaction access isolation, SQL filtering before COUNT/LIMIT, owner transfer mismatch; legacy P1 ORG/EMP contacts regression.
- G1 runtime acceptance requires actual CI4 + MariaDB DEV clone + Vue tests, not a passing documentation validator. Dependent SAL/FIN/INV/PRC/COD tests remain DEFERRED until those systems exist, and must never be falsely marked PASS.

## Requirement-to-test coverage

| Requirement ID | Tests (planned) |
|---|---|
| `P2-AT-CUS-001-01` | `CUS-TC-001`, `CUS-TC-002`, `CUS-TC-047`, `CUS-TC-059`, `CUS-TC-064` |
| `P2-AT-CUS-001-02` | `CUS-TC-003`, `CUS-TC-004`, `CUS-TC-045`, `CUS-TC-066` |
| `P2-AT-CUS-001-03` | `CUS-TC-005` |
| `P2-AT-CUS-001-04` | `CUS-TC-006`, `CUS-TC-007`, `CUS-TC-008`, `CUS-TC-039`, `CUS-TC-040`, `CUS-TC-041`, `CUS-TC-044`, `CUS-TC-054`, `CUS-TC-055`, `CUS-TC-056`, `CUS-TC-057` |
| `P2-AT-CUS-001-05` | `CUS-TC-009`, `CUS-TC-042`, `CUS-TC-058` |
| `P2-AT-CUS-002-01` | `CUS-TC-010`, `CUS-TC-011`, `CUS-TC-060`, `CUS-TC-061`, `CUS-TC-062`, `CUS-TC-063`, `CUS-TC-065` |
| `P2-AT-CUS-002-02` | `CUS-TC-012`, `CUS-TC-013` |
| `P2-AT-CUS-002-03` | `CUS-TC-014` |
| `CUS-ADD-01` | `CUS-TC-015`, `CUS-TC-016` |
| `CUS-ADD-02` | `CUS-TC-017`, `CUS-TC-018`, `CUS-TC-019`, `CUS-TC-020` |
| `CUS-ADD-03` | `CUS-TC-021`, `CUS-TC-022`, `CUS-TC-043` |
| `CUS-ADD-04` | `CUS-TC-023`, `CUS-TC-024`, `CUS-TC-025`, `CUS-TC-026` |
| `CUS-ADD-05` | `CUS-TC-027`, `CUS-TC-028`, `CUS-TC-029` |
| `CUS-ADD-06` | `CUS-TC-030`, `CUS-TC-031`, `CUS-TC-032` |
| `CUS-ADD-07` | `CUS-TC-033`, `CUS-TC-034`, `CUS-TC-035`, `CUS-TC-036`, `CUS-TC-048` |
| `CUS-ADD-08` | `CUS-TC-037`, `CUS-TC-038`, `CUS-TC-046`, `CUS-TC-049`, `CUS-TC-050`, `CUS-TC-051`, `CUS-TC-052`, `CUS-TC-053` |

## Test-case registry (all NOT_RUN)

| ID | Requirement | Decision | Gate | Scenario | Expected | Runtime |
|---|---|---|---|---|---|---|
| `CUS-TC-001` | `P2-AT-CUS-001-01` | `CUS-X-03` | `CUS-G1` | Customer code duplicate within same Company vs different Company | Second create rejected; exactly one Group customer | NOT_RUN |
| `CUS-TC-002` | `P2-AT-CUS-001-01` | `CUS-X-03` | `CUS-G1` | Two concurrent creates with same code | Exactly one commit; unique integrity; no orphan scope | NOT_RUN |
| `CUS-TC-003` | `P2-AT-CUS-001-02` | `CUS-X-03` | `CUS-G1` | all_companies=true with no usage rows | Any active Company eligible subject to Sales PBAC | NOT_RUN |
| `CUS-TC-004` | `P2-AT-CUS-001-02` | `CUS-X-03` | `CUS-G1` | all_companies=false Company A+B, empty/invalid/duplicate allowlist | Atomic, only valid distinct COMPANY IDs accepted | NOT_RUN |
| `CUS-TC-005` | `P2-AT-CUS-001-03` | `CUS-X-03` | `CUS+SAL` | Company C not in allowlist creates SO | Reject at server even if frontend is bypassed | NOT_RUN |
| `CUS-TC-006` | `P2-AT-CUS-001-04` | `CUS-X-01` | `CUS-G1` | Three valid ship-to Contacts per Customer | All three selectable, no new customer_addresses | NOT_RUN |
| `CUS-TC-007` | `P2-AT-CUS-001-04` | `CUS-X-01` | `CUS-G1` | Contact has email only/no address | Contact readable but not shipping-eligible | NOT_RUN |
| `CUS-TC-008` | `P2-AT-CUS-001-04` | `CUS-X-01` | `CUS+SAL` | Contact owner is another Customer/EMPLOYEE | Cannot select for this Customer; no spoof | NOT_RUN |
| `CUS-TC-009` | `P2-AT-CUS-001-05` | `CUS-X-03` | `CUS+SAL` | Customer made INACTIVE after historic SO | New SO rejected; old SO still readable under SAL scope | NOT_RUN |
| `CUS-TC-010` | `P2-AT-CUS-002-01` | `CUS-X-03` | `CUS-G1` | Company A NOTE and Company B CALL; actor A only | B note absent from list/COUNT/export/paging | NOT_RUN |
| `CUS-TC-011` | `P2-AT-CUS-002-01` | `CUS-X-12` | `CUS-G1` | Attempt to silently edit or delete a past interaction | Write rejected; corrective append retains original | NOT_RUN |
| `CUS-TC-012` | `P2-AT-CUS-002-02` | `CUS-X-10` | `CUS+SAL+FIN` | Only sales_order.view allowed, no money_receipt.view | Order visible; receipts/finance sums suppressed | NOT_RUN |
| `CUS-TC-013` | `P2-AT-CUS-002-02` | `CUS-X-10` | `CUS+SAL+FIN` | Company A actor reads combined Group Customer history A+B | Only authorized source records after SQL Company filtering | NOT_RUN |
| `CUS-TC-014` | `P2-AT-CUS-002-03` | `CUS-X-02` | `CUS-G1` | Inspect CUS UI/resource/table catalog | No Lead/Opportunity pipeline or CRUD | NOT_RUN |
| `CUS-TC-015` | `CUS-ADD-01` | `CUS-X-04` | `SAL+INV` | Confirmed order value, shipped part, returned part | Three distinct KPIs; correct values and cutoff dates | NOT_RUN |
| `CUS-TC-016` | `CUS-ADD-01` | `CUS-X-04` | `SAL` | Order cancelled pre-fulfillment | No fulfilled value; confirmed value handling uses authoritative cancellation policy | NOT_RUN |
| `CUS-TC-017` | `CUS-ADD-02` | `CUS-X-05` | `SAL+INV` | Shipment delivered but Sales Issue not POSTED | No fulfilled amount yet | NOT_RUN |
| `CUS-TC-018` | `CUS-ADD-02` | `CUS-X-05` | `SAL+INV` | Sales Issue POSTED, Shipment not delivered | No fulfilled amount yet | NOT_RUN |
| `CUS-TC-019` | `CUS-ADD-02` | `CUS-X-05` | `SAL+INV` | Partial delivery and duplicate carrier callback | Only posted+delivered valid portion; no duplicate values | NOT_RUN |
| `CUS-TC-020` | `CUS-ADD-02` | `CUS-X-05` | `SAL` | Commercial credit approved but stock return not POSTED yet | Net sales decreases only per approved commercial credit event | NOT_RUN |
| `CUS-TC-021` | `CUS-ADD-03` | `CUS-X-06` | `SAL+FIN` | Payable 12m, approved credit 2m, paid allocation 7m | Open 3m VND, no AR/GL table | NOT_RUN |
| `CUS-TC-022` | `CUS-ADD-03` | `CUS-X-06` | `FIN` | Overpayment and unapplied receipt | Separate overpay/open due/unapplied buckets, not hide negative position | NOT_RUN |
| `CUS-TC-023` | `CUS-ADD-04` | `CUS-X-07` | `FIN` | One POSTED receipt allocated to two SOs | Total allocated <= posted amount, correct Company/customer | NOT_RUN |
| `CUS-TC-024` | `CUS-ADD-04` | `CUS-X-07` | `FIN` | Two POSTED receipts allocated to one SO | Correct sum; no double apply; concurrent lock | NOT_RUN |
| `CUS-TC-025` | `CUS-ADD-04` | `CUS-X-07` | `FIN` | Unposted/void/reversed receipt allocated | Not counted; linkage refused or reversed consistently | NOT_RUN |
| `CUS-TC-026` | `CUS-ADD-04` | `CUS-X-07` | `FIN` | Posted customer refund against prior allocated cash | net(o,t) corrected without duplicate commercial credit | NOT_RUN |
| `CUS-TC-027` | `CUS-ADD-05` | `CUS-X-08` | `SAL+FIN` | Carrier collected COD; Company not yet remitted | Customer collection distinct from cash in bank; carrier pending | NOT_RUN |
| `CUS-TC-028` | `CUS-ADD-05` | `CUS-X-08` | `SAL+FIN` | Carrier payout and FIN posted receipt | Carrier pending decreases; Customer debt not reduced twice | NOT_RUN |
| `CUS-TC-029` | `CUS-ADD-05` | `CUS-X-08` | `SAL+FIN` | Marketplace order unknown customer_id | Not attributed to named Customer; no phone-based join | NOT_RUN |
| `CUS-TC-030` | `CUS-ADD-06` | `CUS-X-09` | `SAL+FIN` | Order due_date missing, positive balance | UNKNOWN_DUE_DATE, not overdue | NOT_RUN |
| `CUS-TC-031` | `CUS-ADD-06` | `CUS-X-09` | `SAL+FIN` | Due date -1,-30,-31,-60,-61,-90,-91 days | Buckets 1–30,31–60,61–90,>90 correct Company business date | NOT_RUN |
| `CUS-TC-032` | `CUS-ADD-06` | `CUS-X-09` | `CUS-G1` | Customer UI tries credit limit feature | Not present; new credit blocking not enabled | NOT_RUN |
| `CUS-TC-033` | `CUS-ADD-07` | `CUS-X-10` | `CUS-G1` | Sales dependency not installed | Metric tagged DEPENDENCY_PENDING, not value 0 | NOT_RUN |
| `CUS-TC-034` | `CUS-ADD-07` | `CUS-X-10` | `CUS+SAL+FIN` | Denied one financial source permission | No hidden sums/count leak; NOT_AUTHORIZED | NOT_RUN |
| `CUS-TC-035` | `CUS-ADD-07` | `CUS-X-12` | `SAL+FIN` | As-of date before later receipt/refund/reversal | Historical value computed from valid past events only | NOT_RUN |
| `CUS-TC-036` | `CUS-ADD-07` | `CUS-X-12` | `SAL+FIN` | Period report vs as-of past payments and timezone midnight | Flow period and position as_of not mixed; Company timezone | NOT_RUN |
| `CUS-TC-037` | `CUS-ADD-08` | `CUS-X-11` | `CUS+PRC` | Pricing uses controlled code, group change after SO | No Customer Group FK required; historic SO price frozen | NOT_RUN |
| `CUS-TC-038` | `CUS-ADD-08` | `CUS-X-02` | `CUS-G1` | Unknown customer_group_code posted | Validation reject, no arbitrary text group | NOT_RUN |
| `CUS-TC-039` | `P2-AT-CUS-001-04` | `CUS-X-01` | `CUS+SAL` | Update ship-to Contact after confirmed Order | Order/label snapshot remains unchanged | NOT_RUN |
| `CUS-TC-040` | `P2-AT-CUS-001-04` | `CUS-X-01` | `CUS+SAL` | Marketplace external delivery snapshot | No Contact created; source address retained | NOT_RUN |
| `CUS-TC-041` | `P2-AT-CUS-001-04` | `CUS-X-01` | `CUS-G1` | Same person/mobile two locations | Two distinct eligible Contact rows, no dedup | NOT_RUN |
| `CUS-TC-042` | `P2-AT-CUS-001-05` | `CUS-X-03` | `CUS-G1` | Remove Company A from allowlist with historic interaction | Historic record retained; PBAC governs read | NOT_RUN |
| `CUS-TC-043` | `CUS-ADD-03` | `CUS-X-06` | `SAL+FIN` | Receipt from Company B linked to Company A SO | Reject allocation; no cross-company balance | NOT_RUN |
| `CUS-TC-044` | `P2-AT-CUS-001-04` | `CUS-X-01` | `CUS-G1` | P1 Organization and Employee Contacts regressions | Old owner operations and PBAC scope pass unchanged | NOT_RUN |
| `CUS-TC-045` | `P2-AT-CUS-001-02` | `CUS-X-03` | `CUS-G1` | Company usage replace concurrent with inactivation | Serializable business outcome with locked parent; no invalid ACTIVE+empty LIST | NOT_RUN |
| `CUS-TC-046` | `CUS-ADD-08` | `CUS-X-11` | `CUS+PRC` | Price List matching Company->Group->default and Customer group | Preserve P1 precedence; PRC group-code conditions deterministic | NOT_RUN |
| `CUS-TC-047` | `P2-AT-CUS-001-01` | `CUS-X-03` | `CUS-G1` | Numbering AUTO_REQUIRED with blank code + rollback | Generates business code in transaction, no committed skipped/duplicate | NOT_RUN |
| `CUS-TC-048` | `CUS-ADD-07` | `CUS-X-10` | `CUS+SAL+FIN` | Open source link without permission after summary response | New request re-authorizes; deny when source permission revoked | NOT_RUN |
| `CUS-TC-049` | `CUS-ADD-08` | `CUS-T-GROUP-01` | `CUS-G1` | CUSTOMER_GROUP() helper exact map and order; function_exists guard | Four keys STANDARD/TMDT/VIP1/VIP2 with exact Vietnamese labels; no VIP key | NOT_RUN |
| `CUS-TC-050` | `CUS-ADD-08` | `CUS-T-GROUP-01` | `CUS-G1` | POST group NULL/omitted/blank, PATCH omitted/explicit NULL | POST unassigned SQL NULL; PATCH omission keeps old; explicit NULL clears | NOT_RUN |
| `CUS-TC-051` | `CUS-ADD-08` | `CUS-T-GROUP-01` | `CUS-G1` | Unknown group VIP / literal NULL / arbitrary code and lowercase input | Unknown rejected 422 CUSTOMER_GROUP_CODE_INVALID; trim uppercase canonical accepted when matching known | NOT_RUN |
| `CUS-TC-052` | `CUS-ADD-08` | `CUS-T-GROUP-01` | `CUS-G1` | UI vi/en option keys match CUSTOMER_GROUP() and OpenAPI | Exactly same four keys, no group CRUD or extra group table; nullable option | NOT_RUN |
| `CUS-TC-053` | `CUS-ADD-08` | `CUS-T-GROUP-01` | `CUS+PRC` | TMDT customer-group versus EXTERNAL_CHANNEL Sales channel | No implicit marketplace channel or price rule; PRC exact canonical group matching | NOT_RUN |
| `CUS-TC-054` | `P2-AT-CUS-001-04` | `CUS-T-SEC-01` | `CUS-G1` | Actor has customer.view but no customer_contact.view | Customer master visible; customer contacts denied even if all_companies=1 | NOT_RUN |
| `CUS-TC-055` | `P2-AT-CUS-001-04` | `CUS-T-SEC-01` | `CUS-G1` | GROUP contact viewer, Company B interaction forbidden | Contact may be seen with GROUP permissions; B private notes omitted and count hidden | NOT_RUN |
| `CUS-TC-056` | `P2-AT-CUS-001-04` | `CUS-T-SQL-01` | `CUS-G1` | Mixed ORG/EMP/CUSTOMER Contact rows; owner spoof and SQL LIMIT | One authorized branch per owner; SQL filter before COUNT/sort/limit; no owner spoof or cross-resource bypass | NOT_RUN |
| `CUS-TC-057` | `P2-AT-CUS-001-04` | `CUS-T-SQL-01` | `CUS-G1` | P1 Contact Organization cap overflow / missing trusted GROUP root | Fail closed, no unscoped fallback or fabricated root Organization | NOT_RUN |
| `CUS-TC-058` | `P2-AT-CUS-001-05` | `CUS-T-WF-01` | `CUS-G1` | Customer setstate ACTIVE<->INACTIVE, PATCH status injected | Only valid transitions through setstate; invalid PATCH rejected | NOT_RUN |
| `CUS-TC-059` | `P2-AT-CUS-001-01` | `CUS-T-DATA-01` | `CUS-G1` | Customer code trim/uppercase, DB unique, Numbering AUTO_IF_EMPTY/AUTO_REQUIRED | Canonical Group-unique code; series mode semantics, rollback and collision guarded | NOT_RUN |
| `CUS-TC-060` | `P2-AT-CUS-002-01` | `CUS-T-INT-01` | `CUS-G1` | Create CORRECTION referencing earlier NOTE same Customer+Company | Appends second row; corrects_interaction_id FK set; server timestamp; original unmodified | NOT_RUN |
| `CUS-TC-061` | `P2-AT-CUS-002-01` | `CUS-T-INT-01` | `CUS-G1` | CORRECTION references other Customer/Company/self/non-original/missing | Fail closed 422/authorized masking; transaction rollback; zero correction row committed | NOT_RUN |
| `CUS-TC-062` | `P2-AT-CUS-002-01` | `CUS-T-INT-01` | `CUS-G1` | Ordinary activity with correction ref or CORRECTION without ref | 422 validation; only CORRECTION may reference same-scope original | NOT_RUN |
| `CUS-TC-063` | `P2-AT-CUS-002-01` | `CUS-T-INT-01` | `CUS-G1` | Two corrections to one original, original inactive customer | All append-only preserved; latest by created_at and id; no auto-delete or historic mutation | NOT_RUN |
| `CUS-TC-064` | `P2-AT-CUS-001-01` | `CUS-T-API-01` | `CUS-G1` | Customer search/query whitelist, 50 default/100 cap and stable id sort | Invalid filter/sort/page rejected; no SQL injection; stable pagination; P1 envelope | NOT_RUN |
| `CUS-TC-065` | `P2-AT-CUS-002-01` | `CUS-T-API-01` | `CUS-G1` | Interaction GET without company_id, negative permission and count | Explicit Company required; Company SQL PBAC before count and page; no private information leak | NOT_RUN |
| `CUS-TC-066` | `P2-AT-CUS-001-02` | `CUS-T-DATA-01` | `CUS-G1` | Concurrent allowlist replacement + Customer activation | One valid committed ALL/LIST scope, no ACTIVE LIST empty and no partial rows | NOT_RUN |

## Release gates

- `CUS-G1 DESIGN_READY`: **APPROVED** by PO, documents/schema/API/security/test blueprint checked.
- `CUS-G1 IMPLEMENTED`: **NOT STARTED**; application code + migration + actual tests must be produced in separate authorized turn.
- `CUS-XMOD`: 9 open source-specific contracts; interaction, sales, receivable and COD reports need per-source permissions and actual event validity before UAT.
- `CUS-FULL ACCEPTED`: **NOT ACCEPTED**; must include 8 baseline acceptance cases and the approved addenda with actual runtime and negative regression evidence.
