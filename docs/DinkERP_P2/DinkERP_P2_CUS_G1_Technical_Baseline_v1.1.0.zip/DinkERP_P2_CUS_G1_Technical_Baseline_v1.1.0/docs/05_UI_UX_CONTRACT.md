# UI/UX Contract — Customer workspace tối giản

**Document ID:** P2-CUS-UI-001 · **v1.0.0**. Không phải screenshot, không phải UI đã code. Sử dụng shell, locale `vi/en`, Display Settings và table patterns của P1.

## 1. Route và screens

| UI ID | Route | Core status | Nội dung |
|---|---|---|---|
| `CUS-UI-01` | `/customers` | CUS-G1 | Search + table + sort/page/filter, create action |
| `CUS-UI-02` | `/customers/new` | CUS-G1 | Customer type, code/name/group, main address, Company ALL/list; create/validation |
| `CUS-UI-03` | `/customers/:id` | CUS-G1 + progressive | Workspace gồm tab Profile, Contact/Ship-to, Interactions; tabs Sales/Payments/Shipping trạng thái dependency |
| `CUS-UI-04` | `/customers/:id/edit` | CUS-G1 | Edit details/company allowlist, primary Contact, status riêng |

Không tạo `/customer-groups` UI; không tạo 6 bảng hoặc 6 SPA module vì có nhiều tab. Dùng layout/components P1 và permission-based actions; route exact spelling chốt trong router implementation review.

## 2. Danh sách Customer

Cột mặc định: customer_code, name, customer_type, group_code, phone, status, all_companies/Company count; không show amounts / note company-private trong Group list. Search theo code/name/tax/phone/email; filter type/group/status/Company eligibility; export chỉ nếu `customer.export` được phép. Không lọc dữ liệu nhạy cảm sau paginate.

## 3. Detail/workspace

| Tab | Trạng thái | UI behavior |
|---|---|---|
| Hồ sơ | CUS-G1 | Group Master, địa chỉ chính, MST, group/status, Company usage |
| Người liên hệ / Điểm giao hàng | CUS-G1 | Multiple P1 Contacts owner CUSTOMER; badge eligible/ineligible + lý do; primary contact không phải default ship-to |
| Nhật ký chăm sóc | CUS-G1 | Notes, calls, emails, meetings theo Company selector actor được xem; tạo append-only; không cho sửa silent history |
| Đơn hàng & Doanh số | SAL/INV later | Order history + 3 KPI riêng, Company/kỳ filter; thiếu nguồn => `NOT_AVAILABLE` |
| Thu tiền & Công nợ | FIN/SAL later | Posted receipts, allocated payments, open balance, overpayment, unapplied, aging; tách COD |
| Giao hàng & Trả hàng | SAL later | Shipments/tracking/return, links và permission per source |
| Tài liệu | DOC later | Attachments qua Document owner authorization; không fork storage |

**Điều kiện hiển thị:** source chưa triển khai => `DEPENDENCY_PENDING`, actor không có permission => `NOT_AUTHORIZED`/ẩn section theo UX policy; metric có dữ liệu hợp lệ bằng 0 => `READY` với value 0. Không show `0` giả khi không có tính toán.

## 4. Ship-to selector ở Sales (contract cho SAL)

`Sales Company → Customer ACTIVE+eligible → Contacts of CUSTOMER → computed ship-to eligible → explicit selection (multiple) → preview recipient/phone/address/province/ward → frozen SO snapshot`. No default in G1, no `is_shipping_address` flag, no live dereference after confirmation; record change only through audited Sales action if approved. Marketplace external address snapshot không tự ghi thành Contact.

## 5. Localization/presentation/security

- `Accept-Language: vi/en` theo workspace preference; mã code/status không dịch; number/date hiển thị qua Display Settings, calculation server DECIMAL + business timezone theo Company.
- Group-level Customer Data không được nhúng vào list Company Sales như aggregate vượt scope. Company selections chỉ bao gồm allowed Company IDs actor authorized.
- Khi backend báo unauthorized/dependency pending, frontend không cố tự tổng hợp hoặc lộ count/amount qua tooltip, pagination, export hay navigation.
- Error code stable, message localized; giữ form draft khi server conflict unique/scope.

## CUS-G1 technical UI contract v1.1.0

Customer Group selection options exactly: `— Chưa phân nhóm —` (SQL NULL), `STANDARD · Tiêu chuẩn`, `TMDT · Thương mại điện tử`, `VIP1 · Vip 1`, `VIP2 · Vip 2`. There is **no** `VIP` code/Customer Group CRUD. Core screen renders localized vi/en labels for these stable values; frontend uses same codes (contract parity tests against backend `CUSTOMER_GROUP()`). `TMDT` is a customer grouping and must **not** imply a sales channel or automatically assign PRC marketplace rules.

Interactions list filters by explicit Company and activity type. `CORRECTION` has an action “Đính chính” which chooses an original event from **same Customer + Company**, requests a reason, and displays a linked correction timeline; no inline edit or deletion. Company B notes must not appear in Company A counts, search or export. Sales/Receivables tabs stay dependency pending and never display dummy 0.
