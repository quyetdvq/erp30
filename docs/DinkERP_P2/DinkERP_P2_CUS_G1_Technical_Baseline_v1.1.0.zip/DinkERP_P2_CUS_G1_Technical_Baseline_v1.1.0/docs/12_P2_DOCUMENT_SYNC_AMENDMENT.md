# Amendment — những tài liệu P2 v1.0.0 phải đồng bộ trước triển khai

**Document ID:** P2-CUS-PARENT-DELTA-001 · **Status:** binding **CUS design amendment** sau quyết định của Product Owner; P2 v1.0.0 lưu như lịch sử DRAFT. Các file P2 draft **chưa được sửa hoặc hợp nhất trong tài liệu gốc**. Bản này cung cấp mapping chi tiết và source mới để cập nhật, tránh nhầm đã thay toàn bộ P2 v1.0.0.

| P2 source cũ | Nội dung CUS phải thay | Source thay thế trong pack |
|---|---|---|
| `modules/P2_CUS_INDEPENDENT_MODULE_SPEC.md` | 4 bảng + Customer Group CRUD + customer_notes => 3 bảng, controlled group code, interactions, ship-to contacts, indicators | `docs/01_..`, `02_..`, `03_..`, `04_..`, `05_..` |
| `docs/05_P2_DATABASE_DESIGN.md` | Bỏ `customer_groups`, `customer_notes`; bỏ `customers.customer_group_id` và `shipping_*`; bỏ `customer_company_usages.status`; dùng `customer_interactions`, `customer_group_code` | `docs/03_DATABASE_MINIMAL.md` |
| `docs/06_P2_API_DESIGN.md` | Bỏ Customer Group CRUD, notes/history endpoints draft; bổ sung `interactions`, deferred `transactions/sales-summary/receivables`; owner Contact | `docs/04_API_CONTRACT.md` + OpenAPI CUS |
| `docs/07_P2_UI_UX_DESIGN.md` | Bỏ `/customer-groups`; Customer workspace tabs, computed ship-to, deferred KPI status | `docs/05_UI_UX_CONTRACT.md` |
| `docs/08_P2_AUTHORIZATION_AND_AUDIT.md` | Thêm resource `customer_contact`, `customer_interaction`; PBAC nguồn KPI, SQL-first Company notes | `docs/06_PBAC_AND_SECURITY.md` |
| `docs/09_P2_INTEGRATIONS_AND_IDEMPOTENCY.md` | CUS cross-module payment and COD separation, Customer/Company owner checks | `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md` |
| `docs/14_P2_GAPS_AND_OPEN_DECISIONS.md` + `reference/P2_OPEN_DECISIONS.csv` | P2-DEC-007/008 resolved business; 009 design yes/technical open; add source-module blockers | `docs/10_OPEN_ITEMS_AND_GATES.md` |
| `docs/15_P2_TRACEABILITY_MATRIX.md` | CUS addendum CR and deferred tests | `reference/CUS_TRACEABILITY.csv` |
| `contracts/openapi/p2.draft.openapi.yaml` | Customer Group endpoints and Customer Group FK schema stale; CUS contract separate design file, merge after global review | `contracts/openapi/p2-cus.design.openapi.yaml` |
| `modules/P2_PRC_INDEPENDENT_MODULE_SPEC.md`, P2 PRC DB/API | `customer_group_id` FK -> `customer_group_code` code-aware lookup, no dynamic group table | `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md` |
| `modules/P2_SAL_INDEPENDENT_MODULE_SPEC.md` | SO ship-to immutable snapshot, delivery+posted-issue KPI, due date, returns credit, Customer ID company | `docs/07_..`, `08_..` |
| `modules/P2_FIN_INDEPENDENT_MODULE_SPEC.md` | posted payment allocations, refund/reversal, COD carrier remittance no double count | `docs/07_SAL_FIN_PRC_DEPENDENCY_CONTRACTS.md` |

**Quan trọng:** Bản P2 tổng hợp v1.0.0 hiện có **187 API draft**; khi bỏ 5 group endpoints và thay các endpoint liên quan, số đếm sẽ thay đổi. Không coi con số cũ, API draft YAML cũ và CR hiện hành là nhất quán sau khi chốt CUS. Khi phát hành P2 v1.0.1 nên regenerate toàn bộ P2 registry, OpenAPI, FRS, handbook và chạy audit liên kết; việc này **khác** với approved CUS-only doc pack này.

**Thứ bậc tài liệu:** Original UR v1.0.15 > PO approved 12 decisions / CR CUS > CUS design baseline này > P2 v1.0.0 DRAFT CUS sections. Other P2 module approved invariants vẫn nguyên và không bị CUS quyết định tự sửa.

## Further change v1.1.0 — P2 cross-module handoff

- P2 Group enum/PRC design must now recognize **four actual codes:** `STANDARD`, `TMDT`, `VIP1`, `VIP2`; no bare `VIP`; `NULL` permitted. Use `CUSTOMER_GROUP()` source function per approved PO specimen; no `customer_groups` or `customer_group_id` tables/columns.
- `customer_interactions` has `CORRECTION` plus nullable `corrects_interaction_id`; the CUS entity dictionary, API JSON Schema and test matrix are updated in this pack.
- Former seven `CUS-T-*` G1 technical open rows are now CLOSED_APPROVED. **9 downstream XMOD decisions remain OPEN**; no SAL/FIN/PRC/DOC code or original P2 v1.0.0 files have been modified by the CUS-only documentation release.
