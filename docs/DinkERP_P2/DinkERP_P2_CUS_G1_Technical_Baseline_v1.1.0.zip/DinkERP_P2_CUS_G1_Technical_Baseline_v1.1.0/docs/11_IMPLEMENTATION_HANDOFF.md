# Implementation Handoff — P2-CUS (tài liệu, chưa code)

**Change set:** G1 Customer Core, shared Contact owner extension and downstream contracts. **Base:** ERP v1.9.0 unchanged, P2 other modules deferred.

## 1. Phạm vi công việc khi bắt đầu CUS-G1 (G1 TECHNICAL DESIGN đã được chốt 7/7; bắt đầu khi chủ dự án cho phép code)

1. Migration additive tạo **3 bảng** CUS và ResourceAction/Lifecycle seeds tương thích P1; kiểm tra DBPrefix/FK and unique.
2. Backend service/repositories cho Customer/Company Usage/Interactions theo patterns Module P1 hiện hành; không tạo Identity/permissions/numbering library mới.
3. Extend `ContactRules`, `ContactScope`, `ContactScopeProvider`, `ContactSql`, `ContactService` and Contact GET validation with new CUSTOMER owner while keeping P1 regressions.
4. API `customers`, `actions/set-state`, `interactions` với P1 response envelope, stable errors, actor+timestamp, SQL authorization.
5. Frontend Vue `Customers` list + Customer workspace, vi/en, Display Settings; Company allowlist; Contact ship-to eligibility.
6. Tests PHP unit/service/DB integration/PBAC negative/migrations/Frontend; approved fixture rules.
7. Dependency tabs for SAL/INV/FIN/DOC return `NOT_AVAILABLE`/hidden until actual source available; no false 0 or fake test success.

## 2. Non-goals for CUS-G1

Không tạo `customer_groups`, `customer_addresses`, `customer_debts`, `customer_revenues`, `customer_notes` hay generic Customer transaction clone. Không implement SAL/FIN transactions inside CUS. Không thêm Lead/Opportunity. Không cập nhật P1 already issued numbers/history. Không cung cấp tín dụng hạn mức.

## 3. Interface invariants phải giữ

| Consumer | Contract |
|---|---|
| SAL | Customer ID stable, Company selectable check authoritative at create/confirm, Contact ship-to snapshot, nullable Customer marketplace |
| PRC | `customer_group_code` from CUS, stable controlled codes; Company-Pricing P1 precedence preserved |
| FIN | Customer+Company validated order allocations, non-reversed POSTED only, source amounts not duplicated |
| DOC | Customer attachment links PBAC; no CUS binary storage |
| Analytics/UI | Company/date/source guards, separate 3 KPIs, no fake zeros, as-of/reversal |

## 4. Pre-merge checklist

- Reference tests 8 original UR and 8 additive CR, all mapped to test registry.
- Reviewed PBAC `customer`, `customer_contact`, `customer_interaction`, admin no bypass, ROW SQL before LIMIT.
- Review SQL EXPLAIN/filters, null/collation/order, concurrent duplicate and Company allowlist race.
- Migrations forward-only and rollback only on DEV clone, no destructive P1 Contact changes.
- Reconcile P2 draft PRC `customer_group_id` and old CUS references before merging OpenAPI docs.
- QA proof includes actual runtime tests in test environment, not docs verification.

## 5. Control

Business decisions 12/12 and G1 technical decisions 7/7 are approved. Only remaining source-module XMOD design questions use `docs/10_OPEN_ITEMS_AND_GATES.md`; do not assume they are approved. New requirements via addendum/ADR, update traceability, bump version.

## G1 implementation-ready handoff delta 2026-10-28

- Create **only after work authorization** planned helper `backend/app/Helpers/customer_helper.php` with PO code map; tests compare source helper vs YAML/CSV/FE i18n. This pack contains **documentation, not the source helper file**.
- Migration: exactly 3 tables/**29** logical columns; `corrects_interaction_id` nullable self FK with same-Customer+Company guard enforced in application; no new group/address/AR table.
- Contact P1: add CUSTOMER owner with dual resource Group check and SQL-first third branch; old ORG/EMP tests must pass; no request-controlled Organization context.
- Customer/workflow: Group numbering, unique canonical customer code, lifecycle two states, Group/Company scope, ResourceActions seed not automatically granted.
- Interactions: 5 event types, correction same owner and earlier original; default timestamp server; no editing/deletion, retention not automatic.
- APIs: seven CUS-G1 endpoints only, 3 XMOD deferred; run Swagger/OpenAPI schema parity and authorization negative tests on DEV clone before UAT.
