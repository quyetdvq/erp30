# P2-CUS-G1 — Bảy quyết định kỹ thuật đã chốt

**Document ID:** P2-CUS-G1-TECH-ADR-001 · **Version:** 1.1.0 · **Approved 2026-10-28**  
**Authority:** Product Owner approved all 7 proposed A, **including** `CORRECTION` + `corrects_interaction_id` and **amended GROUP-01** to the exact `CUSTOMER_GROUP()` map supplied in the approval message.  
**Status:** `APPROVED_TECHNICAL_DESIGN / READY_FOR_IMPLEMENTATION (DESIGN ONLY)`; **no code/database modified; no runtime tests executed**.  
**Precedence:** original UR 1.0.15 + 12 business decisions and D addenda + this seven-item PO technical approval > older CUS v1.0.0 technical DRAFT.

## Approved design decision register

| ID | Technical decision locked by PO | Owner/source | G1 status |
|---|---|---|---|
| `CUS-T-GROUP-01` | `CUSTOMER_GROUP()` controls exactly `STANDARD`, `TMDT`, `VIP1`, `VIP2` (labels below); nullable customer group; code-based PRC linkage | CUS/PRC | APPROVED |
| `CUS-T-SEC-01` | `CUSTOMER` contacts belong to GROUP-shared master; require `customer.view` **and** `customer_contact.<action>` at GROUP; Company notes remain private | Security/BE | APPROVED |
| `CUS-T-SQL-01` | Owner-aware SQL-first Contact union branch CUSTOMER; Group PBAC before count/sort/page, fail-closed, preserve P1 ORG/EMP paths | BE/Security | APPROVED |
| `CUS-T-WF-01` | Customer ACTIVE/INACTIVE via lifecycle `setstate`; Contact reuses P1 lifecycle; interactions append-only with no business state; ResourceAction catalog as below | BE/PO | APPROVED |
| `CUS-T-API-01` | 7 core API routes, 3 deferred readers, P1 response/error format, strict allowlist sort/filter/page and id tiebreak | BE/FE | APPROVED |
| `CUS-T-DATA-01` | Group-unique customer code, P1 numbering, location consistency, Group/Company usage transaction, no destructive P1 migration | DBA/BE | APPROVED |
| `CUS-T-INT-01` | `NOTE/CALL/EMAIL/MEETING/CORRECTION`; append-only + same-Customer/same-Company corrective reference; no auto-purge | PO/BE | APPROVED |

### T-01. Customer groups — exact PHP function list

**Four active codes, no fifth `VIP` literal:** `STANDARD` → `Tiêu chuẩn`, `TMDT` → `Thương mại điện tử`, `VIP1` → `Vip 1`, `VIP2` → `Vip 2`. The phrase “STANDARD, VIP” in the approval note is a general category reference; **the supplied function keys are the canonical literal codes**. `NULL` is an optional unassigned value, **not** an array key. No `customer_groups` DB table and no group CRUD API.

**Design-only planned helper** (this text is a specification, NOT a committed PHP source change):

```php
<?php

if (!function_exists('CUSTOMER_GROUP')) {
    function CUSTOMER_GROUP()
    {
        return array(
            'STANDARD' => 'Tiêu chuẩn',
            'TMDT'     => 'Thương mại điện tử',
            'VIP1'     => 'Vip 1',
            'VIP2'     => 'Vip 2',
        );
    }
}
```

Plan location: `backend/app/Helpers/customer_helper.php` (P1 source currently has only `.gitkeep` in this helper folder); load through CI4 `helper('customer')` in the CUS composition root/service integration. Do **not** create that source file in this documentation-only change. `CUSTOMER_GROUP()` returns **code=>Vietnamese label**; `customer_group_code` stores only the **code** (or SQL NULL). Group may be omitted/null to mean unassigned; empty selection from UI is normalized to `null`; string `'NULL'`/`'VIP'` and unknown code are rejected; trim then uppercase code before membership check. On PATCH field omitted means unchanged, explicit `null` clears group. Consistency of frontend vi/en labels is managed by UI locale keys for the same codes (no extra API, no frontend numeric IDs).

Codes are immutable identities; change labels only in a versioned release with test updates. Retirement requires a new ADR, must retain recognition/display of historic values without reassigning identity, and must never silently reprice confirmed Sales Orders. `TMDT` is a **customer segment**, not the marketplace/source channel `EXTERNAL_CHANNEL`. Pricing P2-PRC joins by stable `customer_group_code`, not `customer_group_id`.

### T-02. CUSTOMER Contact ownership and authorization

`customer` and its `CUSTOMER` contacts are shared Group masters. `contacts` has **no Company owner column**; do not invent one. Persisted owner pair is immutable: `(contact_type='CUSTOMER', contact_ref_id=customers.id)`; synthesized evaluation Organization is the **one persisted root GROUP node**, resolved server-side (never request hint). For Contact `view`/`create`/`edit`/`setstate`, check at least `customer.view@GROUP` **AND** the matching `customer_contact.action@GROUP`; also validate owner Customer/status/ship-to eligibility where appropriate. Never treat Company eligibility as PBAC permission. An actor with Group rights may see Customer Contact addresses globally under those rights, while interactions and later financial transactions remain Company scoped.

### T-03. SQL-first Contact scope integration

P1 `ContactSql.php` has ORGANIZATION/EMPLOYEE OR branches. Extend with a **third** branch requiring `UPPER(TRIM(c.contact_type))='CUSTOMER'`, `EXISTS` persisted `customers` whose `id=c.contact_ref_id`, verified singleton root GROUP scope and positive PBAC for `customer.view` and `customer_contact.view`. Reuse P1 prefix/table-identifier protection; use parameter binding. For mixed-owner collections, construct **only** authorized branches (`org`/`employee`/`customer`) with matching resource scopes, fail-closed when none; use the exact same predicate for COUNT and rows before ORDER/LIMIT/OFFSET. P1 enumeration cap `>512` Organizations remains fail-closed for the branches that use it; no widening or bypass. The existing `(contact_type,contact_ref_id)` index is already in P1 migration. P1 owner transfer remains rejected. Verify owner mismatch, no indirect Group auth from Company, inactive Customer/contact behavior and P1 ORG/EMP negative regressions.

**Important:** The snippet above describes a future **implementation strategy**, not a claim that P1 Contact has CUSTOMER support. G1 code must extend `ContactRules`, `ContactScope`, `ContactScopeProvider`, `ContactSql`, `ContactService` and appropriate API/authorization wiring together.

### T-04. ResourceActions, lifecycle and audit

| Resource | Actions authorized through P1 PBAC | Evaluation Organization | State |
|---|---|---|---|
| `customer` | `view`, `create`, `edit`, `setstate`, `export` (reserve export permission; no new export endpoint in 7-Core-API contract) | Root GROUP | `ACTIVE` ↔ `INACTIVE`, initial `ACTIVE` only when valid |
| `customer_contact` | `view`, `create`, `edit`, `setstate` | Root GROUP + owning customer.view check | Reuse Contact P1 state/transition registry |
| `customer_interaction` | `view`, `create`, `export` (reserve export permission) | Persisted `company_organization_id` | No business state, append-only |

Transitions for Customer `ACTIVE → INACTIVE` and `INACTIVE → ACTIVE` require `customer.setstate` and a configured P1 lifecycle definition/transition; no status change via normal PATCH. Interactions have no edit/delete/status transition. Seed ResourceAction/Workflow via existing P1 mechanism, not new tables; **seeding does not grant permissions**. Shield/Assignment/PBAC `ABSOLUTE_DENY` and no System Admin bypass remain binding. Export action is separate from view and must never become an unguarded endpoint.

### T-05. API contract

**Exactly seven CUS Core operations:** Customer GET list, POST create, GET by id, PATCH by id, POST set-state, GET interactions, POST interactions. No `/customer-groups`, `/customer-addresses`, `/customer-interactions/{id}` mutation endpoints. Reuse P1 Contact routes after verified owner extension. Three readers `transactions`, `sales-summary`, `receivables` remain `DEPENDENCY_PENDING`, not released or implemented at G1.

List Customer: optional `q` (code/name/phone/email/tax), exact filters `customer_type,status,customer_group_code,company_id` (Company filter = usage eligibility, not authorization), page integer ≥1 default 1, page_size ≥1 default 50 cap 100, optional `sort` allowlisted `id,customer_code,name,customer_type,customer_group_code,status,created_at` with `-` for descending and stable `id` tie-break. Interactions: require explicit authorized `company_id` in GET, page/page_size same bounds, optional `activity_type`, `from`, `to`; deterministic `(happened_at DESC,id DESC)`. Unknown sort/filter/query -> 400; duplicate Group code -> 409; invalid group/Company scope/foreign correction -> 422, authorization 401/403/404 per P1 disclosure semantics. P1 `{data,meta}` and `{error:{code,message,details},meta:{request_id}}` envelopes; code independent of vi/en; amounts later only from source modules and only when authorized. See `docs/04_API_CONTRACT.md` and OpenAPI 3.1 YAML for exact payload/JSON Schema.

### T-06. Customer data and three-table migration

`customers` has Group-unique canonical `customer_code` (trim, ASCII uppercase for manual code; database unique index authoritative) and stable ID; validate generated Numbering output against 50-char target without imposing restrictions conflicting with configured P1 pattern. P1 `AUTO_REQUIRED` / `AUTO_IF_EMPTY` are the only configured automatic modes; resource `customer` uses GROUP scope; if no eligible active series apply manual-code rule. Numbering, create and usage inserts share transaction/unique check; do not clone allocator/counters. If `ward_id` exists, `province_id` must exist and ward must belong to province; validate active geo choices for new data; preserve historical references. `tax_code` non-unique. `ALL`: `all_companies=1`, zero usage rows. `LIST`: `all_companies=0` and ≥1 distinct active Company for ACTIVE Customer. Replace list with parent-row lock and atomic transaction; do not delete historic SAL facts. Database `DBPrefix`, charset, collation and actual FK SQL must be verified against DEV before migration (implementation verification, **not another PO design decision**).

### T-07. Interaction types, correction and retention

`activity_type` exactly `NOTE`, `CALL`, `EMAIL`, `MEETING`, `CORRECTION`. Add nullable **`corrects_interaction_id BIGINT UNSIGNED` FK → `customer_interactions.id`**, with NO cascade deletion. Non-CORRECTION types must have NULL `corrects_interaction_id`. CORRECTION must carry a positive valid reference to an **earlier, non-CORRECTION** interaction for **same Customer and same persisted Company**; content must explain correction; no cross-Customer/Company pointer. Multiple corrections to one original are allowed; effective latest displayed revision is last by `(created_at,id)` while audit/history keeps all entries. Correction `happened_at` and `created_at` are assigned by server at correction commit (no backdating); normal event `happened_at` optional validated business instant, defaults server now; `created_by` always server-derived for interactive usage. No PATCH/DELETE; no automatic purge at G1, retention future change-controlled policy. SQL-first Company filter and PBAC for original/correction list, details and counts. On correction target validation lock/transaction to prevent inconsistent owner scope.

**Total CUS logical tables remains THREE; logical columns become TWENTY-NINE (18 + 2 + 9).** No new CUS balance, Customer Group, customer_addresses or Customer Contact table.

## Gate ruling

`CUS-G1 TECHNICAL DESIGN READY`: **7/7 approved; no remaining G1 design blocker.** Next activity is implementation in an isolated branch/DEV clone with P1 regression and runtime validation. The nine source-module XMOD items remain OPEN and are **not** waived by these G1 approvals. No P2-CUS source or DB has been changed by this documentation update.
