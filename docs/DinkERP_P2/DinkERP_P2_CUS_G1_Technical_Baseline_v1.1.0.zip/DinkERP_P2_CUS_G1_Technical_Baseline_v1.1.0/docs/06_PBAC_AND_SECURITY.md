# PBAC, Identity, Company Scope và Audit — CUS

**Document ID:** P2-CUS-SEC-001 · **P1 contract inherited, P2 resource additions are design-approved conceptually, technical seeding pending.**

## 1. Security boundaries

- `customer` là Group Master: authorize canonical `GROUP` for shared create/update/view/setstate. Company list is business *eligibility for new transactions*, **not** authorization.
- `customer_interaction` thuộc `COMPANY` persisted, authorize at `company_organization_id`. Multiple Company access only if actor permitted per Company; no cross-Company lane merge.
- `customer_contact` uses existing P1 Contact resource approach extended to owner `CUSTOMER`; owner `(contact_type, contact_ref_id)` authoritative, immutable, not inferred from request context.
- `customer.sales_summary`/financial summary authorization requires both aggregate-level policy (if introduced) and the underlying source Data Resource/Action/Company filter. `customer.view` does not grant finance data.
- No System Admin bypass; Shield User→Employee→effective Assignment→PBAC base permission/policy. Inheritance `GROUP`→exact ancestor; `ABSOLUTE_DENY` propagated as P1.

## 2. Candidate Resource/Action catalog

| Resource | Actions proposed | Evaluation Organization |
|---|---|---|
| `customer` | `view/create/edit/setstate/export` | GROUP for Group Master |
| `customer_contact` | `view/create/edit/setstate` | Verified Customer owner; persisted root GROUP PBAC + required customer.view; technical gate APPROVED |
| `customer_interaction` | `view/create/export` | Saved `company_organization_id` type COMPANY |
| Customer KPI reader | `view` or specific metric-view action TBD | Authorized Company/source, not Group blanket |
| `sales_order`, `shipment`, `sales_return`, `money_receipt` | Source `view` and `export` as configured | Persisted source Company per P2 module |

No new permission table. Catalog ResourceAction registered using P1 Resource/Action registry and approved Group assignments/Policy. ACTION `export` is independent of `view`.

## 3. Contact P1 modification boundary

Verified source: `backend/app/Modules/Contact/ContactRules.php` has exactly `ORGANIZATION`/`EMPLOYEE`; `ContactScope.php` chooses Organization or effective Employee Primary; `ContactScopeProvider.php` only supports `organization_contact` and `employee_contact`; `ContactSql.php` compiles SQL authorization predicates for those two branches. Thus `CUSTOMER` requires all four coordinated changes plus controller/service/read tests and seed of ResourceAction/Workflow. Inserting `contact_type='CUSTOMER'` alone is invalid.

For Customer contact owner, authoritative `customers.id` exists, resource `customer_contact`, Organization evaluation cannot come from request/client hint. P1 Contact SQL list includes authorized organization/employee branches; new Customer branch must be integrated **before** filtering/pagination. Resolved `CUS-T-SEC-01`: Customer Contacts are Group-shared and require dual GROUP PBAC (`customer.view` and `customer_contact.<action>`); interactions are Company-private. P1 Contact owner CUSTOMER is still future implementation work.

## 4. Interaction SQL scope and negative cases

Authorized filter minimum: `customer_id=target` and `company_organization_id IN permitted-company-ids` and the actor has `customer_interaction.view` at each Company. Reject untrusted `company_id` not type COMPANY, not allowed or outside Customer usage for **new** event. No count leak, no ordering/projection leak, no export leak. For historical records, current usage scope changes should not delete history; final historical read scope solely PBAC.

On primary Contact update, stored Contact must have `contact_type='CUSTOMER' AND contact_ref_id=customer.id`, regardless of permission to another Customer. Contact routing must not grant Customer permission through `employee_contact`/`organization_contact`. Wrong-owner/foreign Company source -> deny, no partial writes.

## 5. Access to SAL/FIN data

1. Apply Company and Resource view permissions **before** constructing list/aggregate.
2. If actor may view `sales_order` but not `money_receipt`, show order summary only; receipt and receivable totals suppressed when not faithfully computable without finance data.
3. Unknown/deferred source => `DEPENDENCY_PENDING`; denied source => not authorized, never `0`.
4. Per-source navigation/external documents enforce permission again at access time; do not use CUS fetch as authorization token.
5. Request/user/employee context, actor/timestamp and decision reason follow P1 audit and error convention; note contents potentially personal data, apply least privilege.

## 6. Security test matrix highlights

- Company A-only role cannot access B interactions using list, direct ID, sort pagination, count, export or summary.
- Base permission missing=>deny even if Policy ALLOW; `ABSOLUTE_DENY` cannot be opened through assignment lanes.
- Contacts owner spoofing, primary-contact mismatch, status bypass, context hint mismatch rejected; Organization/Employee contact regression remains PASS.
- Master Group access must not accidentally expose Company-private financial data; query-level SQL scoped and negative tests.

## G1 Technical closure: Customer Contact at GROUP and SQL strategy

The approved `CUS-T-SEC-01` resolves the former open owner scope: `CUSTOMER` Contact is a Group-shared Customer master child. Require `customer.view@GROUP` and `customer_contact.<action>@GROUP` for Contact use. The owner is verified from persisted `contacts.contact_type/contact_ref_id` and persisted `customers.id`; root Group Organization is resolved from P1 trusted Organization tree, **not** the request body. Company allowlist never grants permission; Company-private interactions use persisted Company PBAC independent of Group master.

`CUS-T-SQL-01`: add a third, independently authorized `CUSTOMER` branch to P1 Contact SQL-first query, preserving the Organization and Employee branches. Use owner EXISTS, trusted Group PBAC and identical authorized scope for COUNT and rows before LIMIT. P1 Contact `(contact_type,contact_ref_id)` index exists. Fail-closed for unavailable root/scopes or Organization cap; never treat `customer_contact` as `organization_contact` or `employee_contact`. A GROUP-privileged user may see Contact ship-to details across Companies by design; no Sales/FIN Company transactions are implicitly exposed.

ResourceAction/lifecycle frozen at `docs/14_G1_TECHNICAL_DECISIONS_APPROVED.md`. `customer_interaction` has no business state, only view/create/(independent export); correction service verifies same Customer+Company and original event under transaction. Neither 7-Core-API readers nor Contact owner changes have been implemented in v1.9.0.
