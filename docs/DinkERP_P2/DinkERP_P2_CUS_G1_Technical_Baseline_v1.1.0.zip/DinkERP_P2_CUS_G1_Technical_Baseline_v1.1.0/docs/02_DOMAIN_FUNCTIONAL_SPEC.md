# Functional Specification — Customer Core + liên module

**Document ID:** P2-CUS-FRS-001 · **v1.0.0** · **Trạng thái:** chức năng/kiến trúc đã được duyệt, chi tiết tích hợp tương lai gắn gate.

## 1. Customer Master (CUS-C-01..06)

| Use case | Tiền điều kiện / luồng | Hậu điều kiện |
|---|---|---|
| CUS-C-01 Create | Actor có `customer.create` tại Group, validate loại/nhóm, tên/code, main address, chọn ALL hoặc Company allowlist | Tạo Customer 1 lần toàn Group; number P1 nếu bật; transaction atomically tạo usages |
| CUS-C-02 List/search | `customer.view`; query `code/name/phone/email/tax_code/customer_type/group/status`, sort allowlist, paging | Kết quả chỉ gồm Customer actor có thể view; không tự đưa Finance KPI vào danh sách |
| CUS-C-03 Detail/edit | Chỉ được sửa mutable fields, kiểm tra persisted target/permission; reject `status` trong PATCH thông thường | Audit actor/time; uniqueness enforced DB; không renumber historical ID |
| CUS-C-04 Status | Lifecycle `ACTIVE/INACTIVE` với `customer.setstate`; trạng thái qua workflow, không bypass | ACTIVE usable nếu Company eligible; INACTIVE không giao dịch mới, history vẫn đọc |
| CUS-C-05 Company Usage | `all_companies=true` => zero allowlist rows; `false` => ít nhất 1 Company hợp lệ khi ACTIVE; all rows type COMPANY | Thay đổi toàn bộ list trong một DB transaction/lock; không xóa/sửa SO lịch sử |
| CUS-C-06 Shared Contact | Xem/ghi contact owner `CUSTOMER` qua resource `customer_contact`; owner ID immutable | N Customer contacts; `primary_contact_id` chỉ thuộc Customer hiện tại và không phải ship-to default |

**Dữ liệu Customer đề xuất:** `customer_code`, `name`, `customer_type` (`INDIVIDUAL`/`ORGANIZATION`), `customer_group_code`, `phone`, `email`, `tax_code`, địa chỉ chính/Province/Ward, Company scope, status, audit. `tax_code` nonunique; có thể tìm kiếm. `customer_group_code` không được nhận arbitrary code do người dùng gửi; bộ codes đã được khóa theo `CUSTOMER_GROUP()` gồm `STANDARD/TMDT/VIP1/VIP2`, cho phép NULL; xem quyết định `CUS-T-GROUP-01`.

**Trạng thái:** `ACTIVE`/`INACTIVE` là trạng thái business được duyệt ở scope cơ bản. Workflow Resource state/transition registrations và status API vẫn tuân P1, không update status bằng generic PATCH.

## 2. Contacts và shipping (CUS-C-07..09)

- Người liên hệ chính là một optional Customer Contact; không bắt buộc phải đủ địa chỉ giao hàng.
- Không cần bảng địa chỉ. Contact `CUSTOMER` + active + name người nhận + phone/mobile + address detail + province/ward active và liên hệ đúng chủ = eligible ship-to.
- Contact chỉ có email/phone vẫn là Contact hợp lệ, **không** eligible ship-to.
- Người nhận giống nhau ở hai địa chỉ được lưu thành hai Contact rows. Không ép dedupe dựa trên tên hoặc số điện thoại.
- Không có ship-to mặc định trong CUS G1; Sales bắt người dùng chọn khi có nhiều địa chỉ. One-off shipping destination cho Sales không tự thêm Contact.
- Marketplace shipping address tự do theo dữ liệu bên ngoài vào Sales snapshot, không tự ghép Contact hay Customer.
- Khi Customer inactive/Company ngoài usage/Contact inactive/owner không đúng thì chặn việc chọn ship-to cho SO mới.
- `customer_contact.view` không tự đủ cho việc tạo Sales Order; cần `sales_order.create` và Company eligibility/PBAC.

## 3. Interactions (CUS-C-10..12)

- Một interaction thuộc **chính xác một** persisted Company (`company_organization_id`) và một Customer; `activity_type` đã khóa `NOTE/CALL/EMAIL/MEETING/CORRECTION`; actor và event time server validated.
- P2 Core lưu tương tác append-only. Correction được ghi một event mới được liên kết audit (schema tối giản không có explicit `corrects_id`; nội dung correction cần tham chiếu ID bản ghi bị sửa và lý do). Không delete/edit overwrite lịch sử cũ.
- Truy vấn `company_id`, date window, `activity_type`, pagination với Company SQL scope **trước** count/sort/limit; không trả thông tin Company B cho actor chỉ có Company A.
- Tác vụ list/export phải có `customer_interaction.view`/`export` riêng; View không suy ra Export.

## 4. Lịch sử giao dịch & báo cáo (CUS-M-01..07; integrated later)

Customer workspace phải truy vấn nguồn live sau khi có module:

| Phần hiển thị | Nguồn / điều kiện |
|---|---|
| Sales Orders | SAL, Customer ID nguồn và Company; không suy diễn Customer từ phone |
| Shipment | SAL Shipment liên kết Order; chỉ hiển thị nếu `shipment.view` + Company authorized |
| Sales Return | SAL return/credit, chỉ accepted state được định nghĩa giảm doanh số |
| Money Receipt/Refund | FIN POSTED, đúng Customer/order link, tránh liên kết thông tin bị coi là thanh toán |
| Order Value | SAL confirmed order snapshot; tính một lần theo Order, không sum theo shipments |
| Fulfilled Goods Value | SAL/INV với Delivery confirmed + Stock Issue POSTED, quantity partial và no duplicates |
| Net Operational Sales | Fulfilled goods value trừ approved commercial return credits, không trừ money refunds hai lần |
| Receivables | SAL obligations + FIN payment allocations/reversals; không tạo bảng `customer_balance` |
| Past Due | Order due_date < business date Company và outstanding dương; missing due_date unclassified |
| COD Pending Carrier | Đã xác nhận carrier thu từ khách nhưng chưa payout, độc lập tiền đã POSTED về account |

**Không dùng `customer.view` duy nhất để đọc Sales/Finance**; permissions theo nguồn và Company trước aggregate. KPI chưa có backend nguồn: `DEPENDENCY_PENDING`/`NOT_AVAILABLE`, không hiển thị số `0`.

## 5. Invariants, edge cases

1. Customer code unique toàn Group, mã số thuế **không** unique. Normalize code theo P1 string identity convention, không tự invent normalizer khác; unique DB vẫn là chốt sau cùng.
2. Một Customer có thể được dùng tại nhiều Company, nhưng mỗi SO, Shipment, Money Receipt/Expense, interaction vẫn đúng một Company owner.
3. Remove usage scope chỉ chặn **giao dịch mới** (không orphan historical reference); historic read do PBAC của từng nguồn quyết định.
4. Shipping Contact không có FK polymorphic tự động tới Customer: owner pair phải được kiểm tra server-side; không cho transfer owner qua PATCH.
5. User-defined shipping destination chỉ xuất hiện khi SAL phê duyệt; snapshot immutable sau confirmation hoặc thay qua action được audit.
6. P2 Core chỉ quản lý quan hệ Customer: không Lead/Opportunity, full AR, credit blocking, invoice/tax ledger, không cross-Company money allocation.
7. Kiểm tra same Company/currency, status, quantity/amount, partial deliveries, idempotency và reversal tại module nguồn, CUS chỉ đọc results.
8. Price List/Pricing Context P2 phải dùng `customer_group_code` làm matching key stable; Customer không tính price.
9. Show linked source only if actor has permission for that resource and Company. Click-through re-authorize independently.

## 6. Lịch phát hành

**Core release (CUS-G1):** CRUD, contact, company scope, interactions, search, PBAC, UI. **XMOD release:** transaction history, doanh số/công nợ/COD khi nguồn INV/SAL/FIN hoàn thành; không giả lập endpoints như đã triển khai.

## CUS-G1 technical closure (binding v1.1.0)

- **Group list:** fixed helper `CUSTOMER_GROUP()` => `STANDARD=Tiêu chuẩn`, `TMDT=Thương mại điện tử`, `VIP1=Vip 1`, `VIP2=Vip 2`, with SQL NULL for unassigned. No `VIP` literal; no group DB table; UI vi/en labels for same keys. PRC may match only canonical code.
- **Customer Contact:** group-shared under GROUP PBAC with **both** `customer.view` and `customer_contact.<action>`; notes remain Company-private. New CUSTOMER owner path must integrate SQL-first with existing P1 Contact branches.
- **Customer lifecycle:** `ACTIVE`/`INACTIVE`, default ACTIVE when create valid, only `setstate` transitions; no generic status PATCH.
- **Interactions:** enum `NOTE/CALL/EMAIL/MEETING/CORRECTION`. `CORRECTION` requires `corrects_interaction_id` to an earlier **non-CORRECTION event of same Customer + Company**, append-only, retains origin. For non-correction must be NULL; correction timestamp server-now, no historical overwrite.
- **Customer API and data:** frozen seven Core operation designs, full validation/whitelist described in docs/04 and docs/14; `customer_code` Group unique, Numbering P1 GROUP scope; allowlist replaced transactionally. Unimplemented dependent reports stay pending, not zero.
