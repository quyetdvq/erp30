# CUSTOMER_GROUP() — Danh mục nhóm khách hàng đã khóa

**Approved scope:** `CUS-T-GROUP-01` · **Design-only** · 2026-10-28 · CUS-G1.  
The following is the approved **function contract and proposed PHP source**, included as documentation. **It has not been added to the ERP codebase.**

```php
<?php

if (!function_exists('CUSTOMER_GROUP')) {
    function CUSTOMER_GROUP()
    {
        return array(
            'STANDARD' => 'Tiêu chuẩn',
            'TMDT'     => 'Thương mại điện tử',
            'VIP1'     => 'Vip 1',
            'VIP2'     => 'Vip 2',
        );
    }
}
```

| Code | Label (vi) | Save to `customers.customer_group_code` | Rule |
|---|---|---|---|
| `STANDARD` | Tiêu chuẩn | `STANDARD` | Active code |
| `TMDT` | Thương mại điện tử | `TMDT` | Active code; **not** Sales marketplace channel |
| `VIP1` | Vip 1 | `VIP1` | Active code |
| `VIP2` | Vip 2 | `VIP2` | Active code |
| `NULL` (not a function key) | Chưa phân nhóm | SQL `NULL` | Optional group/no selection |

**Planned integration location:** CodeIgniter 4 `backend/app/Helpers/customer_helper.php`, invoked via `helper('customer')` then `CUSTOMER_GROUP()`; no existing helper file or code touched here. Function guard `function_exists('CUSTOMER_GROUP')` follows exact PO preference. Implement unit test ensuring order, exact keys and Vietnamese labels; compare with `reference/CUS_CUSTOMER_GROUP_CODES.csv`, the OpenAPI schema and Vue i18n enum. No extra group table, source-managed list, no new group CRUD endpoint.

**Input/output:** `null` / omitted / blank UI selection -> `NULL` on POST (on PATCH: omit retains existing; explicit `null` clears). For a nonblank string, `strtoupper(trim(value))`, then allow only `array_keys(CUSTOMER_GROUP())`; reject `'VIP'`, `'NULL'`, unknown codes, and non-string non-null values with canonical 422 `CUSTOMER_GROUP_CODE_INVALID`. API returns stable canonical code or `null`, **not** the translated label as an identity. Frontend label is localized separately; labels from this helper are baseline Vietnamese.

**PRC integration:** match `customer_group_code` (not `customer_group_id`), keep P1 Company > Group > default precedence, channel-specific and promotion-specific specificity must be locked at PRC G3. Changing a Customer group must not reprice already confirmed order snapshots. Adding/renaming/retiring codes is a controlled release; never silently reassign a code to a different meaning. No dynamic administration in G1.
