# Open items & gates — P2-CUS v1.1.0

**Approved:** `CUS-X-01…12` = 12/12 A + rules D; `CUS-T-*` = **7/7 approved 2026-10-28**.  
**G1 DESIGN:** `READY_FOR_IMPLEMENTATION (DOCUMENTATION)`; **RUNTIME:** NOT_STARTED/NOT_TESTED.  
**Remaining OPEN:** **9 XMOD items**, governed by owning future modules. No new G1 design blocker.

## 1. G1 technical items — CLOSED / APPROVED

| ID | Binding decision | Status |
|---|---|---|
| `CUS-T-GROUP-01` | `CUSTOMER_GROUP()` with EXACT `STANDARD/TMDT/VIP1/VIP2`; NULL permitted; no literal VIP | CLOSED_APPROVED |
| `CUS-T-SEC-01` | CUSTOMER Contacts shared at GROUP, require Customer + Contact PBAC; interactions Company-private | CLOSED_APPROVED |
| `CUS-T-SQL-01` | SQL-first Customer Contact branch, no mixed-owner leakage, existing P1 512 cap fail-closed | CLOSED_APPROVED |
| `CUS-T-WF-01` | Customer ACTIVE/INACTIVE setstate, P1 Contact lifecycle, interaction append-only; ResourceActions | CLOSED_APPROVED |
| `CUS-T-API-01` | 7 Core routes, 3 deferred, exact query/error/enums/limits frozen in API/OpenAPI v1.1 | CLOSED_APPROVED |
| `CUS-T-DATA-01` | 3 tables, 29 columns, P1 Numbering, Group unique code, FK/Company atomic allowlist | CLOSED_APPROVED |
| `CUS-T-INT-01` | NOTE/CALL/EMAIL/MEETING/CORRECTION and self-FK corrects_interaction_id, no purge | CLOSED_APPROVED |

**Source of precise details:** `docs/14_G1_TECHNICAL_DECISIONS_APPROVED.md` and `docs/15_CUSTOMER_GROUP_FUNCTION_CONTRACT.md`. Implementation-time schema/DBPrefix/EXPLAIN/running Numbering verification are mandatory tests and engineering checks, **not unresolved PO design choices**. Approval does not mean deployed software or tests passed.

## 2. Các hạng mục tích hợp còn OPEN tại module nguồn

| Mã | Chi tiết cần hoàn tất | Gate |
|---|---|---|
| `CUS-T-SEC-02` | Permission riêng cho sales-summary/receivables và source authorization fallback, aggregate suppression | G3/G4 |
| `CUS-SAL-01` | Lifecycle SO, partial cancellation, direct pickup equivalent delivered event, frozen price components/taxes/fees | G3 |
| `CUS-SAL-02` | Return commercially-approved credit event/time and partial goods/discount/COMBO rounding | G3/G4 |
| `CUS-FIN-01` | money_source_links typed payment/refund allocations, N:M locking, overpayment, reversal and unapplied prepayments | G4 |
| `CUS-FIN-02` | Due_date source/default term, aging as-of retroactive events, refunds on allocated cash and backdate policy | G4 |
| `CUS-COD-01` | Provider collected/remitted/settled statuses, payout many shipments, fees and no double count | G4 |
| `CUS-PRC-01` | Replace P2 draft customer_group_id FK with stable customer_group_code matching plus specificity/tie-break | G3 |
| `CUS-DOC-01` | Document owner Customer and file permission/retention, future attachment tab | G1 DOC |
| `CUS-REPORT-01` | Định nghĩa cuối kỳ/holiday/date filtering, exact aggregation sources, response availability/auth/error mapping | G4 |

**Gate CUS-XMOD:** các mục này được sở hữu bởi SAL/INV/FIN/PRC/DOC; CUS chỉ chuẩn bị hợp đồng và client read projection. Không thêm bảng CUS vì các mục chưa chốt.

## 3. Parent P2 synchronization

The old P2 v1.0.0 draft CUS tables/endpoints remain superseded by this pack. See `docs/12_P2_DOCUMENT_SYNC_AMENDMENT.md` for mappings. PRC must replace `customer_group_id` with stable canonical `customer_group_code`, matching the four helper keys.

## 4. Permissible release status

| Gate | State as of 2026-10-28 | Evidence required next |
|---|---|---|
| 12 business CUS-X decisions | APPROVED | PO answer in conversation, decision record |
| Seven CUS-G1 technical A decisions | APPROVED; DESIGN READY | This v1.1.0 pack + structural QA |
| CUS-G1 implemented | NOT STARTED | Code/migration/API/UI, P1 regression + DEV clone evidence |
| CUS Core closed | NOT ACCEPTED | 8 source AC as applicable + runtime QA |
| CUS XMOD contract locked | PARTIAL BUSINESS CONTRACT / 9 OPEN | SAL/INV/FIN/PRC/DOC source owners approve details |
| CUS full accepted | NOT ACCEPTED | Live source module E2E, finance reconciliation and security tests |
