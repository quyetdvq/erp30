# CUS Decision Record — chốt 12/12 phương án A

**Document ID:** P2-CUS-ADR-001 · **Version:** 1.0.0 · **Decision date:** 2026-10-28  
**Approval evidence:** Chủ sở hữu sản phẩm chọn phương án A cho `CUS-X-01`…`CUS-X-12`, đồng ý tất cả quy tắc mục D, không có ghi chú.  
**Status:** `APPROVED — BUSINESS DESIGN` plus **`CUS-G1 TECHNICAL DESIGN APPROVED 7/7`** (2026-10-28); runtime not started. See `docs/14_G1_TECHNICAL_DECISIONS_APPROVED.md` and `docs/15_CUSTOMER_GROUP_FUNCTION_CONTRACT.md`. Không đồng nghĩa schema/API hoặc downstream calculation implementation đều đã đạt QA.

| ID | Quyết định đã duyệt | Dữ liệu/module chịu trách nhiệm |
|---|---|---|
| `CUS-X-01` | Dùng Contact P1 cho nhiều địa chỉ giao hàng | CUS / Contact |
| `CUS-X-02` | Dùng INDIVIDUAL/ORGANIZATION và mã nhóm kiểm soát | CUS |
| `CUS-X-03` | Customer Group Master; giao dịch và nhật ký scoped Company | CUS / PBAC |
| `CUS-X-04` | Ba chỉ tiêu doanh số riêng biệt | SAL / CUS |
| `CUS-X-05` | Doanh số fulfillment cần giao thành công + xuất kho POSTED | SAL / INV |
| `CUS-X-06` | Công nợ vận hành theo Sales Order, không phải AR kế toán | SAL / FIN / CUS |
| `CUS-X-07` | Thu tiền được phân bổ theo Sales Order | FIN |
| `CUS-X-08` | Tách tiền khách trả cho hãng và tiền hãng chuyển Company | SAL / FIN |
| `CUS-X-09` | Có due_date và tuổi nợ; chưa credit limit | SAL / FIN |
| `CUS-X-10` | API và thống kê phân quyền theo từng nguồn dữ liệu | CUS / PBAC |
| `CUS-X-11` | Pricing nằm tại PRC; CUS chỉ cung cấp customer_group_code | PRC |
| `CUS-X-12` | As-of/timezone theo Company và hiệu chỉnh reversal | SAL / FIN / CUS |

## Quy tắc bổ sung mục D đã được duyệt

| Quy tắc | Cách áp dụng |
|---|---|
| Số bảng mới | **3**: `customers`, `customer_company_usages`, `customer_interactions` |
| Customer code | Unique toàn Group; tái sử dụng P1 Auto Numbering nếu bật |
| Mã số thuế | Có search/index, **không UNIQUE** |
| Primary Contact | `primary_contact_id` nullable, owner bắt buộc đúng Customer; không đồng nghĩa địa chỉ giao hàng mặc định |
| Nhiều địa chỉ | Từ các bản ghi P1 `contacts` owner `CUSTOMER`; không `is_shipping_address` |
| Company Usage | `all_companies`/allowlist hiện hành; không tự sửa history |
| Contact interactions | Company-owned, append-only |
| Đơn không xác định Customer | `customer_id=NULL` không được tự ghép Customer theo phone/address/alias |
| Tiền tệ | VND, DECIMAL; không dùng float |
| Customer inactive | Chặn giao dịch mới; lịch sử được phép vẫn xem được |

## Tác động chính thức của việc duyệt

- Chuyển từ 4 bảng CUS draft sang 3 bảng: xóa thiết kế `customer_groups`, thay `customer_notes` bằng `customer_interactions`; bỏ các `shipping_*` trực tiếp trên `customers`.
- Mở rộng Contact P1 bằng `CUSTOMER` owner khi bắt đầu triển khai, không thay đổi owner `ORGANIZATION` và `EMPLOYEE`.
- Khóa **chức năng**: chỉ tiêu sales ba loại, doanh số giao+POSTED, công nợ vận hành theo Sales Order, phân bổ thanh toán, COD collection vs remittance, due_date/aging, as-of và reversal.
- Không tự phê duyệt những chi tiết **chưa được chỉ định**: bộ giá trị `customer_group_code`, SQL PBAC cuối cùng, các status event SAL, settlement provider contract, payment-reversal allocation schema cụ thể. Chúng thuộc gate kỹ thuật/thiết kế module nguồn ở `docs/10_OPEN_ITEMS_AND_GATES.md`.

## Change control

Quyết định bổ sung KPI và công nợ **không được chèn ngược** vào nguyên văn User Requirements 1.0.15. Đăng ký `P2-CUS-CR-001` để quản lý scope tăng thêm. P2 v1.0.0 và tài liệu v0.x giữ làm lịch sử; trong phạm vi CUS quyết định mới tại đây **supersede** mô hình CUS 4 bảng và endpoint customer-groups trước đó. Mọi thay đổi sau này cần version/ADR mới.

## Addendum 2026-10-28 — G1 Technical sign-off (binding)

Product Owner additionally approved seven technical A decisions `CUS-T-GROUP-01`, `CUS-T-SEC-01`, `CUS-T-SQL-01`, `CUS-T-WF-01`, `CUS-T-API-01`, `CUS-T-DATA-01`, `CUS-T-INT-01`. The specific Group code function supplied by PO **overrides** the previous suggested `STANDARD`/`VIP` code list: `STANDARD, TMDT, VIP1, VIP2` and nullable; there is **no** literal `VIP` code. Approved `CORRECTION` interaction type and `corrects_interaction_id` FK are mandatory. These are technical decisions, **not** approval to execute production migrations or to claim tests passed. The 9 XMOD source-module contracts stay open. Technical normative detail: `docs/14_G1_TECHNICAL_DECISIONS_APPROVED.md`.
