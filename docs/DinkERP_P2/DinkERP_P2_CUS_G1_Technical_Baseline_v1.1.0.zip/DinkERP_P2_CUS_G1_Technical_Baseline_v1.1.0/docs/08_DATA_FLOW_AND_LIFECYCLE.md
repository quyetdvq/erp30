# Data Flow, state/lifecycle và tính lịch sử

**Document ID:** P2-CUS-FLOW-001 · **v1.0.0** · **Source control only; not runtime tested**.

## 1. Customer creation

```text
User authenticated -> authorize(customer.create@GROUP) -> normalize/validate Customer
 -> validate Customer Type / group code / main Province-Ward
 -> resolve Company ALL or allowlist (Organizations type COMPANY)
 -> begin transaction (+ P1 numbering if active)
 -> insert customers -> insert usages (when LIST) -> audit -> commit
```

- Fails at any step => rollback Customer/usage/number allocation together.
- `customer_code` unique across Group, including concurrent create; `tax_code` nonunique.
- `status` initially configured lifecycle state, no client arbitrarily choosing state.

## 2. Status/usage change

**Status:** only approved Workflow transition through `customer.setstate`; one transition at a time, PBAC re-evaluated on persisted target. `INACTIVE` cannot be chosen on *new* Orders; changing status never erases historical orders/notes.

**Company usage:** `ALL=true` -> no usage rows; `ALL=false` -> one or more Company IDs when Customer ACTIVE. Permission on shared Customer still independent of Company business eligibility. A currently existing SO belonging removed Company remains linked to Customer and governed by Sales authorization/history rules.

## 3. Contact-as-ship-to

```text
Customer selected for Company C
 -> verify Customer ACTIVE and eligible at C
 -> fetch Contacts (CUSTOMER owner, persisted ID, permitted by PBAC)
 -> computed shippable: ACTIVE + name + phone/mobile + address + active valid Province/Ward
 -> choose Contact (no default) -> validate again in Sales server transaction
 -> SNAPSHOT recipient/address/phone/Province/Ward into Sales Order
 -> confirm; later Contact edits do NOT mutate SO/Shipment labels
```

If a carrier or recipient change is necessary after confirmation, SAL must implement an audited business action and possibly a Shipment snapshot. A SO initially has one destination; multi-destination requires separate Sales design. Marketplace external order address snapshots do not imply Customer Contact creation.

## 4. Interactions

`customer_interaction.create` with authoritative Customer and Company -> append once (server actor/time). Read with SQL PBAC restricted Company before page/total; corrections append another event, not edit/delete silent history. No independent Company ownership table for Contact.

## 5. Sales/Finance event projection

```text
Confirmed SO (frozen price+customer+company) ----> confirmed_order_value
Delivery success AND posted Sales Issue -------> fulfilled_goods_value
Approved commercial return credit -------------> net_sales_operational decreases
Posted FIN receipt with order allocation ------> paid(o,t) decreases receivable
Posted refund undoing applied payment ---------> refunded(o,t) increases receivable position
Carrier confirmed COD collection --------------> customer collection state (separate)
Carrier payout + posted FIN receipt -----------> business cash received; NOT another customer payment
```

- Time is authoritative instant; business date per **transaction Company** timezone P1.
- As-of replay requires events/reversal and effective times retained by SAL/FIN. If only current mutable status is stored, historical query as-of cannot be certified; this is an integration test blocker.
- Do not read `status` from presentation settings. Do not mix future settlement/remittance amounts with Customer received.

## 6. Deletion / retention

No hard delete Customer with references. `customer_interactions` append-only. P1 Contact retains history on inactive/closed. Posted Sales Issue/Receipt adjustments happen with reversal/correction links. Underlying audit retention and data privacy rules from P1/P2 operational policy still apply; no arbitrary permanent deletion in UI.

## G1 technical workflow and correction lock v1.1.0

Customer new `ACTIVE` only after canonical Group code validated (`CUSTOMER_GROUP()` or SQL NULL), unique customer_code and atomic ALL/LIST Company checks. `ACTIVE`↔`INACTIVE` via `customer.setstate` only; Contact follows P1 lifecycle. For `CORRECTION`, find a previously committed non-CORRECTION original with identical Customer + Company in a server transaction; insert a **new** row with `corrects_interaction_id`, reason content and server-created `happened_at/created_at`. Existing activity data is never overwritten. Use stored original events and latest correction by `(created_at,id)` for effective display while retaining full audit history. No new balance or history table.
