# CUS Scope, Requirements và Change Addendum

**Design authority:** UR-CUS-001 / UR-CUS-002 và các P1 invariants trong `00_User_Requirements_v1.0.15.md`. Toàn văn UR gốc đính kèm ở `../reference/UR_CUS_001_002_SOURCE_VERBATIM.md` và `../reference/00_User_Requirements_v1.0.15.md`.

## 1. UR gốc — giữ nguyên hiệu lực

- **UR-CUS-001:** Customer là shared Group Master, code unique, contact/Company Usage/Status, địa chỉ chính và địa chỉ giao hàng, Customer inactive không dùng giao dịch mới nhưng history đọc được.
- **UR-CUS-002:** note/lịch sử liên hệ, lịch sử Sales Order/Shipment/Sales Return/Thu tiền có kiểm tra phân quyền; **không Lead/Opportunity**.
- **Quyết định biểu diễn tương đương được duyệt:** Shipping Address/Province/Ward được lưu ở `contacts` owner `CUSTOMER` thay vì cột shipping trực tiếp trong `customers`. Khi tạo SO lấy snapshot ship-to, không biến Customer thành bộ nhớ duy nhất của Shipping data.

**UR acceptance registry (8 AC):**

| ID | Kiểm chứng |
|---|---|
| `P2-AT-CUS-001-01` | Code unique toàn Group |
| `P2-AT-CUS-001-02` | ALL hoặc Company allowlist |
| `P2-AT-CUS-001-03` | Company không thuộc scope không dùng cho giao dịch mới |
| `P2-AT-CUS-001-04` | Shared Contact 1:N dùng lại từ P1 |
| `P2-AT-CUS-001-05` | Customer inactive không giao dịch mới, vẫn đọc history có quyền |
| `P2-AT-CUS-002-01` | Lưu notes/interaction history |
| `P2-AT-CUS-002-02` | Sales Orders, Shipments, Returns, Receipts theo quyền nguồn |
| `P2-AT-CUS-002-03` | Không Lead/Opportunity |

## 2. Scope bổ sung đã được Product Owner phê duyệt — `P2-CUS-CR-001`

**Lý do:** 2 UR CUS ban đầu không đặc tả KPI doanh số/công nợ, thời điểm ghi nhận, phân bổ tiền, COD và aging. Quyết định `CUS-X-04`…`CUS-X-12` đã chốt *mục tiêu nghiệp vụ*, giữ triển khai và nghiệm thu theo module sở hữu nguồn.

| FR bổ sung | Năng lực / tiêu chí chấp nhận nghiệp vụ | Chủ dữ liệu |
|---|---|---|
| `CUS-ADD-01` | Hiển thị riêng Giá trị đơn xác nhận, Giá trị hàng đã giao và Doanh số vận hành ròng | SAL + INV |
| `CUS-ADD-02` | Value fulfilled chỉ khi đã giao và Stock Issue POSTED; trả hàng chỉ trừ khi credit thương mại được duyệt; partials không double count | SAL / INV |
| `CUS-ADD-03` | Công nợ vận hành theo Company + Customer + Sales Order, phân biệt còn phải thu, thừa tiền và tiền ứng trước; không lập full AR ledger | SAL / FIN |
| `CUS-ADD-04` | Payment allocation N:M, chỉ POSTED/reversal-aware; không cross-Company, Customer hoặc double apply | FIN |
| `CUS-ADD-05` | COD tách trạng thái người mua trả hãng và hãng chuyển doanh nghiệp; settlement không thu khách hai lần | SAL / FIN |
| `CUS-ADD-06` | Có due_date/aging (1–30, 31–60, 61–90, >90); không credit limit, không auto block; không due date => unclassified | SAL / FIN |
| `CUS-ADD-07` | Mọi báo cáo theo authorized Company và quyền nguồn, với `as_of`/timezone/reversal; dependency chưa triển khai -> NOT_AVAILABLE | CUS + nguồn |
| `CUS-ADD-08` | Customer group codes ổn định dùng cho PRC; CUS không lưu/list giá độc lập | CUS / PRC |

**Đây là addendum scope được duyệt qua hội thoại Product Owner, không phải thay thế text UR gốc.** Các kịch bản test chi tiết vẫn cần phê duyệt tại gate của module sở hữu khi biết chính xác state/event/field.

## 3. Scope bị loại

Không có customer-specific AR ledger, invoice journal/GL, tax-compliance AR, dòng tiền FX, hạn mức/khóa tín dụng, Lead/Opportunity/Campaign, bảng Customer Group tự cấu hình, địa chỉ giao hàng riêng, billing process mang tính pháp lý, cache KPI đã materialize, hay bảng copy Sales/Finance vào CUS.

## 4. Sở hữu chức năng và nghiệm thu

- **CUS-G1 Core:** Customer CRUD, Company Usage, Contact ship-to, interaction log, PBAC, UI/API/list, 8 UR acceptance nhưng nhánh UR-CUS-002 liên quan SAL/FIN phải **DEFERRED BY DEPENDENCY**, không được ghi PASS giả.
- **CUS-XMOD:** Phê duyệt contract theo bản thiết kế này; runtime UAT chỉ sau khi INV/SAL/FIN/PRC/DOC module nguồn cần thiết sẵn sàng.
- **CUS-FULL:** Chỉ được đóng toàn bộ khi kiểm thử E2E với data thật trên DEV clone; không có bằng chứng test runtime trong bộ tài liệu này.

## CUS-G1 technical sign-off 2026-10-28

The Product Owner approved all 7 G1 technical A choices. The exact initial code list is `CUSTOMER_GROUP(): STANDARD/TMDT/VIP1/VIP2` (Vietnamese labels as in `docs/15_CUSTOMER_GROUP_FUNCTION_CONTRACT.md`); `customer_group_code` permits SQL NULL, `VIP` by itself is **not a valid code**. Add `customer_interactions.corrects_interaction_id` nullable FK and `CORRECTION` in the activity enum. G1 design blockers are CLOSED, the code/database remain unchanged, SAL/FIN/PRC XMOD gates remain open. The 8 source acceptance criteria remain unchanged verbatim.
