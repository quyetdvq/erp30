# Documentation Integrity & Design QA — P2-CUS-G1 v1.1.0

**Run this after extraction:** `python3 tools/check_cus_g1_bundle.py` (no ERP runtime or DB required). PyYAML/jsonschema optional for deeper OpenAPI validation.

**Design gate:** 12/12 business choices A + 7/7 technical choices A approved by PO on 2026-10-28. **G1 blockers: 0**; **XMOD design still OPEN: 9**.

## Freeze summary

| Measured design item | Count / state |
|---|---|
| Original CUS requirements | 2 with 8 acceptance criteria retained verbatim |
| Additive feature groups | 8, including revenue and operational receivables |
| Approved business choices | 12/12 A + D supporting rules |
| Approved G1 technical choices | 7/7 A, including exact GROUP helper and CORRECTION self-FK |
| Outstanding G1 technical design blocker | 0 |
| Outstanding XMOD source-module design item | 9 |
| New CUS tables | 3 (not migrated) |
| New CUS logical columns | 29 (including corrects_interaction_id) |
| PHP CUSTOMER_GROUP() registered keys | 4: STANDARD / TMDT / VIP1 / VIP2, nullable DB field |
| CUS Core API in OpenAPI design | 7 (not implemented) |
| CUS deferred readers | 3 (dependency pending) |
| CUS planned test cases | 66, all NOT_RUN |

## Structural validation scope

The packaged checker verifies the manifest and checksum list, byte-faithful User Requirements, 12 + 7 approved choices, 7 CLOSED/9 OPEN, exact group-helper code/label list and nullable rule, absence of executable PHP application code, 3 tables/29 columns, self-FK and activity type, trace coverage, 66/66 tests unexecuted, 7/3 API statuses, local Markdown links, OpenAPI 3.1 parsing/$refs and JSON-Schema positive/negative fixtures (when PyYAML/jsonschema are installed).

**Runtime limitation:** QA validates documentary structure and sample schemas, **not** actual PHP Contact permission, DBPrefix, MariaDB migration, Frontend behavior, SAL/FIN transactions, P1 regressions or production deployment. The DOCS READY state **must not** be presented as CUS deployed or UAT passed.

## Authoritative dependency mapping

- `reference/00_User_Requirements_v1.0.15.md` is original byte-faithful requirements content.
- `docs/00_DECISION_RECORD.md` is the original 12-business decision record with technical addendum.
- `docs/14_G1_TECHNICAL_DECISIONS_APPROVED.md` is the binding seven technical choices; `docs/15_CUSTOMER_GROUP_FUNCTION_CONTRACT.md` contains the literal helper code specimen.
- `docs/10_OPEN_ITEMS_AND_GATES.md` lists only nine remaining XMOD source-gate items.
- `reference/CUS_G1_APPROVED_TECH_DECISIONS.csv`, `reference/CUS_OPEN_TECHNICAL_ITEMS.csv`, `reference/CUS_CUSTOMER_GROUP_CODES.csv`, `reference/CUS_DATABASE_DICTIONARY.csv`, `contracts/openapi/p2-cus.design.openapi.yaml`, `reference/CUS_TEST_CASES.csv` are structured consistency sources.

## Verified distribution evidence (2026-10-28)

- **29/29 documentation/schema/integrity checks PASS** using `tools/check_cus_g1_bundle.py`.
- The independently extracted ZIP also produced **29/29 PASS**. Source requirement SHA-256 matched the preserved original.
- The planned `CUSTOMER_GROUP()` PHP snippet was extracted into a **temporary review file outside ERP**, passed `php -l` (PHP 8.4.24), and returned exactly `STANDARD/TMDT/VIP1/VIP2` with user-approved Vietnamese labels.
- `erp_v1.9.0.zip` source hash verified as `464cfe340c4d1b8d8ada4357b48fb8e470d719985155b8371ba01a975dbdf626`. No source application files were changed.
- This evidence is **documentation and helper-example verification**, not CI4 integration/UAT or deployed application behavior.

## Release-state guard

`CUS-G1 TECHNICAL DESIGN READY` ✅; actual implementation `NOT_STARTED`; MariaDB/CI4/FE runtime tests `NOT_RUN`; XMOD reports `DEPENDENCY_PENDING`; no application source code/database changed during this documentary update. Previous parent P2 v1.0.0 remains a historical DRAFT to be merged at a separate P2 versioned update; see `docs/12_P2_DOCUMENT_SYNC_AMENDMENT.md`.
