# Database Design — CUS tối giản 3 bảng

**Document ID:** P2-CUS-DB-001 · **Approved logical design v1.1.0; all 7 G1 technical choices signed off**. Chưa có migration thực thi và chưa kiểm thử MariaDB. Tên logic tuân `DBPrefix` CodeIgniter của dự án; trường hợp cụ thể DB prefixed cần kiểm tra migration khi triển khai.

## 1. ER logical model

```text
organizations (P1, type COMPANY) 1 -- N customer_company_usages N -- 1 customers
customers 1 -- N customer_interactions N -- 1 organizations (COMPANY)
customers 1 -- N contacts (P1: contact_type='CUSTOMER', contact_ref_id=customers.id)
customers 0..1 -- 1 contacts (P1: primary_contact_id, validate owner pair)
customers N -- 1 provinces / wards (P1, optional main address)
[future] customers 1 -- N sales_orders (SAL) -- N money_source_links (FIN via order)
```

## 2. `customers` (new)

| Column | Type (logical) | Null/default | Validation |
|---|---|---|---|
| `id` | BIGINT UNSIGNED auto PK | NOT NULL | Technical key |
| `customer_code` | VARCHAR(50) | NOT NULL | UNIQUE toàn Group, trim/normalize theo P1 + numbering if configured |
| `name` | VARCHAR(255) | NOT NULL | Không rỗng |
| `customer_type` | VARCHAR(20) | NOT NULL | `INDIVIDUAL`, `ORGANIZATION` |
| `customer_group_code` | VARCHAR(50) | NULL | NULL hoặc `STANDARD/TMDT/VIP1/VIP2` từ helper `CUSTOMER_GROUP()` đã được duyệt |
| `phone` | VARCHAR(50) | NULL | Plain contact channel, optional |
| `email` | VARCHAR(255) | NULL | Optional; validation theo API contract |
| `tax_code` | VARCHAR(50) | NULL | Chỉ INDEX, **không UNIQUE** |
| `address` | TEXT | NULL | Địa chỉ chính/billing của Customer; không thay địa chỉ SO |
| `province_id` | BIGINT UNSIGNED | NULL | FK provinces.id |
| `ward_id` | BIGINT UNSIGNED | NULL | FK wards.id; nếu có phải thuộc province hợp lệ |
| `primary_contact_id` | BIGINT UNSIGNED | NULL | FK contacts.id; owner `CUSTOMER` và ID khớp; không ship-to default |
| `all_companies` | TINYINT(1) | NOT NULL | ALL nếu `1`, allowlist nếu `0` |
| `status` | VARCHAR(20) | NOT NULL | `ACTIVE`, `INACTIVE`; transition qua Workflow |
| `created_by`, `updated_by` | BIGINT UNSIGNED | NULL | Server actor / seed null |
| `created_at` | DATETIME | NOT NULL | Server-managed |
| `updated_at` | DATETIME | NULL | Server-managed |

**Keys/indexes:** PK(id), UNIQUE(customer_code), INDEX(status,name), INDEX(customer_group_code), INDEX(tax_code), INDEX(all_companies,status). FK province_id/ward_id, primary_contact_id (P1 contacts). Không yêu cầu uniqueness của phone/email/tax. `customer_group_code` không có FK vì catalog code kiểm soát tại application layer.

**Đã loại khỏi thiết kế:** `shipping_address`, `shipping_province_id`, `shipping_ward_id`, `customer_group_id`, company-owned `customer_id` clone, `revenue`, `debt`, balance counters hoặc `current_due`. Contact quản lý các địa chỉ ship-to; các khoản phải thu chỉ là reporting projection.

## 3. `customer_company_usages` (new)

| Column | Type | Constraint |
|---|---|---|
| `customer_id` | BIGINT UNSIGNED | NOT NULL FK `customers.id` |
| `company_organization_id` | BIGINT UNSIGNED | NOT NULL FK `organizations.id`; service verify `type=COMPANY` |

**PK:** `(customer_id, company_organization_id)`; index reversed `(company_organization_id, customer_id)` khi dùng query theo Company. Không có auto id, status, effective dates, audit row; parent customer audit ghi actor/time thay scope.

**Mutation:** `all_companies=1` => zero row; `all_companies=0` và Customer ACTIVE => ít nhất một Company hợp lệ; replace list trong transaction + lock parent row, reject invalid non-COMPANY/duplicate/unknown/inactive Company for new use. `customer_company_usages` chỉ thể hiện eligibility, không phải permission và không back-edit historical orders.

## 4. `customer_interactions` (new)

| Column | Type | Constraint |
|---|---|---|
| `id` | BIGINT UNSIGNED PK auto | NOT NULL |
| `customer_id` | BIGINT UNSIGNED | NOT NULL FK customers.id |
| `company_organization_id` | BIGINT UNSIGNED | NOT NULL FK organizations.id (`COMPANY`) |
| `activity_type` | VARCHAR(30) | NOT NULL, enum `NOTE/CALL/EMAIL/MEETING/CORRECTION` |
| `content` | TEXT | NOT NULL nonblank |
| `happened_at` | DATETIME | NOT NULL; authoritative instant/UTC convention compatible P1 |
| `corrects_interaction_id` | BIGINT UNSIGNED | NULL FK `customer_interactions.id`; required iff `CORRECTION` |
| `created_by` | BIGINT UNSIGNED | NULL for approved system actions; otherwise actor |
| `created_at` | DATETIME | NOT NULL |

**Indexes:** `(customer_id,company_organization_id,happened_at,id)`; `(company_organization_id,happened_at)`; `(corrects_interaction_id)` (FK index if not already covered). Append-only, không có `updated_at`, `deleted_at`. A `CORRECTION` must reference an earlier non-CORRECTION row **of same Customer + Company** (validated in service transaction), with nonblank reason; non-CORRECTION `corrects_interaction_id` must be NULL. No cascade delete; effective latest correction ordered by `(created_at,id)`, all history retained. Không thêm `customer_notes` cạnh tranh.

## 5. P1 reused tables, verified from v1.9.0

| Table | P1 source and integration notes |
|---|---|
| `contacts` | P1 migration `2026-10-05-000002_CreateOrganizationContactTables.php`. Fields owner `contact_type`, `contact_ref_id`; `description`, `name`, `phone`, `mobile`, `email`, `address`, Province/Ward IDs and name snapshots, status/audit. No `organization_id` and no FK to polymorphic owner. Currently owner types `ORGANIZATION`/`EMPLOYEE` only. |
| `organizations` | P1 group/company hierarchy; Company is `type=COMPANY`; only one Group root business scope |
| `provinces`, `wards` | P1 migration `2026-10-05-000001_CreateFoundationLocationTables.php`; FK wards.province_id; historic references retained |
| P1 authorization/numbering/workflow | Reuse Resource Actions, PBAC, Shield, Auto Numbering, Lifecycle; do **not** create alternative persistence |

**Đặc biệt:** `primary_contact_id` FK + polymorphic owner validity **không thể được bảo đảm bằng FK đơn thuần**; service validates `(contact_type='CUSTOMER', contact_ref_id=customers.id)` tại transaction. Kết nối vòng Customer→Contact bằng cách insert customer trước, rồi contact, rồi gán `primary_contact_id`.

## 6. Concurrency, audit and migration contract

1. Migration chỉ **additive** từ ERP P1 v1.9.0; không drop/rename P1 Contact table. P1 existing `CONTACT` owner regression giữ nguyên.
2. Customer creation/numbering and company usages cùng transaction; unique index chống duplicate concurrent code. Numbering rollback cùng transaction khi tạo thất bại.
3. Replace allowlist lock row Customer, reset/replace atomically; checks thực thi tại thời điểm SO create/confirm trong SAL.
4. FK with soft state invariants: không CASCADE hard-delete Customer/Company/Contact khi lịch sử đã tham chiếu.
5. Authorization SQL scope trước COUNT/order/limit. Audit create/update/status/usage mutations; interaction append-only.
6. Dữ liệu *không* có thể reconstruct từ bảng Customer: total revenue, receivable, COD, sales order shipping history — lấy từ nguồn SAL/FIN/ship snapshot.
7. Trước migration: DBA xác nhận exact CI4 DBPrefix, default charset/collation, indexes, FK, timezone, duplicate-code normalization và rollback plan trên DEV clone.

## 7. P2 drafts cần loại bỏ

`customer_groups`, `customer_notes`, Customer `shipping_*`, `customer_company_usages.status`; cả `customer_group_id` FK trong `price_list_item_conditions` và `promotion_conditions` phải được thiết kế lại tại PRC thành code-based matching. Không sửa *source* P1; các entity này mới chỉ ở tài liệu draft P2 v1.0.0.

## 8. 2026-10-28 — Technical G1 database freeze

**Exactly 3 new tables, 29 logical columns**: `customers` 18 + `customer_company_usages` 2 + `customer_interactions` **9**. New column in interactions `corrects_interaction_id BIGINT UNSIGNED NULL`, FK self-reference `ON DELETE RESTRICT`, indexing for lookup; service validates same persisted `customer_id`/`company_organization_id`, non-CORRECTION original, older row, and correction action. Do not add `is_shipping_address`, `customer_groups`, `customer_addresses` or cached receivable fields.

`customers.customer_group_code VARCHAR(50) NULL` must be validated against the four keys from `CUSTOMER_GROUP()`; no SQL enum or FK, and `NULL` means unassigned. **Never persist Vietnamese labels.** `TMDT` is a code, not Sales source channel. Duplicate Customer code authoritative Unique Group index after trim/ASCII-uppercase canonicalization; numbering P1 `AUTO_REQUIRED`/`AUTO_IF_EMPTY` and manual fallback after active series validation. Verify actual CI4 DBPrefix, collation and FK DDL on DEV clone before applying any migration; this implementation-time check does not reopen the approved schema.
