<?php

declare(strict_types=1);

/**
 * This file is part of CodeIgniter 4 framework.
 *
 * (c) CodeIgniter Foundation <admin@codeigniter.com>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

// Pager language settings
return [
    'pageNavigation'         => 'Điều hướng trang',
    'first'                  => 'Đầu tiên',
    'previous'               => 'Trước',
    'next'                   => 'Kế tiếp',
    'last'                   => 'Cuối cùng',
    'older'                  => 'Cũ hơn',
    'newer'                  => 'Mới hơn',
    'invalidTemplate'        => '{0} không phải là một mẫu phân trang hợp lệ.',
    'invalidPaginationGroup' => '{0} không phải là một nhóm phân trang hợp lệ.',
];
